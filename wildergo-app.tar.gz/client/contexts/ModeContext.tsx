/**
 * WilderGo Mode Context
 * Global state management for strict mode separation (Dating, Friends, Builder)
 * Implements "Wall of Separation" architecture with liquid color themes
 */

import React, { createContext, useContext, useState, useCallback, useRef, useEffect } from 'react';
import { Animated, Easing } from 'react-native';
import { colors } from '@/constants/theme';

export type AppMode = 'dating' | 'friends' | 'builder';

export interface ModeTheme {
  primary: string;
  primaryLight: string;
  primaryDark: string;
  accent: string;
  glow: string;
  gradient: [string, string, string];
  icon: string;
  emoji: string;
  label: string;
  description: string;
}

// Standardized Wall of Separation Colors
// Dating: Red | Friends: Blue | Builder: Amber | Help: Orange
export const modeThemes: Record<AppMode, ModeTheme> = {
  dating: {
    primary: '#DC2626',           // Red for dating
    primaryLight: '#EF4444',
    primaryDark: '#B91C1C',
    accent: '#FCA5A5',
    glow: 'rgba(220, 38, 38, 0.4)',
    gradient: ['#EF4444', '#DC2626', '#B91C1C'],
    icon: 'heart',
    emoji: '💕',
    label: 'Dating',
    description: 'Find meaningful connections on the road',
  },
  friends: {
    primary: '#2563EB',           // Blue for friends
    primaryLight: '#3B82F6',
    primaryDark: '#1D4ED8',
    accent: '#93C5FD',
    glow: 'rgba(37, 99, 235, 0.4)',
    gradient: ['#3B82F6', '#2563EB', '#1D4ED8'],
    icon: 'people',
    emoji: '🏔️',
    label: 'Friends',
    description: 'Join convoys and share adventures',
  },
  builder: {
    primary: '#D97706',           // Amber for builder
    primaryLight: '#F59E0B',
    primaryDark: '#B45309',
    accent: '#FCD34D',
    glow: 'rgba(217, 119, 6, 0.4)',
    gradient: ['#F59E0B', '#D97706', '#B45309'],
    icon: 'construct',
    emoji: '🔧',
    label: 'Builder',
    description: 'Connect with vetted rig builders',
  },
};

interface UserSettings {
  ghostMode: boolean;
  isPremium: boolean;
  rigType: string;
  rigName: string;
}

interface ModeContextValue {
  // Current mode state
  mode: AppMode;
  setMode: (mode: AppMode) => void;
  theme: ModeTheme;

  // Animated values for liquid transitions
  colorAnim: Animated.Value;
  isTransitioning: boolean;

  // User settings
  settings: UserSettings;
  updateSettings: (settings: Partial<UserSettings>) => void;

  // Ghost mode
  isGhostMode: boolean;
  toggleGhostMode: () => void;

  // Premium status
  isPremium: boolean;
  setPremium: (status: boolean) => void;

  // Mode-specific helpers
  getModeAccentColor: () => string;
  getModeIcon: () => string;
  isModeAllowed: (feature: string) => boolean;
}

const ModeContext = createContext<ModeContextValue | undefined>(undefined);

interface ModeProviderProps {
  children: React.ReactNode;
}

export const ModeProvider: React.FC<ModeProviderProps> = ({ children }) => {
  const [mode, setModeState] = useState<AppMode>('friends');
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [settings, setSettings] = useState<UserSettings>({
    ghostMode: false,
    isPremium: false,
    rigType: 'Van Lifer',
    rigName: 'My Rig',
  });

  const colorAnim = useRef(new Animated.Value(0)).current;

  const setMode = useCallback((newMode: AppMode) => {
    if (newMode === mode) return;

    // Check if premium is required for dating mode
    if (newMode === 'dating' && !settings.isPremium) {
      // Could trigger paywall here
      console.log('Dating mode requires premium');
    }

    setIsTransitioning(true);

    // Liquid color transition animation
    Animated.sequence([
      Animated.timing(colorAnim, {
        toValue: 0.5,
        duration: 150,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: false,
      }),
      Animated.timing(colorAnim, {
        toValue: 1,
        duration: 300,
        easing: Easing.inOut(Easing.cubic),
        useNativeDriver: false,
      }),
    ]).start(() => {
      colorAnim.setValue(0);
      setIsTransitioning(false);
    });

    setModeState(newMode);
  }, [mode, settings.isPremium, colorAnim]);

  const updateSettings = useCallback((newSettings: Partial<UserSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  const toggleGhostMode = useCallback(() => {
    if (!settings.isPremium) {
      console.log('Ghost Mode requires premium');
      return;
    }
    setSettings(prev => ({ ...prev, ghostMode: !prev.ghostMode }));
  }, [settings.isPremium]);

  const setPremium = useCallback((status: boolean) => {
    setSettings(prev => ({ ...prev, isPremium: status }));
  }, []);

  const getModeAccentColor = useCallback(() => {
    return modeThemes[mode].primary;
  }, [mode]);

  const getModeIcon = useCallback(() => {
    return modeThemes[mode].icon;
  }, [mode]);

  const isModeAllowed = useCallback((feature: string) => {
    // Dating mode features require premium
    if (mode === 'dating' && !settings.isPremium) {
      const premiumFeatures = ['swipe', 'message', 'route-match'];
      return !premiumFeatures.includes(feature);
    }

    // Ghost mode requires premium
    if (feature === 'ghost-mode' && !settings.isPremium) {
      return false;
    }

    // Advanced route planning requires premium
    if (feature === 'advanced-route' && !settings.isPremium) {
      return false;
    }

    return true;
  }, [mode, settings.isPremium]);

  const value: ModeContextValue = {
    mode,
    setMode,
    theme: modeThemes[mode],
    colorAnim,
    isTransitioning,
    settings,
    updateSettings,
    isGhostMode: settings.ghostMode,
    toggleGhostMode,
    isPremium: settings.isPremium,
    setPremium,
    getModeAccentColor,
    getModeIcon,
    isModeAllowed,
  };

  return (
    <ModeContext.Provider value={value}>
      {children}
    </ModeContext.Provider>
  );
};

export const useMode = (): ModeContextValue => {
  const context = useContext(ModeContext);
  if (!context) {
    throw new Error('useMode must be used within a ModeProvider');
  }
  return context;
};

export const useModeTheme = () => {
  const { theme, mode } = useMode();
  return { theme, mode };
};

export const useGhostMode = () => {
  const { isGhostMode, toggleGhostMode, isPremium } = useMode();
  return { isGhostMode, toggleGhostMode, isPremium };
};

export default ModeContext;
