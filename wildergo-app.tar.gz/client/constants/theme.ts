/**
 * WilderGo Design System - Liquid iOS / Glassmorphism Edition
 * Premium, organic aesthetic with frosted glass and nature-inspired tones
 * Inspired by Yeti & Filson - rugged sophistication for the nomadic community
 */

// High-resolution nature imagery URLs for immersive backgrounds
export const natureImages = {
  // Van under stars - Desert night scene
  vanStars: 'https://images.unsplash.com/photo-1504851149312-7a075b496cc7?w=1200&q=80',
  // Desert sunrise with van
  desertSunrise: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200&q=80',
  // Misty pine forest
  mistyForest: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?w=1200&q=80',
  // Mountain lake reflection
  mountainLake: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200&q=80',
  // Campfire at dusk
  campfire: 'https://images.unsplash.com/photo-1475483768296-6163e08872a1?w=1200&q=80',
  // Redwood forest
  redwoodForest: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=1200&q=80',
  // Ocean cliff sunset
  oceanCliff: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&q=80',
  // Starry night sky
  starryNight: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=1200&q=80',
  // Golden hour meadow
  goldenMeadow: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=1200&q=80',
  // Canyon vista
  canyonVista: 'https://images.unsplash.com/photo-1474044159687-1ee9f3a51722?w=1200&q=80',
  // Pacific coast highway
  pacificCoast: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=1200&q=80',
  // Autumn forest road
  autumnRoad: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&q=80',
  // Person in nature (for profile photos)
  hikingProfile: 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=800&q=80',
  // Desert canyon
  desertCanyon: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=1200&q=80',
  // Cozy van interior
  vanInterior: 'https://images.unsplash.com/photo-1533745848184-3db07256e163?w=1200&q=80',
};

// Profile placeholder images
export const profileImages = {
  alex: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80',
  jordan: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80',
  sam: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&q=80',
  sarah: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&q=80',
  mike: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=80',
};

// Event/Activity images
export const eventImages = {
  bonfire: 'https://images.unsplash.com/photo-1475483768296-6163e08872a1?w=600&q=80',
  hiking: 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=600&q=80',
  climbing: 'https://images.unsplash.com/photo-1522163182402-834f871fd851?w=600&q=80',
  surfing: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=600&q=80',
  stargazing: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=600&q=80',
};

// Earth & Moss map color palette
export const mapColors = {
  land: '#E8E4DE',
  landLight: '#F0ECE8',
  water: '#8A9B8A',
  waterDark: '#6A7B6A',
  road: '#C9B896',
  roadMain: '#988A78',
  forest: '#7A9B80',
  park: '#A8C4A8',
  building: '#D0C8BC',
  text: '#4A4038',
  textLight: '#7A6E64',
  border: '#BAB0A8',
};

// ============================================
// OUTDOOR-INSPIRED BRAND PALETTE
// ============================================

// Primary Brand Colors
export const brandColors = {
  // Burnt Sienna - Primary Actions (CTA buttons, important UI)
  burntSienna: {
    900: '#7A3520',
    800: '#8B3E26',
    700: '#A64A2E',
    600: '#B65436',
    500: '#C65D3B', // Primary
    400: '#D47050',
    300: '#E08A6D',
    200: '#ECAA94',
    100: '#F5CCBE',
    50: '#FBE9E3',
  },

  // Desert Sand - Secondary Accents (backgrounds, cards)
  desertSand: {
    900: '#8B7355',
    800: '#9E8466',
    700: '#B39878',
    600: '#C7AB8C',
    500: '#E8C5A5', // Primary
    400: '#EDD0B5',
    300: '#F2DBC5',
    200: '#F6E5D5',
    100: '#FAF0E8',
    50: '#FDF8F4',
  },

  // Forest Green - Natural/Friend Elements
  forestGreen: {
    900: '#152218',
    800: '#1E3124',
    700: '#254030',
    600: '#2D5A3D', // Primary
    500: '#3A7050',
    400: '#4D8563',
    300: '#6A9B7D',
    200: '#94B9A3',
    100: '#C4DBC9',
    50: '#E8F2EA',
  },

  // Deep Teal - Professional/Builder Accents
  deepTeal: {
    900: '#0D2629',
    800: '#133539',
    700: '#174048',
    600: '#1B4B52', // Primary
    500: '#256068',
    400: '#347680',
    300: '#508D97',
    200: '#7EB0B8',
    100: '#B4D4D9',
    50: '#E2F0F2',
  },

  // Sunset Orange - Dating Highlights
  sunsetOrange: {
    900: '#8C4520',
    800: '#A35028',
    700: '#BD5E32',
    600: '#D46B3C',
    500: '#E87A47', // Primary
    400: '#ED8F62',
    300: '#F1A47E',
    200: '#F5BFA2',
    100: '#FADAC6',
    50: '#FDEEE5',
  },
};

export const colors = {
  // Brand Colors (accessible at top level)
  ...brandColors,

  // Organic Palette - Muted nature tones (legacy + enhanced)
  moss: {
    900: '#1A2A1E',
    800: '#243826',
    700: '#2E462F',
    600: '#3A5840',
    500: '#4A6B50',
    400: '#5A7D60',
    300: '#7A9B80',
    200: '#A8C4A8',
    100: '#D4E4D4',
    50: '#EEF5EE',
  },

  sage: {
    900: '#2A3028',
    800: '#3A4238',
    700: '#4A5448',
    600: '#5A6658',
    500: '#6A7868',
    400: '#8A9A88',
    300: '#A8B8A8',
    200: '#C8D4C8',
    100: '#E4ECE4',
    50: '#F4F8F4',
  },

  driftwood: {
    900: '#2C2420',
    800: '#3E3430',
    700: '#524840',
    600: '#685C50',
    500: '#7E7060',
    400: '#988A78',
    300: '#B4A898',
    200: '#D0C8BC',
    100: '#E8E4DE',
    50: '#F6F4F2',
  },

  clay: {
    900: '#3A2820',
    800: '#4E3830',
    700: '#644840',
    600: '#7C5A4C',
    500: '#946C5C',
    400: '#A88474',
    300: '#C4A494',
    200: '#DCC8BC',
    100: '#F0E4DC',
    50: '#FAF6F4',
  },

  // Deep Bark - Text colors (never pure black)
  bark: {
    900: '#1E1814',
    800: '#2C241E',
    700: '#3A3028',
    600: '#4A4038',
    500: '#5A5048',
    400: '#7A6E64',
    300: '#9A8E84',
    200: '#BAB0A8',
    100: '#DCD6D0',
    50: '#F0ECE8',
  },

  // Accent - Sunset Ember (warm glow for route overlaps)
  ember: {
    900: '#7A4820',
    800: '#8C5430',
    700: '#A86840',
    600: '#C4784A',
    500: '#D68A5C',
    400: '#E89C6E',
    300: '#F0B088',
    200: '#F5C4A8',
    100: '#FAE0D0',
    50: '#FDF2EC',
    glow: 'rgba(214, 138, 92, 0.4)',
  },

  // Glass System
  glass: {
    white: 'rgba(255, 255, 255, 0.78)',
    whiteMedium: 'rgba(255, 255, 255, 0.58)',
    whiteLight: 'rgba(255, 255, 255, 0.38)',
    whiteSubtle: 'rgba(255, 255, 255, 0.18)',
    dark: 'rgba(30, 24, 20, 0.68)',
    darkMedium: 'rgba(30, 24, 20, 0.48)',
    darkLight: 'rgba(30, 24, 20, 0.28)',
    border: 'rgba(255, 255, 255, 0.28)',
    borderLight: 'rgba(255, 255, 255, 0.15)',
    borderDark: 'rgba(30, 24, 20, 0.12)',
    // Premium tinted glass variants
    tealGlass: 'rgba(27, 75, 82, 0.15)',
    greenGlass: 'rgba(45, 90, 61, 0.15)',
    orangeGlass: 'rgba(232, 122, 71, 0.15)',
    siennaGlass: 'rgba(198, 93, 59, 0.15)',
  },

  // Legacy compatibility
  forestGreen: brandColors.forestGreen,

  earthBrown: {
    900: '#2C2420',
    800: '#3E3430',
    700: '#524840',
    600: '#685C50',
    500: '#7E7060',
    400: '#988A78',
    300: '#B4A898',
    200: '#D0C8BC',
    100: '#E8E4DE',
    50: '#F6F4F2',
  },

  accent: {
    terracotta: '#C65D3B', // Updated to Burnt Sienna
    clay: '#A88474',
    rust: '#8B5A42',
    sand: '#E8C5A5', // Updated to Desert Sand
    stone: '#8B8680',
    driftwood: '#988A78',
    pine: '#2D5A3D', // Updated to Forest Green
    moss: '#5C6B4D',
    teal: '#1B4B52', // New Deep Teal
    sunset: '#E87A47', // New Sunset Orange
  },

  // Mode Accent Colors for UI elements, icons, pins
  modeAccent: {
    dating: {
      primary: '#DC2626',     // Red
      light: '#FEE2E2',       // Light red
      glow: 'rgba(220, 38, 38, 0.4)',
      border: '#DC2626',
    },
    friends: {
      primary: '#2563EB',     // Blue
      light: '#DBEAFE',       // Light blue
      glow: 'rgba(37, 99, 235, 0.4)',
      border: '#2563EB',
    },
    builder: {
      primary: '#D97706',     // Amber
      light: '#FEF3C7',       // Light amber
      glow: 'rgba(217, 119, 6, 0.4)',
      border: '#D97706',
    },
    help: {
      primary: '#E87A47',     // Orange
      light: '#FFEDD5',       // Light orange
      glow: 'rgba(232, 122, 71, 0.4)',
      border: '#E87A47',
    },
  },

  // Map Pin Colors
  mapPin: {
    base: '#F5EFE6',           // Warm cream base
    border: '#C65D3B',         // Burnt sienna border
    borderWidth: 2,
    innerBorderColor: '#FFFFFF', // White inner border for mode colors
    innerBorderWidth: 3,
  },

  // Semantic Colors (muted)
  semantic: {
    success: '#2D5A3D', // Forest Green
    error: '#C65D3B', // Burnt Sienna
    warning: '#E87A47', // Sunset Orange
    info: '#1B4B52', // Deep Teal
  },

  // Status Colors (for UI feedback)
  status: {
    success: '#2D5A3D', // Forest Green
    error: '#DC2626', // Red
    warning: '#E87A47', // Sunset Orange
    info: '#1B4B52', // Deep Teal
  },

  // Mode Colors - Wall of Separation (standardized across UI)
  modes: {
    dating: '#DC2626',    // Red for dating
    friends: '#2563EB',   // Blue for friends
    builder: '#D97706',   // Amber for builder
    help: '#E87A47',      // Orange for help/emergency
  },

  // Background - Warm Cream base (#F5EFE6)
  background: {
    nature: '#2A3A30',
    overlay: 'rgba(42, 58, 48, 0.4)',
    primary: '#F5EFE6',     // Warm cream (main background)
    secondary: '#EDE5D8',   // Slightly darker cream
    tertiary: '#E8DCC8',    // Desert sand light
    card: 'rgba(255, 255, 255, 0.85)',
    sand: '#F5EFE6',        // Same as primary for consistency
    cream: '#F5EFE6',       // Warm cream alias
    warmWhite: '#FAF7F2',   // Light warm white
    navBar: '#F5EFE6',      // Navigation bar background
  },

  // Text Colors - Deep Bark (never black)
  text: {
    primary: '#1E1814',
    secondary: '#4A4038',
    tertiary: '#7A6E64',
    muted: '#9A8E84',
    inverse: '#F6F4F2',
    link: '#2D5A3D', // Forest Green
    action: '#C65D3B', // Burnt Sienna
  },

  // Border Colors
  border: {
    light: 'rgba(255, 255, 255, 0.28)',
    medium: 'rgba(255, 255, 255, 0.18)',
    dark: 'rgba(30, 24, 20, 0.12)',
    sienna: '#C65D3B',        // Burnt sienna for nav bars
    siennaLight: 'rgba(198, 93, 59, 0.3)',
  },

  // Button Colors (standardized)
  button: {
    primary: {
      background: '#C65D3B',    // Burnt Sienna
      text: '#FFFFFF',
      border: '#C65D3B',
    },
    secondary: {
      background: '#FFFFFF',
      text: '#C65D3B',
      border: '#C65D3B',
    },
    secondaryOrange: {
      background: '#FFFFFF',
      text: '#E87A47',
      border: '#E87A47',
    },
    disabled: {
      background: '#E8E4DE',
      text: '#9A8E84',
      border: '#E8E4DE',
    },
  },

  // Card Colors
  card: {
    background: 'rgba(255, 255, 255, 0.9)',
    border: 'rgba(198, 93, 59, 0.2)',
    badgeBackground: '#E8C5A5', // Desert Sand for badges/tags
  },

  // Rig Break Emergency Color
  emergency: {
    red: '#DC2626',
    redGlow: 'rgba(220, 38, 38, 0.4)',
    redLight: '#FEE2E2',
  },

  // Weather Layer Colors
  weather: {
    clear: '#87CEEB',
    rain: '#4A6B8A',
    storm: '#374151',
    wind: '#6B7280',
    hot: '#DC2626',
    cold: '#3B82F6',
  },
};

// ============================================
// DUAL-FONT TYPOGRAPHY SYSTEM
// ============================================

export const typography = {
  // Dual-Font System:
  // 1. Russo One - Rugged, strong headers (expedition-ready)
  // 2. Outfit - Display and body text (clean, modern)
  fontFamily: {
    // Primary heading font - expedition-ready (Russo One)
    heading: 'RussoOne_400Regular',
    logo: 'RussoOne_400Regular',

    // Display font - Outfit for larger text elements
    display: 'Outfit_800ExtraBold',
    displayMedium: 'Outfit_500Medium',
    displayRegular: 'Outfit_400Regular',

    // Body text - Outfit for clean readability
    body: 'Outfit_400Regular',
    bodyMedium: 'Outfit_500Medium',
    bodySemiBold: 'Outfit_600SemiBold',
    bodyBold: 'Outfit_700Bold',
    bodyExtraBold: 'Outfit_800ExtraBold',

    // Legacy compatibility (mapped to new fonts)
    serif: 'RussoOne_400Regular',
    serifBold: 'RussoOne_400Regular',
    sans: 'Outfit_400Regular',
    sansMedium: 'Outfit_500Medium',
    sansBold: 'Outfit_700Bold',
    regular: 'Outfit_400Regular',
    medium: 'Outfit_500Medium',
    semiBold: 'Outfit_600SemiBold',
    bold: 'Outfit_700Bold',

    // Fallback (Inter for compatibility)
    fallback: 'Inter_400Regular',
    fallbackMedium: 'Inter_500Medium',
    fallbackBold: 'Inter_700Bold',
  },

  fontSize: {
    xxs: 10,
    xs: 11,
    sm: 13,
    base: 15,
    md: 17,
    lg: 20,
    xl: 24,
    '2xl': 30,
    '3xl': 36,
    '4xl': 44,
    '5xl': 52,
    hero: 52,
    logo: 28,
    // New display sizes
    displaySm: 32,
    displayMd: 40,
    displayLg: 48,
    displayXl: 56,
  },

  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },

  letterSpacing: {
    tight: -0.5,
    normal: 0,
    wide: 0.5,
    wider: 1,
    widest: 2,
    logo: 1.5,
    // Russo One specific
    rugged: 1.2,
  },
};

export const spacing = {
  xxs: 2,
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  '2xl': 32,
  '3xl': 40,
  '4xl': 48,
  '5xl': 64,
  xxxl: 80,
};

// Liquid design - extreme corner rounding (30px+)
export const borderRadius = {
  none: 0,
  sm: 8,
  base: 12,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 36,
  '2xl': 40,
  '3xl': 48,
  full: 9999,
  liquid: 30, // Primary liquid radius
  liquidLg: 36,
  liquidXl: 42,
  pill: 50,
};

// Ambient shadows for floating glass effect
export const shadows = {
  glass: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 24,
    elevation: 8,
  },
  glassSubtle: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 4,
  },
  glassFloat: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.2,
    shadowRadius: 32,
    elevation: 12,
  },
  glow: {
    shadowColor: '#D68A5C',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 6,
  },
  // Mode-specific glows
  glowDating: {
    shadowColor: '#E87A47',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 8,
  },
  glowFriends: {
    shadowColor: '#2D5A3D',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 6,
  },
  glowBuilder: {
    shadowColor: '#1B4B52',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 6,
  },
  // Emergency glow for Rig Break Flare
  glowEmergency: {
    shadowColor: '#DC2626',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 24,
    elevation: 12,
  },
  sm: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  base: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  md: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },
  lg: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8,
  },
  xl: {
    shadowColor: '#1E1814',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.18,
    shadowRadius: 24,
    elevation: 12,
  },
};

// Glass blur intensity
export const blur = {
  light: 10,
  medium: 20,
  heavy: 40,
  intense: 60,
  ultraIntense: 80,
};

// Valid invite codes for the app
export const VALID_INVITE_CODES = ['WILDER2024', 'VANLIFE', 'FREEDOM', 'NOMAD', 'ROADTRIP'];

// Marker types for the map - with mode-based visibility and warm cream styling
export const markerTypes = {
  campfire: {
    icon: 'flame',
    color: '#E87A47', // Orange
    baseColor: '#F5EFE6', // Warm cream base
    borderColor: '#C65D3B', // Burnt sienna border
    pulseColor: 'rgba(232, 122, 71, 0.4)',
    glowColor: 'rgba(232, 122, 71, 0.6)',
    label: 'Event',
    size: 44,
    modes: ['dating', 'friends'],
  },
  traveler: {
    icon: 'car-sport',
    color: '#2563EB', // Blue (Friends mode)
    baseColor: '#F5EFE6',
    borderColor: '#C65D3B',
    pulseColor: 'rgba(37, 99, 235, 0.4)',
    glowColor: 'rgba(37, 99, 235, 0.6)',
    label: 'Traveler',
    size: 40,
    modes: ['dating', 'friends'],
  },
  match: {
    icon: 'heart',
    color: '#DC2626', // Red (Dating mode)
    baseColor: '#F5EFE6',
    borderColor: '#C65D3B',
    pulseColor: 'rgba(220, 38, 38, 0.5)',
    glowColor: 'rgba(220, 38, 38, 0.8)',
    label: 'Match',
    size: 44,
    modes: ['dating'],
  },
  builder: {
    icon: 'construct',
    color: '#D97706', // Amber (Builder mode)
    baseColor: '#F5EFE6',
    borderColor: '#C65D3B',
    pulseColor: 'rgba(217, 119, 6, 0.4)',
    glowColor: 'rgba(217, 119, 6, 0.6)',
    label: 'Builder',
    size: 40,
    modes: ['builder'],
  },
  convoy: {
    icon: 'people',
    color: '#2563EB', // Blue (Friends mode)
    baseColor: '#F5EFE6',
    borderColor: '#C65D3B',
    pulseColor: 'rgba(37, 99, 235, 0.5)',
    glowColor: 'rgba(37, 99, 235, 0.7)',
    label: 'Convoy',
    size: 48,
    modes: ['friends'],
  },
  campfireCluster: {
    icon: 'bonfire',
    color: '#E87A47', // Orange
    baseColor: '#F5EFE6',
    borderColor: '#C65D3B',
    pulseColor: 'rgba(232, 122, 71, 0.6)',
    glowColor: 'rgba(232, 122, 71, 0.9)',
    label: 'Gathering',
    size: 56,
    modes: ['dating', 'friends'],
  },
  rigBreak: {
    icon: 'warning',
    color: '#E87A47', // Orange (Help mode)
    baseColor: '#F5EFE6',
    borderColor: '#C65D3B',
    pulseColor: 'rgba(232, 122, 71, 0.6)',
    glowColor: 'rgba(232, 122, 71, 0.9)',
    label: 'Rig Break',
    size: 52,
    modes: ['friends', 'builder', 'help'],
  },
  help: {
    icon: 'help-circle',
    color: '#E87A47', // Orange (Help mode)
    baseColor: '#F5EFE6',
    borderColor: '#C65D3B',
    pulseColor: 'rgba(232, 122, 71, 0.6)',
    glowColor: 'rgba(232, 122, 71, 0.9)',
    label: 'Help Request',
    size: 48,
    modes: ['help'],
  },
};

// Mapbox Earth & Moss theme configuration
export const mapboxConfig = {
  // Earth & Moss color scheme for map styling
  style: {
    land: '#E8E4DE',
    landLight: '#F0ECE8',
    water: '#8A9B8A',
    waterDark: '#6A7B6A',
    road: '#C9B896',
    roadMain: '#988A78',
    forest: '#7A9B80',
    park: '#A8C4A8',
    building: '#D0C8BC',
    text: '#4A4038',
    textLight: '#7A6E64',
    border: '#BAB0A8',
  },
  // Default map center (US - Moab, UT)
  defaultCenter: {
    latitude: 38.5733,
    longitude: -109.5498,
  },
  defaultZoom: 10,
  // Cluster configuration
  cluster: {
    radius: 50,
    maxZoom: 14,
    colors: {
      small: '#2D5A3D', // Forest Green
      medium: '#E87A47', // Sunset Orange
      large: '#C65D3B', // Burnt Sienna
    },
  },
  // Weather layer configuration
  weather: {
    windSpeedThresholds: {
      calm: 5, // mph
      moderate: 15,
      strong: 25,
      dangerous: 40,
    },
    temperatureThresholds: {
      cold: 32, // °F
      cool: 50,
      warm: 75,
      hot: 90,
    },
  },
};

// Social layer configuration
export const socialLayer = {
  // Route overlap thresholds for ember glow intensity
  routeOverlap: {
    high: 70,
    medium: 40,
    low: 20,
  },
  // Nomadic density scoring
  nomadicDensity: {
    high: 10,
    medium: 5,
    low: 1,
  },
  // Smart route suggestions
  routeSuggestions: {
    maxDistance: 500,
    minOverlap: 30,
    maxResults: 5,
  },
  // Campfire clustering thresholds
  clustering: {
    minPins: 3, // Minimum pins to form a cluster
    maxRadius: 5, // Miles
    animationDuration: 800,
  },
};

// Animation durations and configs
export const animations = {
  quick: 150,
  normal: 300,
  slow: 500,
  pulse: 2000,
  scan: 3000,
  // Mode icon animations
  heartbeat: {
    duration: 1200,
    scale: [1, 1.15, 1],
  },
  sway: {
    duration: 2000,
    rotation: [-3, 3],
  },
  tighten: {
    duration: 1500,
    rotation: [0, 15, -15, 0],
  },
  // Nomadic Pulse ripple
  nomadicPulse: {
    duration: 1800,
    scale: [1, 1.5],
    opacity: [0.6, 0],
  },
  // Liquid ripple for mode transitions
  liquidRipple: {
    duration: 600,
    scale: [0, 2],
    opacity: [0.8, 0],
  },
};

// Route overlap thresholds
export const routeOverlapThresholds = {
  high: 70,
  medium: 40,
  low: 20,
};

// Rig specifications configuration
export const rigSpecs = {
  solarWattage: {
    min: 0,
    max: 2000,
    unit: 'W',
    presets: [100, 200, 400, 600, 800, 1000, 1500, 2000],
  },
  waterCapacity: {
    min: 0,
    max: 200,
    unit: 'gal',
    presets: [10, 20, 40, 60, 80, 100, 150, 200],
  },
  batteryCapacity: {
    min: 0,
    max: 1000,
    unit: 'Ah',
    presets: [100, 200, 300, 400, 600, 800, 1000],
  },
  rigTypes: [
    'Sprinter Van',
    'Promaster',
    'Transit',
    'Skoolie',
    'Class A',
    'Class B',
    'Class C',
    'Fifth Wheel',
    'Travel Trailer',
    'Truck Camper',
    'Teardrop',
    'Popup',
    'Custom Build',
  ],
  connectivityTypes: [
    'Starlink',
    'Cellular (Hotspot)',
    'WiFi Only',
    'None',
  ],
};

// Maintenance tracking categories
export const maintenanceCategories = [
  { id: 'oil', label: 'Oil Change', icon: 'water', interval: 5000, color: '#1B4B52' },
  { id: 'tires', label: 'Tire Rotation', icon: 'ellipse', interval: 7500, color: '#4A4038' },
  { id: 'battery', label: 'Battery Check', icon: 'battery-charging', interval: 30, color: '#2D5A3D' },
  { id: 'solar', label: 'Solar Panel Clean', icon: 'sunny', interval: 90, color: '#E87A47' },
  { id: 'water', label: 'Water System Sanitize', icon: 'water-outline', interval: 180, color: '#3B82F6' },
  { id: 'propane', label: 'Propane System Check', icon: 'flame', interval: 365, color: '#C65D3B' },
  { id: 'brakes', label: 'Brake Inspection', icon: 'disc', interval: 15000, color: '#DC2626' },
  { id: 'generator', label: 'Generator Service', icon: 'flash', interval: 100, color: '#E8C5A5' },
];

export const theme = {
  colors,
  typography,
  spacing,
  borderRadius,
  shadows,
  blur,
  natureImages,
  profileImages,
  eventImages,
  mapColors,
  markerTypes,
  animations,
  brandColors,
  rigSpecs,
  maintenanceCategories,
};

// Compatibility exports for template components (capitalized versions)
// These map to the light/dark theme variants expected by useTheme hook
export const Colors = {
  light: {
    text: colors.bark[800],
    buttonText: colors.text.inverse,
    tabIconDefault: colors.bark[400],
    tabIconSelected: colors.ember[500],
    link: colors.ember[500],
    backgroundRoot: colors.background.primary,
    backgroundDefault: colors.background.secondary,
    backgroundSecondary: colors.background.tertiary,
    backgroundTertiary: colors.glass.white,
  },
  dark: {
    text: colors.text.inverse,
    buttonText: colors.text.inverse,
    tabIconDefault: colors.bark[400],
    tabIconSelected: colors.ember[400],
    link: colors.ember[400],
    backgroundRoot: '#1E1814',
    backgroundDefault: '#2A2620',
    backgroundSecondary: '#353129',
    backgroundTertiary: '#403C34',
  },
};

export const Spacing = {
  xs: spacing.xs,
  sm: spacing.sm,
  md: spacing.md,
  lg: spacing.lg,
  xl: spacing.xl,
  '2xl': spacing['2xl'],
  '3xl': spacing['3xl'],
  '4xl': spacing['4xl'],
  '5xl': spacing['5xl'],
  inputHeight: 48,
  buttonHeight: 52,
};

export const BorderRadius = {
  xs: borderRadius.sm,
  sm: borderRadius.base,
  md: borderRadius.md,
  lg: borderRadius.lg,
  xl: borderRadius.xl,
  '2xl': borderRadius['2xl'],
  '3xl': borderRadius['3xl'],
  full: borderRadius.full,
};

export const Typography = {
  h1: {
    fontSize: typography.fontSize['4xl'],
    lineHeight: 44,
    fontWeight: '700' as const,
    fontFamily: typography.fontFamily.heading,
  },
  h2: {
    fontSize: typography.fontSize['3xl'],
    lineHeight: 36,
    fontWeight: '700' as const,
    fontFamily: typography.fontFamily.heading,
  },
  h3: {
    fontSize: typography.fontSize['2xl'],
    lineHeight: 32,
    fontWeight: '600' as const,
    fontFamily: typography.fontFamily.heading,
  },
  h4: {
    fontSize: typography.fontSize.xl,
    lineHeight: 28,
    fontWeight: '600' as const,
    fontFamily: typography.fontFamily.bodySemiBold,
  },
  body: {
    fontSize: typography.fontSize.base,
    lineHeight: 24,
    fontWeight: '400' as const,
    fontFamily: typography.fontFamily.body,
  },
  small: {
    fontSize: typography.fontSize.sm,
    lineHeight: 20,
    fontWeight: '400' as const,
    fontFamily: typography.fontFamily.body,
  },
  link: {
    fontSize: typography.fontSize.base,
    lineHeight: 24,
    fontWeight: '500' as const,
    fontFamily: typography.fontFamily.bodyMedium,
  },
};

export default theme;
