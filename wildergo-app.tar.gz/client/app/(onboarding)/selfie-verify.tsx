import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Animated,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows, natureImages } from '@/constants/theme';
import { Button } from '@/components/ui/Button';
import { GlassCard } from '@/components/ui/GlassCard';

const { width, height } = Dimensions.get('window');

export default function SelfieVerifyScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [selfiePhoto, setSelfiePhoto] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const backgroundScale = useRef(new Animated.Value(1.1)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const scanLineAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(backgroundScale, {
        toValue: 1.05,
        duration: 20000,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();
  }, [fadeAnim, slideAnim, backgroundScale]);

  // Pulse animation for camera icon
  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, [pulseAnim]);

  // Scanning animation
  useEffect(() => {
    if (verifying) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(scanLineAnim, {
            toValue: 1,
            duration: 1500,
            useNativeDriver: true,
          }),
          Animated.timing(scanLineAnim, {
            toValue: 0,
            duration: 0,
            useNativeDriver: true,
          }),
        ])
      ).start();
    }
  }, [verifying, scanLineAnim]);

  const handleTakePhoto = (type: 'profile' | 'selfie') => {
    // Simulate photo capture - in production, use expo-image-picker
    if (type === 'profile') {
      setProfilePhoto('placeholder');
    } else {
      setSelfiePhoto('placeholder');
    }
  };

  const handleComplete = async () => {
    setVerifying(true);
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2500));
    setVerifying(false);
    router.push('/(onboarding)/complete');
    setLoading(false);
  };

  return (
    <View style={styles.container}>
      {/* Full-Screen Background Image */}
      <Animated.View
        style={[
          styles.backgroundContainer,
          { transform: [{ scale: backgroundScale }] },
        ]}
      >
        <Image
          source={{ uri: natureImages.mistyForest }}
          style={styles.backgroundImage}
          contentFit="cover"
          transition={800}
        />
      </Animated.View>

      {/* Gradient Overlay */}
      <LinearGradient
        colors={[
          'rgba(0, 0, 0, 0.4)',
          'rgba(0, 0, 0, 0.5)',
          'rgba(30, 24, 20, 0.9)',
          'rgba(30, 24, 20, 1)',
        ]}
        locations={[0, 0.2, 0.6, 1]}
        style={styles.gradient}
      />

      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + spacing.lg, paddingBottom: insets.bottom + spacing.xl },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Ionicons name="arrow-back" size={24} color={colors.text.inverse} />
        </TouchableOpacity>

        {/* Progress Indicator */}
        <View style={styles.progressContainer}>
          <View style={[styles.progressBar, styles.progressActive]} />
          <View style={[styles.progressBar, styles.progressActive]} />
          <View style={[styles.progressBar, styles.progressActive]} />
          <View style={[styles.progressBar, styles.progressActive]} />
          <View style={styles.progressBar} />
        </View>
        <Text style={styles.stepLabel}>Step 4 of 5 • Photo Verification</Text>

        {/* Title Section */}
        <Animated.View
          style={[
            styles.titleSection,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.titleIconContainer}>
            <Ionicons name="shield-checkmark" size={36} color={colors.moss[400]} />
          </View>
          <Text style={styles.title}>Photo Verification</Text>
          <Text style={styles.subtitle}>
            Help us keep the community safe. We&apos;ll compare your profile photo with a live selfie.
          </Text>
        </Animated.View>

        {/* Photo Comparison Section */}
        <Animated.View
          style={[
            styles.photoSection,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <GlassCard variant="frost" padding="lg" style={styles.photoCard}>
            <View style={styles.photoGrid}>
              {/* Profile Photo */}
              <View style={styles.photoColumn}>
                <TouchableOpacity
                  style={[
                    styles.photoBox,
                    profilePhoto && styles.photoBoxFilled,
                  ]}
                  onPress={() => handleTakePhoto('profile')}
                >
                  {profilePhoto ? (
                    <View style={styles.photoPlaceholder}>
                      <View style={styles.photoCheckmark}>
                        <Ionicons name="checkmark-circle" size={32} color={colors.moss[500]} />
                      </View>
                      <Ionicons name="person" size={44} color={colors.moss[400]} />
                    </View>
                  ) : (
                    <>
                      <View style={styles.photoIconWrapper}>
                        <Ionicons name="image" size={28} color={colors.moss[400]} />
                      </View>
                      <Text style={styles.photoHint}>Add Photo</Text>
                    </>
                  )}
                  {verifying && !profilePhoto && (
                    <Animated.View
                      style={[
                        styles.scanLine,
                        {
                          transform: [
                            {
                              translateY: scanLineAnim.interpolate({
                                inputRange: [0, 1],
                                outputRange: [0, 120],
                              }),
                            },
                          ],
                        },
                      ]}
                    />
                  )}
                </TouchableOpacity>
                <Text style={styles.photoLabel}>Profile Photo</Text>
              </View>

              {/* Comparison Icon */}
              <View style={styles.comparisonContainer}>
                <View style={styles.comparisonLine} />
                <View style={styles.comparisonIcon}>
                  <Ionicons
                    name={profilePhoto && selfiePhoto ? 'checkmark' : 'swap-horizontal'}
                    size={18}
                    color={profilePhoto && selfiePhoto ? colors.moss[500] : colors.bark[400]}
                  />
                </View>
                <View style={styles.comparisonLine} />
              </View>

              {/* Live Selfie */}
              <View style={styles.photoColumn}>
                <TouchableOpacity
                  style={[
                    styles.photoBox,
                    selfiePhoto && styles.photoBoxFilled,
                  ]}
                  onPress={() => handleTakePhoto('selfie')}
                >
                  {selfiePhoto ? (
                    <View style={styles.photoPlaceholder}>
                      <View style={styles.photoCheckmark}>
                        <Ionicons name="checkmark-circle" size={32} color={colors.moss[500]} />
                      </View>
                      <Ionicons name="happy" size={44} color={colors.moss[400]} />
                    </View>
                  ) : (
                    <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
                      <View style={styles.photoIconWrapper}>
                        <Ionicons name="camera" size={28} color={colors.ember[400]} />
                      </View>
                      <Text style={[styles.photoHint, { color: colors.ember[500] }]}>Take Selfie</Text>
                    </Animated.View>
                  )}
                  {verifying && selfiePhoto && (
                    <Animated.View
                      style={[
                        styles.scanLine,
                        {
                          transform: [
                            {
                              translateY: scanLineAnim.interpolate({
                                inputRange: [0, 1],
                                outputRange: [0, 120],
                              }),
                            },
                          ],
                        },
                      ]}
                    />
                  )}
                </TouchableOpacity>
                <Text style={styles.photoLabel}>Live Selfie</Text>
              </View>
            </View>
          </GlassCard>
        </Animated.View>

        {/* Verification Tips */}
        <Animated.View
          style={[
            styles.tipsSection,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <GlassCard variant="light" padding="md" style={styles.tipsCard}>
            <Text style={styles.tipsTitle}>Quick Tips</Text>
            <View style={styles.tipsContainer}>
              <View style={styles.tipRow}>
                <View style={[styles.tipIcon, { backgroundColor: colors.driftwood[500] + '20' }]}>
                  <Ionicons name="sunny" size={16} color={colors.driftwood[500]} />
                </View>
                <Text style={styles.tipText}>Good lighting helps</Text>
              </View>
              <View style={styles.tipRow}>
                <View style={[styles.tipIcon, { backgroundColor: colors.moss[500] + '20' }]}>
                  <Ionicons name="eye" size={16} color={colors.moss[500]} />
                </View>
                <Text style={styles.tipText}>Face the camera directly</Text>
              </View>
              <View style={styles.tipRow}>
                <View style={[styles.tipIcon, { backgroundColor: colors.ember[500] + '20' }]}>
                  <Ionicons name="glasses" size={16} color={colors.ember[500]} />
                </View>
                <Text style={styles.tipText}>Remove sunglasses</Text>
              </View>
            </View>
          </GlassCard>
        </Animated.View>

        {/* Take Selfie CTA */}
        <View style={styles.ctaSection}>
          <Button
            title={selfiePhoto ? 'Retake Selfie' : 'Take Selfie'}
            onPress={() => handleTakePhoto('selfie')}
            variant="primary"
            size="lg"
            fullWidth
            icon={<Ionicons name="camera" size={20} color={colors.text.inverse} />}
          />
        </View>

        {/* Privacy Notice */}
        <GlassCard variant="light" padding="md" style={styles.privacyCard}>
          <View style={styles.privacyContent}>
            <View style={styles.privacyIconContainer}>
              <Ionicons name="shield-checkmark" size={20} color={colors.moss[500]} />
            </View>
            <Text style={styles.privacyText}>
              Your photos are encrypted and used only for verification. They won&apos;t be shared or stored after verification.
            </Text>
          </View>
        </GlassCard>

        {/* Complete Button */}
        <View style={styles.completeSection}>
          <Button
            title={verifying ? 'Verifying...' : 'Complete Verification'}
            onPress={handleComplete}
            variant="ember"
            size="lg"
            fullWidth
            loading={loading}
            disabled={!profilePhoto || !selfiePhoto}
            icon={!loading ? <Ionicons name="checkmark-circle" size={20} color={colors.text.inverse} /> : undefined}
            iconPosition="right"
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1E1814',
  },
  backgroundContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  backgroundImage: {
    width: width,
    height: height,
  },
  gradient: {
    ...StyleSheet.absoluteFillObject,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: spacing.xl,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.full,
    backgroundColor: colors.glass.whiteMedium,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.glass,
  },
  progressContainer: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.xl,
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: colors.glass.whiteLight,
    borderRadius: borderRadius.full,
  },
  progressActive: {
    backgroundColor: colors.ember[500],
  },
  stepLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.bark[200],
    marginTop: spacing.md,
  },
  titleSection: {
    alignItems: 'center',
    marginTop: spacing.xl,
    marginBottom: spacing.xl,
  },
  titleIconContainer: {
    width: 72,
    height: 72,
    borderRadius: borderRadius.pill,
    backgroundColor: colors.glass.whiteMedium,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.lg,
    ...shadows.glassFloat,
  },
  title: {
    fontSize: typography.fontSize['2xl'],
    fontWeight: '700',
    color: colors.text.inverse,
    marginBottom: spacing.sm,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  subtitle: {
    fontSize: typography.fontSize.base,
    color: colors.bark[200],
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: spacing.md,
  },
  photoSection: {
    marginBottom: spacing.lg,
  },
  photoCard: {
    borderRadius: borderRadius['2xl'],
  },
  photoGrid: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  photoColumn: {
    flex: 1,
    alignItems: 'center',
  },
  comparisonContainer: {
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
  },
  comparisonLine: {
    width: 1,
    height: 20,
    backgroundColor: colors.glass.border,
  },
  comparisonIcon: {
    width: 32,
    height: 32,
    borderRadius: borderRadius.full,
    backgroundColor: colors.glass.whiteSubtle,
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: spacing.xs,
  },
  photoBox: {
    width: '100%',
    aspectRatio: 0.85,
    backgroundColor: colors.glass.whiteSubtle,
    borderRadius: borderRadius.xl,
    borderWidth: 2,
    borderStyle: 'dashed',
    borderColor: colors.moss[400],
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.sm,
    overflow: 'hidden',
  },
  photoBoxFilled: {
    borderStyle: 'solid',
    borderColor: colors.moss[500],
    backgroundColor: colors.moss[500] + '15',
  },
  photoPlaceholder: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  photoCheckmark: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
  },
  photoIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.glass.whiteMedium,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  photoHint: {
    fontSize: typography.fontSize.sm,
    color: colors.moss[600],
    fontWeight: '500',
    textAlign: 'center',
  },
  photoLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.bark[300],
    fontWeight: '500',
  },
  scanLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: colors.ember[400],
    shadowColor: colors.ember[400],
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  tipsSection: {
    marginBottom: spacing.lg,
  },
  tipsCard: {
    borderRadius: borderRadius.xl,
  },
  tipsTitle: {
    fontSize: typography.fontSize.md,
    fontWeight: '600',
    color: colors.bark[700],
    marginBottom: spacing.md,
  },
  tipsContainer: {
    gap: spacing.sm,
  },
  tipRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tipIcon: {
    width: 32,
    height: 32,
    borderRadius: borderRadius.md,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  tipText: {
    fontSize: typography.fontSize.sm,
    color: colors.bark[600],
    fontWeight: '500',
  },
  ctaSection: {
    marginBottom: spacing.lg,
  },
  privacyCard: {
    marginBottom: spacing.lg,
    borderRadius: borderRadius.xl,
  },
  privacyContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  privacyIconContainer: {
    width: 36,
    height: 36,
    borderRadius: borderRadius.md,
    backgroundColor: colors.moss[500] + '15',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  privacyText: {
    flex: 1,
    fontSize: typography.fontSize.sm,
    color: colors.bark[500],
    lineHeight: 20,
  },
  completeSection: {
    marginTop: 'auto',
    paddingBottom: spacing.lg,
  },
});
