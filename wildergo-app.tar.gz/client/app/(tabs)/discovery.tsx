/**
 * WilderGo Discovery Screen
 * Strict mode separation with mode-specific profile cards
 * Dating 💕: Route-synced romantic connections
 * Friends 🏔️: Activity-aligned companions
 * Builder 🔧: Professional directory (no swiping)
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  Animated,
  PanResponder,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { useRouter } from '@/hooks/useRouterCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows, profileImages, eventImages, natureImages } from '@/constants/theme';
import { ModeToggle } from '@/components/ui/ModeToggle';
import { NatureBackground } from '@/components/ui/NatureBackground';
import { GlassCard } from '@/components/ui/GlassCard';
import { Button } from '@/components/ui/Button';
import { Logo } from '@/components/ui/Logo';
import { useMode, AppMode } from '@/contexts/ModeContext';
import { DatingProfileCard } from '@/components/profiles/DatingProfileCard';
import { FriendsProfileCard } from '@/components/profiles/FriendsProfileCard';
import { BuilderProfileCard, BuilderCompactCard } from '@/components/profiles/BuilderProfileCard';
import { GhostModeStatus } from '@/components/settings/GhostModeToggle';
import { ConvoyPaywall } from '@/components/paywall/ConvoyPaywall';

const { width } = Dimensions.get('window');
const CARD_WIDTH = width - spacing.xl * 2;
const SWIPE_THRESHOLD = width * 0.15; // Reduced from 25% to 15% for easier swiping
const SWIPE_VELOCITY_THRESHOLD = 0.3; // Quick flicks trigger swipe even with less distance

// Mode-specific data interfaces
interface DatingProfile {
  id: string;
  name: string;
  age: number;
  imageUrl: string;
  currentLocation: string;
  nextDestination: string;
  arrivalDate: string;
  travelTimeline: string;
  routeOverlap: number;
  rigType: string;
  interests: string[];
  bio?: string;
  verified?: boolean;
  online?: boolean;
}

interface FriendsProfile {
  id: string;
  name: string;
  age?: number;
  imageUrl: string;
  currentLocation: string;
  rigType: string;
  interests: string[];
  availableFor: string[];
  bio?: string;
  online?: boolean;
  verified?: boolean;
  travelStyle?: string;
  pets?: string;
}

interface BuilderProfile {
  id: string;
  name: string;
  businessName: string;
  imageUrl: string;
  location: string;
  rating: number;
  reviewCount: number;
  verified: boolean;
  expertise: string[];
  specialties: { name: string; icon: keyof typeof Ionicons.glyphMap }[];
  consultationRate: number;
  portfolioImages: string[];
  bio?: string;
  certifications?: string[];
}

// Dating Mode Profiles - Route Synchronization focus
const datingProfiles: DatingProfile[] = [
  {
    id: '1',
    name: 'Alex',
    age: 28,
    currentLocation: 'Moab, UT',
    nextDestination: 'Glacier National Park',
    arrivalDate: 'Aug 15',
    travelTimeline: 'Slow traveling north through summer',
    routeOverlap: 85,
    rigType: "'98 Sprinter",
    interests: ['Hiking', 'Coffee', 'Photography'],
    imageUrl: profileImages.alex,
    bio: 'Full-time nomad chasing sunsets and good coffee. Always down for a sunrise hike!',
    online: true,
    verified: true,
  },
  {
    id: '2',
    name: 'Jordan',
    age: 32,
    currentLocation: 'Sedona, AZ',
    nextDestination: 'Big Sur, CA',
    arrivalDate: 'Sept 1',
    travelTimeline: 'Following the coast this fall',
    routeOverlap: 42,
    rigType: 'Promaster',
    interests: ['Yoga', 'Climbing', 'Cooking'],
    imageUrl: profileImages.jordan,
    bio: 'Remote yoga instructor exploring the west coast. Love cooking over campfires.',
    online: true,
    verified: true,
  },
  {
    id: '3',
    name: 'Sam',
    age: 26,
    currentLocation: 'Joshua Tree, CA',
    nextDestination: 'Pacific Northwest',
    arrivalDate: 'Aug 20',
    travelTimeline: 'Chasing music festivals this season',
    routeOverlap: 28,
    rigType: 'Skoolie',
    interests: ['Music', 'Surfing', 'Stargazing'],
    imageUrl: profileImages.sam,
    bio: 'Musician on wheels. Catch me playing at campfire jams!',
    online: false,
    verified: false,
  },
];

// Friends Mode Profiles - Activity Alignment focus
const friendsProfiles: FriendsProfile[] = [
  {
    id: '1',
    name: 'Alex',
    imageUrl: profileImages.alex,
    currentLocation: 'Moab, UT',
    rigType: 'Sprinter Van',
    interests: ['Hiking', 'Photography', 'Coffee'],
    availableFor: ['Hiking', 'Coffee', 'Stargazing'],
    bio: 'Always up for adventure! Looking for hiking buddies and campfire hangs.',
    online: true,
    verified: true,
    pets: '🐕 Luna',
  },
  {
    id: '2',
    name: 'Jordan',
    imageUrl: profileImages.jordan,
    currentLocation: 'Sedona, AZ',
    rigType: 'Promaster',
    interests: ['Yoga', 'Climbing', 'Cooking'],
    availableFor: ['Climbing', 'Co-working', 'Convoy'],
    bio: 'Looking for climbing partners and convoy buddies heading to California.',
    online: true,
    verified: true,
    travelStyle: 'Slow traveler',
  },
  {
    id: '3',
    name: 'Sam',
    imageUrl: profileImages.sam,
    currentLocation: 'Joshua Tree, CA',
    rigType: 'Skoolie',
    interests: ['Music', 'Surfing', 'Stargazing'],
    availableFor: ['Music', 'Camping', 'Photography'],
    bio: 'Campfire jams are my thing. Bring your instruments!',
    online: false,
    verified: false,
  },
];

// Builder Mode Profiles - Professional Directory
const builderProfiles: BuilderProfile[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    businessName: "Sarah's Solar Systems",
    imageUrl: profileImages.sarah,
    location: 'Denver, CO',
    rating: 4.9,
    reviewCount: 47,
    verified: true,
    expertise: ['Solar Installation', 'Battery Systems', 'Electrical'],
    specialties: [
      { name: 'Solar', icon: 'sunny' },
      { name: 'Lithium', icon: 'battery-charging' },
      { name: 'Off-Grid', icon: 'flash' },
    ],
    consultationRate: 75,
    portfolioImages: [natureImages.vanInterior, eventImages.bonfire],
    bio: '15 years electrical experience. Specialized in complete off-grid solar systems for van conversions.',
    certifications: ['NABCEP Certified', 'Licensed Electrician'],
  },
  {
    id: '2',
    name: 'Mike Thompson',
    businessName: 'VanTech Conversions',
    imageUrl: profileImages.mike,
    location: 'Portland, OR',
    rating: 4.8,
    reviewCount: 32,
    verified: true,
    expertise: ['Full Builds', 'Custom Cabinetry', 'Insulation'],
    specialties: [
      { name: 'Full Build', icon: 'construct' },
      { name: 'Woodwork', icon: 'cube' },
      { name: 'Design', icon: 'color-palette' },
    ],
    consultationRate: 100,
    portfolioImages: [natureImages.vanInterior],
    bio: 'Complete van conversions from bare metal to move-in ready. Custom designs that maximize your space.',
  },
];

export default function DiscoveryScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { mode, setMode, theme, isPremium, isModeAllowed } = useMode();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showPaywall, setShowPaywall] = useState(false);

  // Ember glow animation for route overlap
  const glowAnim = useRef(new Animated.Value(0.3)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // Glow pulsing animation
    Animated.loop(
      Animated.sequence([
        Animated.parallel([
          Animated.timing(glowAnim, {
            toValue: 0.6,
            duration: 1500,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1.1,
            duration: 1500,
            useNativeDriver: true,
          }),
        ]),
        Animated.parallel([
          Animated.timing(glowAnim, {
            toValue: 0.3,
            duration: 1500,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1500,
            useNativeDriver: true,
          }),
        ]),
      ])
    ).start();
  }, [glowAnim, pulseAnim]);

  const position = useRef(new Animated.ValueXY()).current;
  const rotate = position.x.interpolate({
    inputRange: [-width / 2, 0, width / 2],
    outputRange: ['-10deg', '0deg', '10deg'],
    extrapolate: 'clamp',
  });

  const likeOpacity = position.x.interpolate({
    inputRange: [0, width / 4],
    outputRange: [0, 1],
    extrapolate: 'clamp',
  });

  const nopeOpacity = position.x.interpolate({
    inputRange: [-width / 4, 0],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  const nextCardScale = position.x.interpolate({
    inputRange: [-width / 2, 0, width / 2],
    outputRange: [1, 0.92, 1],
    extrapolate: 'clamp',
  });

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderMove: (_, gestureState) => {
        position.setValue({ x: gestureState.dx, y: gestureState.dy });
      },
      onPanResponderRelease: (_, gestureState) => {
        // Check velocity first - quick flicks work even with less distance
        const isQuickSwipeRight = gestureState.vx > SWIPE_VELOCITY_THRESHOLD;
        const isQuickSwipeLeft = gestureState.vx < -SWIPE_VELOCITY_THRESHOLD;
        
        if (gestureState.dx > SWIPE_THRESHOLD || isQuickSwipeRight) {
          swipeRight();
        } else if (gestureState.dx < -SWIPE_THRESHOLD || isQuickSwipeLeft) {
          swipeLeft();
        } else {
          resetPosition();
        }
      },
    })
  ).current;

  const swipeRight = () => {
    if (mode === 'dating' && !isModeAllowed('swipe')) {
      resetPosition();
      setShowPaywall(true);
      return;
    }

    Animated.timing(position, {
      toValue: { x: width + 100, y: 0 },
      duration: 200, // Faster animation for snappier feel
      useNativeDriver: false,
    }).start(() => onSwipeComplete('like'));
  };

  const swipeLeft = () => {
    Animated.timing(position, {
      toValue: { x: -width - 100, y: 0 },
      duration: 200, // Faster animation for snappier feel
      useNativeDriver: false,
    }).start(() => onSwipeComplete('nope'));
  };

  const resetPosition = () => {
    Animated.spring(position, {
      toValue: { x: 0, y: 0 },
      tension: 80, // Higher tension = faster spring back
      friction: 8,
      useNativeDriver: false,
    }).start();
  };

  const onSwipeComplete = (_action: 'like' | 'nope') => {
    setCurrentIndex((prev) => prev + 1);
    position.setValue({ x: 0, y: 0 });
  };

  const handleModeChange = (newMode: AppMode) => {
    // Check if dating mode requires premium
    if (newMode === 'dating' && !isPremium) {
      setShowPaywall(true);
      return;
    }
    setMode(newMode);
    setCurrentIndex(0);
  };

  const getModeTitle = () => {
    switch (mode) {
      case 'dating':
        return 'Dating';
      case 'friends':
        return 'Friends';
      case 'builder':
        return 'Builders';
    }
  };

  const getBackgroundVariant = () => {
    switch (mode) {
      case 'dating':
        return 'sunset';
      case 'friends':
        return 'forest';
      case 'builder':
        return 'driftwood';
      default:
        return 'forest';
    }
  };

  // Get current profile based on mode
  const getCurrentDatingProfile = () => datingProfiles[currentIndex % datingProfiles.length];
  const getNextDatingProfile = () => datingProfiles[(currentIndex + 1) % datingProfiles.length];
  const getCurrentFriendsProfile = () => friendsProfiles[currentIndex % friendsProfiles.length];
  const getNextFriendsProfile = () => friendsProfiles[(currentIndex + 1) % friendsProfiles.length];

  // Render Dating Mode - Swipe cards with route overlap
  const renderDatingMode = () => {
    const currentProfile = getCurrentDatingProfile();
    const nextProfile = getNextDatingProfile();

    return (
      <>
        {/* Cards Stack */}
        <View style={styles.cardsContainer}>
          {/* Next Card (underneath) */}
          <Animated.View
            style={[
              styles.card,
              styles.nextCard,
              { transform: [{ scale: nextCardScale }] },
            ]}
          >
            <DatingProfileCard
              profile={nextProfile}
              compact
            />
          </Animated.View>

          {/* Current Card (on top) */}
          <Animated.View
            style={[
              styles.card,
              {
                transform: [
                  { translateX: position.x },
                  { translateY: position.y },
                  { rotate },
                ],
              },
            ]}
            {...panResponder.panHandlers}
          >
            {/* Like Label */}
            <Animated.View
              style={[styles.labelContainer, styles.likeLabel, { opacity: likeOpacity }]}
            >
              <Text style={styles.likeLabelText}>MATCH</Text>
            </Animated.View>

            {/* Nope Label */}
            <Animated.View
              style={[styles.labelContainer, styles.nopeLabel, { opacity: nopeOpacity }]}
            >
              <Text style={[styles.labelText, { color: colors.clay[600] }]}>PASS</Text>
            </Animated.View>

            <DatingProfileCard
              profile={currentProfile}
              onLike={swipeRight}
              onPass={swipeLeft}
              onSuperLike={() => {}}
            />
          </Animated.View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={[styles.actionButton, styles.nopeButton]}
            onPress={swipeLeft}
          >
            <Ionicons name="close" size={28} color={colors.clay[500]} />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.superButton]}
            onPress={() => {}}
          >
            <Ionicons name="star" size={24} color={colors.ember[500]} />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.likeButton]}
            onPress={swipeRight}
          >
            <Ionicons name="heart" size={28} color={colors.ember[500]} />
          </TouchableOpacity>
        </View>
      </>
    );
  };

  // Render Friends Mode - Swipe cards with activity alignment
  const renderFriendsMode = () => {
    const currentProfile = getCurrentFriendsProfile();
    const nextProfile = getNextFriendsProfile();

    return (
      <>
        {/* Cards Stack */}
        <View style={styles.cardsContainer}>
          {/* Next Card (underneath) */}
          <Animated.View
            style={[
              styles.card,
              styles.nextCard,
              { transform: [{ scale: nextCardScale }] },
            ]}
          >
            <FriendsProfileCard
              profile={nextProfile}
            />
          </Animated.View>

          {/* Current Card (on top) */}
          <Animated.View
            style={[
              styles.card,
              {
                transform: [
                  { translateX: position.x },
                  { translateY: position.y },
                  { rotate },
                ],
              },
            ]}
            {...panResponder.panHandlers}
          >
            {/* Connect Label */}
            <Animated.View
              style={[styles.labelContainer, styles.likeLabel, { opacity: likeOpacity }]}
            >
              <Text style={[styles.likeLabelText, { color: colors.moss[500] }]}>CONNECT</Text>
            </Animated.View>

            {/* Pass Label */}
            <Animated.View
              style={[styles.labelContainer, styles.nopeLabel, { opacity: nopeOpacity }]}
            >
              <Text style={[styles.labelText, { color: colors.clay[600] }]}>PASS</Text>
            </Animated.View>

            <FriendsProfileCard
              profile={currentProfile}
              onConnect={swipeRight}
              onMessage={() => {}}
            />
          </Animated.View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={[styles.actionButton, styles.nopeButton]}
            onPress={swipeLeft}
          >
            <Ionicons name="close" size={28} color={colors.clay[500]} />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.messageButton]}
            onPress={() => {}}
          >
            <Ionicons name="chatbubble" size={22} color={colors.moss[500]} />
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, styles.connectButton]}
            onPress={swipeRight}
          >
            <Ionicons name="people" size={28} color={colors.moss[500]} />
          </TouchableOpacity>
        </View>
      </>
    );
  };

  // Render Builder Mode - Professional Directory (no swiping)
  const renderBuilderMode = () => {
    return (
      <ScrollView
        style={styles.builderScrollView}
        contentContainerStyle={[
          styles.builderScrollContent,
          { paddingBottom: insets.bottom + 100 }
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* AI Build Assistant Card */}
        <GlassCard variant="hud" padding="lg" style={styles.aiAssistantCard}>
          <View style={styles.hudCornerTL} />
          <View style={styles.hudCornerTR} />
          <View style={styles.hudCornerBL} />
          <View style={styles.hudCornerBR} />

          <View style={styles.aiHeader}>
            <View style={styles.aiIconContainer}>
              <Ionicons name="sparkles" size={32} color={colors.driftwood[400]} />
            </View>
            <View style={styles.aiStatusBadge}>
              <View style={styles.aiStatusDot} />
              <Text style={styles.aiStatusText}>ONLINE</Text>
            </View>
          </View>

          <Text style={styles.aiTitle}>AI Build Assistant</Text>
          <Text style={styles.aiDescription}>
            Get a personalized professional assessment for your rig build project
          </Text>

          <Button
            title="Start Build Assessment"
            onPress={() => router.push('/ai-assistant')}
            variant="ember"
            size="lg"
            fullWidth
            icon={<Ionicons name="sparkles" size={18} color={colors.text.inverse} />}
          />
        </GlassCard>

        {/* Vetted Builders Section */}
        <View style={styles.buildersSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Vetted Builders</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          {builderProfiles.map((builder) => (
            <BuilderProfileCard
              key={builder.id}
              profile={builder}
              onViewPortfolio={() => {}}
              onBookCall={() => {}}
              onMessage={() => {}}
            />
          ))}
        </View>

        {/* Quick Connect Section */}
        <View style={styles.quickConnectSection}>
          <Text style={styles.sectionTitle}>Quick Connect</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickConnectList}
          >
            {builderProfiles.map((builder) => (
              <BuilderCompactCard
                key={builder.id}
                profile={builder}
                onPress={() => {}}
              />
            ))}
          </ScrollView>
        </View>
      </ScrollView>
    );
  };

  return (
    <NatureBackground variant={getBackgroundVariant()} overlay overlayOpacity={0.35}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Glass Header with Logo */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Logo size="small" variant="light" />
            <Text style={styles.headerTitle}>{getModeTitle()}</Text>
          </View>
          <View style={styles.headerRight}>
            <GhostModeStatus onPress={() => setShowPaywall(true)} />
            <TouchableOpacity
              style={styles.aiButton}
              onPress={() => router.push('/ai-assistant')}
            >
              <Ionicons name="sparkles" size={20} color={theme.primary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Mode Toggle */}
        <View style={styles.toggleContainer}>
          <ModeToggle
            activeMode={mode}
            onModeChange={handleModeChange}
            showPremiumBadge={isPremium}
          />
        </View>

        {/* Mode-Specific Content */}
        {mode === 'dating' && renderDatingMode()}
        {mode === 'friends' && renderFriendsMode()}
        {mode === 'builder' && renderBuilderMode()}
      </View>

      {/* Premium Paywall */}
      <ConvoyPaywall
        visible={showPaywall}
        onClose={() => setShowPaywall(false)}
        onSubscribe={(success) => {
          if (success) {
            // Update premium status through context
          }
        }}
      />
    </NatureBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  headerTitle: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.text.inverse,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
    textTransform: 'uppercase',
    letterSpacing: typography.letterSpacing.wide,
  },
  aiButton: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.full,
    backgroundColor: colors.glass.whiteMedium,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.glass,
  },
  toggleContainer: {
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.lg,
  },
  cardsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
  },
  card: {
    position: 'absolute',
    width: CARD_WIDTH,
    left: (width - CARD_WIDTH) / 2,
    borderRadius: borderRadius['2xl'],
    overflow: 'hidden',
    ...shadows.glassFloat,
  },
  nextCard: {
    top: 10,
  },
  // Labels
  labelContainer: {
    position: 'absolute',
    top: 40,
    zIndex: 10,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.lg,
    borderWidth: 3,
    backgroundColor: colors.glass.whiteLight,
  },
  likeLabel: {
    right: 20,
    borderColor: colors.ember[500],
    transform: [{ rotate: '15deg' }],
  },
  nopeLabel: {
    left: 20,
    borderColor: colors.clay[500],
    transform: [{ rotate: '-15deg' }],
  },
  labelText: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    letterSpacing: typography.letterSpacing.wide,
  },
  likeLabelText: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.ember[500],
    letterSpacing: typography.letterSpacing.wide,
  },
  // Action Buttons
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.xl,
    gap: spacing.xl,
  },
  actionButton: {
    width: 60,
    height: 60,
    borderRadius: borderRadius.full,
    backgroundColor: colors.glass.whiteMedium,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    ...shadows.glass,
  },
  nopeButton: {
    borderColor: colors.clay[400] + '40',
  },
  superButton: {
    width: 48,
    height: 48,
    borderColor: colors.ember[400] + '40',
  },
  likeButton: {
    borderColor: colors.ember[400] + '40',
  },
  messageButton: {
    width: 48,
    height: 48,
    borderColor: colors.moss[400] + '40',
  },
  connectButton: {
    borderColor: colors.moss[400] + '40',
  },
  // Builder Mode Styles
  builderScrollView: {
    flex: 1,
  },
  builderScrollContent: {
    paddingHorizontal: spacing.xl,
    paddingTop: spacing.md,
  },
  aiAssistantCard: {
    marginBottom: spacing.xl,
    position: 'relative',
    overflow: 'hidden',
  },
  hudCornerTL: {
    position: 'absolute',
    top: 8,
    left: 8,
    width: 16,
    height: 16,
    borderLeftWidth: 2,
    borderTopWidth: 2,
    borderColor: colors.driftwood[400],
    opacity: 0.6,
  },
  hudCornerTR: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 16,
    height: 16,
    borderRightWidth: 2,
    borderTopWidth: 2,
    borderColor: colors.driftwood[400],
    opacity: 0.6,
  },
  hudCornerBL: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    width: 16,
    height: 16,
    borderLeftWidth: 2,
    borderBottomWidth: 2,
    borderColor: colors.driftwood[400],
    opacity: 0.6,
  },
  hudCornerBR: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    width: 16,
    height: 16,
    borderRightWidth: 2,
    borderBottomWidth: 2,
    borderColor: colors.driftwood[400],
    opacity: 0.6,
  },
  aiHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.lg,
  },
  aiIconContainer: {
    width: 64,
    height: 64,
    borderRadius: borderRadius.xl,
    backgroundColor: colors.driftwood[500] + '15',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.driftwood[400] + '30',
  },
  aiStatusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.moss[500] + '20',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.moss[400] + '30',
  },
  aiStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.moss[400],
    marginRight: spacing.xs,
  },
  aiStatusText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodyBold,
    color: colors.moss[400],
    letterSpacing: 1,
  },
  aiTitle: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[200],
    marginBottom: spacing.sm,
  },
  aiDescription: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    marginBottom: spacing.lg,
    lineHeight: 22,
  },
  buildersSection: {
    marginBottom: spacing.xl,
    gap: spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontFamily: typography.fontFamily.heading,
    color: colors.text.inverse,
    textShadowColor: 'rgba(0,0,0,0.2)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
    textTransform: 'uppercase',
    letterSpacing: typography.letterSpacing.wide,
  },
  viewAllText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.driftwood[400],
  },
  quickConnectSection: {
    marginBottom: spacing.xl,
  },
  quickConnectList: {
    paddingTop: spacing.md,
    gap: spacing.md,
  },
});
