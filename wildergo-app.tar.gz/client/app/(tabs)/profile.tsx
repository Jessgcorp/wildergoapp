/**
 * WilderGo Nomad Passport Profile Screen
 * Premium profile experience with:
 * - Rig Specs Editor
 * - Travel History
 * - Privacy Vault (Live Pin vs Ghost Mode)
 * - Maintenance Tracker
 * - Private Journal
 * - AI Build Assistant
 */

import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Animated,
  Platform,
  Modal,
} from 'react-native';
import { useRouter } from '@/hooks/useRouterCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'expo-image';
import { colors, typography, spacing, borderRadius, shadows, profileImages } from '@/constants/theme';
import { GlassCard } from '@/components/ui/GlassCard';
import { NatureBackground } from '@/components/ui/NatureBackground';
import { Button } from '@/components/ui/Button';
import { Logo } from '@/components/ui/Logo';
import { useMode } from '@/contexts/ModeContext';
import { RigSpecsEditor } from '@/components/passport/RigSpecsEditor';
import { TravelHistory } from '@/components/passport/TravelHistory';
import { MaintenanceTracker } from '@/components/passport/MaintenanceTracker';
import { NomadJournal } from '@/components/passport/NomadJournal';
import { RigSpecifications } from '@/services/passport/nomadPassportService';

// Mock user data
const mockUser = {
  id: 'user-1',
  name: 'Alex Nomad',
  avatar: profileImages.alex,
  rigName: 'Wanderlust Express',
  rigType: '2019 Mercedes Sprinter 144',
  memberSince: '2023',
  verified: true,
  premium: true,
  stats: {
    connections: 127,
    convoys: 12,
    daysOnRoad: 89,
    statesVisited: 24,
    milesTracked: 15420,
  },
};

// Mock rig specs
const mockRigSpecs: RigSpecifications = {
  id: 'rig-1',
  userId: 'user-1',
  rigName: 'Wanderlust Express',
  rigType: '2019 Mercedes Sprinter 144',
  year: 2019,
  solarWattage: 400,
  batteryCapacity: 300,
  batteryType: 'lithium',
  hasShorepower: true,
  hasGenerator: true,
  generatorType: 'Honda 2000',
  freshWaterCapacity: 40,
  greyWaterCapacity: 30,
  blackWaterCapacity: 0,
  hasWaterFilter: true,
  hasWaterHeater: true,
  connectivityType: 'starlink',
  starlinkActive: true,
  hasBooster: true,
  hasAC: true,
  acType: 'mini-split',
  hasHeater: true,
  heaterType: 'diesel',
  sleeps: 2,
  hasKitchen: true,
  hasBathroom: true,
  lastUpdated: new Date().toISOString(),
};

// Passport sections
type PassportSection = 'overview' | 'rig-specs' | 'travel-history' | 'maintenance' | 'journal';

export default function ProfileScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { isGhostMode, toggleGhostMode, isPremium, setPremium } = useMode();

  const [activeSection, setActiveSection] = useState<PassportSection>('overview');
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [rigSpecs, setRigSpecs] = useState<RigSpecifications>(mockRigSpecs);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [isSignedOut, setIsSignedOut] = useState(false);

  // HUD animation
  const hudGlowAnim = useRef(new Animated.Value(0.3)).current;
  const scanLineAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    // Glow animation for HUD
    Animated.loop(
      Animated.sequence([
        Animated.timing(hudGlowAnim, {
          toValue: 0.6,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(hudGlowAnim, {
          toValue: 0.3,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Scan line animation
    Animated.loop(
      Animated.timing(scanLineAnim, {
        toValue: 1,
        duration: 3000,
        useNativeDriver: true,
      })
    ).start();

    // Pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, [hudGlowAnim, scanLineAnim, pulseAnim]);

  // Section Navigation
  const sections: { key: PassportSection; icon: keyof typeof Ionicons.glyphMap; label: string }[] = [
    { key: 'overview', icon: 'person', label: 'Overview' },
    { key: 'rig-specs', icon: 'car-sport', label: 'Rig Specs' },
    { key: 'travel-history', icon: 'map', label: 'Travel' },
    { key: 'maintenance', icon: 'construct', label: 'Maintenance' },
    { key: 'journal', icon: 'book', label: 'Journal' },
  ];

  const SettingsButtonContent = () => (
    <Ionicons name="settings-outline" size={22} color={colors.bark[700]} />
  );

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'rig-specs':
        return (
          <RigSpecsEditor
            specs={rigSpecs}
            onSave={(updatedSpecs) => setRigSpecs(prev => ({ ...prev, ...updatedSpecs }))}
          />
        );
      case 'travel-history':
        return (
          <TravelHistory
            userId={mockUser.id}
            onSpotPress={(spot) => {
              console.log('View spot:', spot);
            }}
            onAddSpot={() => {
              console.log('Add spot');
            }}
          />
        );
      case 'maintenance':
        return (
          <MaintenanceTracker
            rigId="rig-1"
            currentMileage={mockUser.stats.milesTracked}
          />
        );
      case 'journal':
        return (
          <NomadJournal
            userId={mockUser.id}
            currentLocation={{
              latitude: 38.5733,
              longitude: -109.5498,
              name: 'Moab, UT',
            }}
          />
        );
      default:
        return renderOverview();
    }
  };

  const renderOverview = () => (
    <>
      {/* Profile Header Card */}
      <GlassCard variant="frost" padding="lg" style={styles.profileHeaderCard}>
        <View style={styles.profileHeader}>
          <View style={styles.profileAvatarContainer}>
            {mockUser.avatar ? (
              <Image source={{ uri: mockUser.avatar }} style={styles.profileAvatar} />
            ) : (
              <View style={[styles.profileAvatar, styles.profileAvatarPlaceholder]}>
                <Ionicons name="person" size={36} color={colors.burntSienna[500]} />
              </View>
            )}
            {mockUser.verified && (
              <View style={styles.verifiedBadge}>
                <Ionicons name="shield-checkmark" size={12} color={colors.text.inverse} />
              </View>
            )}
            <View style={styles.onlineIndicator} />
          </View>

          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{mockUser.name}</Text>
            <Text style={styles.profileRig}>{mockUser.rigType}</Text>
            <View style={styles.profileBadges}>
              {mockUser.premium && (
                <View style={styles.premiumBadge}>
                  <Ionicons name="diamond" size={10} color={colors.text.inverse} />
                  <Text style={styles.premiumBadgeText}>Premium</Text>
                </View>
              )}
              <View style={styles.memberBadge}>
                <Text style={styles.memberBadgeText}>Since {mockUser.memberSince}</Text>
              </View>
            </View>
          </View>

          {/* Privacy Status Button */}
          <TouchableOpacity
            style={[styles.privacyButton, isGhostMode && styles.privacyButtonActive]}
            onPress={() => setShowPrivacyModal(true)}
          >
            <Ionicons
              name={isGhostMode ? 'eye-off' : 'location'}
              size={18}
              color={isGhostMode ? colors.deepTeal[500] : colors.forestGreen[600]}
            />
          </TouchableOpacity>
        </View>

        {/* Stats Row */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{mockUser.stats.connections}</Text>
            <Text style={styles.statLabel}>Connections</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{mockUser.stats.convoys}</Text>
            <Text style={styles.statLabel}>Convoys</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{mockUser.stats.daysOnRoad}</Text>
            <Text style={styles.statLabel}>Days</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>{mockUser.stats.statesVisited}</Text>
            <Text style={styles.statLabel}>States</Text>
          </View>
        </View>
      </GlassCard>

      {/* Rig Quick Specs */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Rig at a Glance</Text>
        <TouchableOpacity onPress={() => setActiveSection('rig-specs')}>
          <Text style={styles.viewAllText}>Edit</Text>
        </TouchableOpacity>
      </View>

      <GlassCard variant="hud" padding="md" style={styles.rigQuickSpecs}>
        <View style={styles.hudCornerTL} />
        <View style={styles.hudCornerTR} />
        <View style={styles.hudCornerBL} />
        <View style={styles.hudCornerBR} />

        <View style={styles.specsGrid}>
          <View style={styles.specItem}>
            <Ionicons name="sunny" size={20} color={colors.sunsetOrange[500]} />
            <Text style={styles.specValue}>{rigSpecs.solarWattage}W</Text>
            <Text style={styles.specLabel}>Solar</Text>
          </View>
          <View style={styles.specItem}>
            <Ionicons name="battery-charging" size={20} color={colors.forestGreen[500]} />
            <Text style={styles.specValue}>{rigSpecs.batteryCapacity}Ah</Text>
            <Text style={styles.specLabel}>Battery</Text>
          </View>
          <View style={styles.specItem}>
            <Ionicons name="water" size={20} color={colors.deepTeal[500]} />
            <Text style={styles.specValue}>{rigSpecs.freshWaterCapacity}gal</Text>
            <Text style={styles.specLabel}>Water</Text>
          </View>
          <View style={styles.specItem}>
            <Ionicons name="wifi" size={20} color={colors.burntSienna[500]} />
            <Text style={styles.specValue}>
              {rigSpecs.connectivityType === 'starlink' ? 'Starlink' :
               rigSpecs.connectivityType === 'cellular' ? 'Cellular' :
               rigSpecs.connectivityType === 'both' ? 'Both' : 'None'}
            </Text>
            <Text style={styles.specLabel}>Internet</Text>
          </View>
        </View>
      </GlassCard>

      {/* AI Build Assistant */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>AI Assistant</Text>
      </View>

      <GlassCard variant="hud" padding="lg" style={styles.aiCard}>
        <View style={styles.hudCornerTL} />
        <View style={styles.hudCornerTR} />
        <View style={styles.hudCornerBL} />
        <View style={styles.hudCornerBR} />

        <Animated.View
          style={[
            styles.scanLine,
            {
              opacity: 0.3,
              transform: [
                {
                  translateY: scanLineAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, 200],
                  }),
                },
              ],
            },
          ]}
        />

        <View style={styles.aiHeader}>
          <View style={styles.aiIconContainer}>
            <Animated.View
              style={[styles.aiIconGlow, { opacity: hudGlowAnim }]}
            />
            <Ionicons name="camera-outline" size={32} color={colors.forestGreen[500]} />
          </View>
          <View style={styles.aiStatusBadge}>
            <View style={styles.aiStatusDot} />
            <Text style={styles.aiStatusText}>ONLINE</Text>
          </View>
        </View>

        <Text style={styles.aiTitle}>Newell AI Vision</Text>
        <Text style={styles.aiDescription}>
          Snap a photo of any build issue for instant AI-powered analysis and recommendations.
        </Text>

        <View style={styles.aiFeatures}>
          <View style={styles.aiFeatureItem}>
            <Ionicons name="flash" size={16} color={colors.forestGreen[500]} />
            <Text style={styles.aiFeatureText}>Instant Analysis</Text>
          </View>
          <View style={styles.aiFeatureItem}>
            <Ionicons name="bulb" size={16} color={colors.forestGreen[500]} />
            <Text style={styles.aiFeatureText}>Smart Solutions</Text>
          </View>
          <View style={styles.aiFeatureItem}>
            <Ionicons name="hardware-chip" size={16} color={colors.forestGreen[500]} />
            <Text style={styles.aiFeatureText}>Part IDs</Text>
          </View>
        </View>

        <Button
          title="Analyze Issue with AI"
          onPress={() => router.push('/ai-assistant')}
          variant="ember"
          size="lg"
          fullWidth
          icon={<Ionicons name="sparkles" size={18} color={colors.text.inverse} />}
        />
      </GlassCard>

      {/* Quick Actions */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Nomad Passport</Text>
      </View>

      <View style={styles.quickActions}>
        <TouchableOpacity
          style={styles.quickActionCard}
          onPress={() => setActiveSection('travel-history')}
        >
          <GlassCard variant="medium" padding="md" style={styles.actionCardInner}>
            <LinearGradient
              colors={[colors.forestGreen[500] + '30', colors.forestGreen[600] + '15']}
              style={styles.actionIconBg}
            >
              <Ionicons name="map" size={24} color={colors.forestGreen[600]} />
            </LinearGradient>
            <Text style={styles.actionLabel}>Travel History</Text>
            <Text style={styles.actionSublabel}>{mockUser.stats.milesTracked.toLocaleString()} mi</Text>
          </GlassCard>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.quickActionCard}
          onPress={() => setActiveSection('maintenance')}
        >
          <GlassCard variant="medium" padding="md" style={styles.actionCardInner}>
            <LinearGradient
              colors={[colors.deepTeal[500] + '30', colors.deepTeal[600] + '15']}
              style={styles.actionIconBg}
            >
              <Ionicons name="construct" size={24} color={colors.deepTeal[600]} />
            </LinearGradient>
            <Text style={styles.actionLabel}>Maintenance</Text>
            <Text style={styles.actionSublabel}>HUD Tracker</Text>
          </GlassCard>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.quickActionCard}
          onPress={() => setActiveSection('journal')}
        >
          <GlassCard variant="medium" padding="md" style={styles.actionCardInner}>
            <LinearGradient
              colors={[colors.burntSienna[500] + '30', colors.burntSienna[600] + '15']}
              style={styles.actionIconBg}
            >
              <Ionicons name="book" size={24} color={colors.burntSienna[600]} />
            </LinearGradient>
            <Text style={styles.actionLabel}>Journal</Text>
            <Text style={styles.actionSublabel}>Private Notes</Text>
          </GlassCard>
        </TouchableOpacity>
      </View>

      {/* Settings Menu */}
      <GlassCard variant="light" padding="none" style={styles.settingsCard}>
        {[
          { icon: 'person-outline', label: 'Edit Profile', onPress: () => setShowEditProfileModal(true) },
          { icon: 'notifications-outline', label: 'Notifications', onPress: () => setShowNotificationsModal(true) },
          { icon: 'shield-outline', label: 'Privacy & Safety', onPress: () => setShowPrivacyModal(true) },
          { icon: 'help-circle-outline', label: 'Help & Support', onPress: () => setShowHelpModal(true) },
          { icon: 'log-out-outline', label: 'Sign Out', danger: true, onPress: () => setIsSignedOut(true) },
        ].map((item, index, arr) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.settingsItem,
              index < arr.length - 1 && styles.settingsItemBorder,
            ]}
            onPress={item.onPress}
          >
            <View style={[
              styles.settingsIconContainer,
              item.danger && styles.settingsIconDanger,
            ]}>
              <Ionicons
                name={item.icon as keyof typeof Ionicons.glyphMap}
                size={20}
                color={item.danger ? colors.sunsetOrange[500] : colors.bark[600]}
              />
            </View>
            <Text style={[styles.settingsLabel, item.danger && styles.dangerLabel]}>
              {item.label}
            </Text>
            <Ionicons name="chevron-forward" size={18} color={colors.bark[400]} />
          </TouchableOpacity>
        ))}
      </GlassCard>
    </>
  );

  return (
    <View style={[styles.cleanContainer, { paddingTop: insets.top }]}>
        {/* Header */}
        <View style={styles.header}>
          {activeSection !== 'overview' ? (
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => setActiveSection('overview')}
            >
              <Ionicons name="chevron-back" size={24} color="#2C2C2C" />
            </TouchableOpacity>
          ) : (
            <Logo size="small" variant="dark" />
          )}

          <Text style={styles.headerTitle}>
            {activeSection === 'overview' ? 'Nomad Passport' :
             activeSection === 'rig-specs' ? 'Rig Specs' :
             activeSection === 'travel-history' ? 'Travel History' :
             activeSection === 'maintenance' ? 'Maintenance' : 'Journal'}
          </Text>

          <TouchableOpacity style={styles.settingsButton}>
            {Platform.OS === 'ios' ? (
              <BlurView intensity={80} tint="light" style={styles.settingsBlur}>
                <SettingsButtonContent />
              </BlurView>
            ) : (
              <View style={[styles.settingsBlur, styles.settingsFallback]}>
                <SettingsButtonContent />
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Section Navigation - Compact Horizontal Tabs */}
        <View style={styles.sectionNav}>
          {sections.map((section) => (
            <TouchableOpacity
              key={section.key}
              style={[
                styles.sectionNavItem,
                activeSection === section.key && styles.sectionNavItemActive,
              ]}
              onPress={() => setActiveSection(section.key)}
            >
              <Ionicons
                name={section.icon}
                size={14}
                color={activeSection === section.key ? '#FFFFFF' : '#FF6B35'}
              />
              <Text style={[
                styles.sectionNavText,
                activeSection === section.key && styles.sectionNavTextActive,
              ]}>
                {section.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Content */}
        <ScrollView
          style={styles.scrollContainer}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingBottom: insets.bottom + 100 },
          ]}
          showsVerticalScrollIndicator={false}
        >
          {renderSectionContent()}
        </ScrollView>

        {/* Privacy Vault Modal */}
        <PrivacyVaultModal
          visible={showPrivacyModal}
          onClose={() => setShowPrivacyModal(false)}
          isGhostMode={isGhostMode}
          onToggleGhostMode={toggleGhostMode}
          isPremium={isPremium}
          onUpgrade={() => setPremium(true)}
        />

        {/* Edit Profile Modal */}
        <Modal
          visible={showEditProfileModal}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={() => setShowEditProfileModal(false)}
        >
          <View style={[modalStyles.container, { paddingBottom: insets.bottom }]}>
            <View style={modalStyles.header}>
              <Text style={modalStyles.title}>Edit Profile</Text>
              <TouchableOpacity onPress={() => setShowEditProfileModal(false)}>
                <Ionicons name="close" size={24} color={colors.bark[600]} />
              </TouchableOpacity>
            </View>
            <ScrollView style={modalStyles.content} contentContainerStyle={modalStyles.scrollContent}>
              <View style={modalStyles.formSection}>
                <Text style={modalStyles.formLabel}>Display Name</Text>
                <View style={modalStyles.inputContainer}>
                  <Text style={modalStyles.inputText}>{mockUser.name}</Text>
                  <Ionicons name="pencil" size={18} color={colors.bark[400]} />
                </View>
              </View>
              <View style={modalStyles.formSection}>
                <Text style={modalStyles.formLabel}>Rig Name</Text>
                <View style={modalStyles.inputContainer}>
                  <Text style={modalStyles.inputText}>{mockUser.rigName}</Text>
                  <Ionicons name="pencil" size={18} color={colors.bark[400]} />
                </View>
              </View>
              <View style={modalStyles.formSection}>
                <Text style={modalStyles.formLabel}>Bio</Text>
                <View style={modalStyles.inputContainer}>
                  <Text style={modalStyles.inputText}>Living the nomad life...</Text>
                  <Ionicons name="pencil" size={18} color={colors.bark[400]} />
                </View>
              </View>
              <Button
                title="Save Changes"
                onPress={() => setShowEditProfileModal(false)}
                variant="ember"
                size="lg"
                fullWidth
                style={{ marginTop: spacing.xl }}
              />
            </ScrollView>
          </View>
        </Modal>

        {/* Notifications Modal */}
        <Modal
          visible={showNotificationsModal}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={() => setShowNotificationsModal(false)}
        >
          <View style={[modalStyles.container, { paddingBottom: insets.bottom }]}>
            <View style={modalStyles.header}>
              <Text style={modalStyles.title}>Notifications</Text>
              <TouchableOpacity onPress={() => setShowNotificationsModal(false)}>
                <Ionicons name="close" size={24} color={colors.bark[600]} />
              </TouchableOpacity>
            </View>
            <ScrollView style={modalStyles.content} contentContainerStyle={modalStyles.scrollContent}>
              {[
                { label: 'Convoy Invites', icon: 'people', enabled: true },
                { label: 'Message Alerts', icon: 'chatbubble', enabled: true },
                { label: 'Weather Warnings', icon: 'thunderstorm', enabled: true },
                { label: 'Maintenance Reminders', icon: 'construct', enabled: false },
                { label: 'Community Events', icon: 'calendar', enabled: true },
              ].map((item, idx) => (
                <View key={idx} style={modalStyles.notificationItem}>
                  <View style={modalStyles.notificationLeft}>
                    <Ionicons name={item.icon as any} size={20} color={colors.forestGreen[600]} />
                    <Text style={modalStyles.notificationLabel}>{item.label}</Text>
                  </View>
                  <View style={[modalStyles.toggle, item.enabled && modalStyles.toggleActive]}>
                    <View style={[modalStyles.toggleDot, item.enabled && modalStyles.toggleDotActive]} />
                  </View>
                </View>
              ))}
            </ScrollView>
          </View>
        </Modal>

        {/* Help & Support Modal */}
        <Modal
          visible={showHelpModal}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={() => setShowHelpModal(false)}
        >
          <View style={[modalStyles.container, { paddingBottom: insets.bottom }]}>
            <View style={modalStyles.header}>
              <Text style={modalStyles.title}>Help & Support</Text>
              <TouchableOpacity onPress={() => setShowHelpModal(false)}>
                <Ionicons name="close" size={24} color={colors.bark[600]} />
              </TouchableOpacity>
            </View>
            <ScrollView style={modalStyles.content} contentContainerStyle={modalStyles.scrollContent}>
              {[
                { label: 'Getting Started', icon: 'rocket', description: 'Learn the basics' },
                { label: 'FAQs', icon: 'help-circle', description: 'Common questions' },
                { label: 'Contact Support', icon: 'mail', description: 'Get in touch' },
                { label: 'Report a Bug', icon: 'bug', description: 'Help us improve' },
                { label: 'Community Guidelines', icon: 'document-text', description: 'Our rules' },
              ].map((item, idx) => (
                <TouchableOpacity key={idx} style={modalStyles.helpItem}>
                  <View style={modalStyles.helpIconContainer}>
                    <Ionicons name={item.icon as any} size={22} color={colors.forestGreen[600]} />
                  </View>
                  <View style={modalStyles.helpContent}>
                    <Text style={modalStyles.helpLabel}>{item.label}</Text>
                    <Text style={modalStyles.helpDescription}>{item.description}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color={colors.bark[400]} />
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </Modal>

        {/* Sign Out Confirmation Modal */}
        <Modal
          visible={isSignedOut}
          animationType="fade"
          transparent={true}
          onRequestClose={() => setIsSignedOut(false)}
        >
          <View style={modalStyles.signOutOverlay}>
            <View style={modalStyles.signOutCard}>
              <Ionicons name="log-out" size={48} color={colors.sunsetOrange[500]} />
              <Text style={modalStyles.signOutTitle}>Sign Out?</Text>
              <Text style={modalStyles.signOutDescription}>
                You will need to sign in again to access your Nomad Passport.
              </Text>
              <View style={modalStyles.signOutButtons}>
                <TouchableOpacity
                  style={modalStyles.signOutCancel}
                  onPress={() => setIsSignedOut(false)}
                >
                  <Text style={modalStyles.signOutCancelText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={modalStyles.signOutConfirm}
                  onPress={() => {
                    setIsSignedOut(false);
                  }}
                >
                  <Text style={modalStyles.signOutConfirmText}>Sign Out</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
    </View>
  );
}

// Privacy Vault Modal Component
interface PrivacyVaultModalProps {
  visible: boolean;
  onClose: () => void;
  isGhostMode: boolean;
  onToggleGhostMode: () => void;
  isPremium: boolean;
  onUpgrade: () => void;
}

const PrivacyVaultModal: React.FC<PrivacyVaultModalProps> = ({
  visible,
  onClose,
  isGhostMode,
  onToggleGhostMode,
  isPremium,
  onUpgrade,
}) => {
  const insets = useSafeAreaInsets();

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={[modalStyles.container, { paddingBottom: insets.bottom }]}>
        {/* Header */}
        <View style={modalStyles.header}>
          <Text style={modalStyles.title}>Privacy Vault</Text>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={24} color={colors.bark[600]} />
          </TouchableOpacity>
        </View>

        <ScrollView
          style={modalStyles.content}
          contentContainerStyle={modalStyles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Location Sharing Header */}
          <View style={modalStyles.sectionHeader}>
            <Ionicons name="location" size={20} color={colors.forestGreen[600]} />
            <Text style={modalStyles.sectionTitle}>Location Sharing</Text>
          </View>
          <Text style={modalStyles.sectionDescription}>
            Control how your location is shared with the community
          </Text>

          {/* Live Pin Option */}
          <TouchableOpacity
            style={[
              modalStyles.optionCard,
              !isGhostMode && modalStyles.optionCardActive,
            ]}
            onPress={() => isGhostMode && onToggleGhostMode()}
          >
            <LinearGradient
              colors={!isGhostMode
                ? [colors.forestGreen[500], colors.forestGreen[600]]
                : [colors.glass.whiteLight, colors.glass.whiteLight]
              }
              style={modalStyles.optionIconBg}
            >
              <Ionicons
                name="location"
                size={24}
                color={!isGhostMode ? colors.text.inverse : colors.bark[400]}
              />
            </LinearGradient>
            <View style={modalStyles.optionContent}>
              <Text style={[
                modalStyles.optionTitle,
                !isGhostMode && modalStyles.optionTitleActive,
              ]}>
                Live Pin
              </Text>
              <Text style={modalStyles.optionDescription}>
                Share your exact location with connections and convoy members
              </Text>
            </View>
            <View style={[
              modalStyles.radioButton,
              !isGhostMode && modalStyles.radioButtonActive,
            ]}>
              {!isGhostMode && (
                <Ionicons name="checkmark" size={14} color={colors.text.inverse} />
              )}
            </View>
          </TouchableOpacity>

          {/* Ghost Mode Option */}
          <TouchableOpacity
            style={[
              modalStyles.optionCard,
              isGhostMode && modalStyles.optionCardActive,
              !isPremium && modalStyles.optionCardLocked,
            ]}
            onPress={() => {
              if (!isPremium) {
                onUpgrade();
              } else if (!isGhostMode) {
                onToggleGhostMode();
              }
            }}
          >
            <LinearGradient
              colors={isGhostMode
                ? [colors.deepTeal[500], colors.deepTeal[600]]
                : [colors.glass.whiteLight, colors.glass.whiteLight]
              }
              style={modalStyles.optionIconBg}
            >
              <Ionicons
                name="eye-off"
                size={24}
                color={isGhostMode ? colors.text.inverse : colors.bark[400]}
              />
            </LinearGradient>
            <View style={modalStyles.optionContent}>
              <View style={modalStyles.optionTitleRow}>
                <Text style={[
                  modalStyles.optionTitle,
                  isGhostMode && modalStyles.optionTitleActive,
                ]}>
                  Ghost Mode
                </Text>
                {!isPremium && (
                  <View style={modalStyles.premiumBadge}>
                    <Ionicons name="diamond" size={10} color={colors.text.inverse} />
                    <Text style={modalStyles.premiumBadgeText}>PRO</Text>
                  </View>
                )}
              </View>
              <Text style={modalStyles.optionDescription}>
                Show a blurred area instead of exact location. Stay private while still connecting.
              </Text>
            </View>
            <View style={[
              modalStyles.radioButton,
              isGhostMode && modalStyles.radioButtonActive,
            ]}>
              {isGhostMode && (
                <Ionicons name="checkmark" size={14} color={colors.text.inverse} />
              )}
            </View>
          </TouchableOpacity>

          {/* Ghost Mode Preview */}
          {isGhostMode && (
            <GlassCard variant="frost" padding="md" style={modalStyles.previewCard}>
              <View style={modalStyles.previewHeader}>
                <Ionicons name="information-circle" size={18} color={colors.deepTeal[600]} />
                <Text style={modalStyles.previewTitle}>Ghost Mode Active</Text>
              </View>
              <Text style={modalStyles.previewText}>
                Others will see a ~10 mile blurred radius around your location.
                Your convoy can still coordinate meetups.
              </Text>
            </GlassCard>
          )}

          {/* Additional Privacy Settings */}
          <View style={[modalStyles.sectionHeader, { marginTop: spacing.xl }]}>
            <Ionicons name="shield" size={20} color={colors.deepTeal[600]} />
            <Text style={modalStyles.sectionTitle}>Additional Settings</Text>
          </View>

          <GlassCard variant="light" padding="none" style={modalStyles.settingsList}>
            {[
              { icon: 'eye-outline', label: 'Profile Visibility', value: 'Friends Only' },
              { icon: 'chatbubble-outline', label: 'Message Requests', value: 'Everyone' },
              { icon: 'people-outline', label: 'Convoy Invites', value: 'Connections' },
              { icon: 'analytics-outline', label: 'Activity Status', value: 'On' },
            ].map((item, index, arr) => (
              <TouchableOpacity
                key={index}
                style={[
                  modalStyles.settingItem,
                  index < arr.length - 1 && modalStyles.settingItemBorder,
                ]}
              >
                <Ionicons
                  name={item.icon as keyof typeof Ionicons.glyphMap}
                  size={20}
                  color={colors.bark[500]}
                />
                <Text style={modalStyles.settingLabel}>{item.label}</Text>
                <Text style={modalStyles.settingValue}>{item.value}</Text>
                <Ionicons name="chevron-forward" size={16} color={colors.bark[400]} />
              </TouchableOpacity>
            ))}
          </GlassCard>
        </ScrollView>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  cleanContainer: {
    flex: 1,
    backgroundColor: '#F5EFE6',
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.xl,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    gap: spacing.md,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.glass.whiteMedium,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: '#2C2C2C',
    letterSpacing: typography.letterSpacing.wide,
  },
  settingsButton: {
    borderRadius: borderRadius.full,
    overflow: 'hidden',
  },
  settingsBlur: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  settingsFallback: {
    backgroundColor: colors.glass.whiteMedium,
  },
  sectionNav: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.xs,
    marginHorizontal: spacing.md,
    marginBottom: spacing.md,
    borderRadius: borderRadius.lg,
    justifyContent: 'space-between',
    ...shadows.soft,
  },
  sectionNavItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xs,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    gap: spacing.xxs,
  },
  sectionNavItemActive: {
    backgroundColor: '#FF6B35',
  },
  sectionNavText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodyMedium,
    color: '#4A4A4A',
  },
  sectionNavTextActive: {
    color: '#FFFFFF',
    fontFamily: typography.fontFamily.bodySemiBold,
  },
  profileHeaderCard: {
    marginBottom: spacing.xl,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  profileAvatarContainer: {
    position: 'relative',
    marginRight: spacing.lg,
  },
  profileAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: colors.glass.whiteLight,
  },
  profileAvatarPlaceholder: {
    backgroundColor: colors.burntSienna[500] + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.forestGreen[500],
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.glass.whiteLight,
  },
  onlineIndicator: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: colors.forestGreen[500],
    borderWidth: 2,
    borderColor: colors.glass.whiteLight,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[800],
  },
  profileRig: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    marginTop: 2,
  },
  profileBadges: {
    flexDirection: 'row',
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.burntSienna[500],
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xxs,
    borderRadius: borderRadius.sm,
    gap: spacing.xxs,
  },
  premiumBadgeText: {
    fontSize: typography.fontSize.xxs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
  memberBadge: {
    backgroundColor: colors.bark[200],
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xxs,
    borderRadius: borderRadius.sm,
  },
  memberBadgeText: {
    fontSize: typography.fontSize.xxs,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.bark[600],
  },
  privacyButton: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.forestGreen[500] + '20',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.forestGreen[500] + '40',
  },
  privacyButtonActive: {
    backgroundColor: colors.deepTeal[500] + '20',
    borderColor: colors.deepTeal[500] + '40',
  },
  statsRow: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: colors.glass.border,
    paddingTop: spacing.lg,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.burntSienna[500],
  },
  statLabel: {
    fontSize: typography.fontSize.xxs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    backgroundColor: colors.glass.border,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontFamily: typography.fontFamily.heading,
    color: colors.text.inverse,
    textShadowColor: 'rgba(0,0,0,0.2)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
    letterSpacing: typography.letterSpacing.wide,
  },
  viewAllText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.desertSand[600],
  },
  rigQuickSpecs: {
    marginBottom: spacing.xl,
    position: 'relative',
    overflow: 'hidden',
  },
  hudCornerTL: {
    position: 'absolute',
    top: 8,
    left: 8,
    width: 16,
    height: 16,
    borderLeftWidth: 2,
    borderTopWidth: 2,
    borderColor: colors.deepTeal[400],
    opacity: 0.6,
  },
  hudCornerTR: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 16,
    height: 16,
    borderRightWidth: 2,
    borderTopWidth: 2,
    borderColor: colors.deepTeal[400],
    opacity: 0.6,
  },
  hudCornerBL: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    width: 16,
    height: 16,
    borderLeftWidth: 2,
    borderBottomWidth: 2,
    borderColor: colors.deepTeal[400],
    opacity: 0.6,
  },
  hudCornerBR: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    width: 16,
    height: 16,
    borderRightWidth: 2,
    borderBottomWidth: 2,
    borderColor: colors.deepTeal[400],
    opacity: 0.6,
  },
  specsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  specItem: {
    alignItems: 'center',
    gap: spacing.xs,
  },
  specValue: {
    fontSize: typography.fontSize.md,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[200],
  },
  specLabel: {
    fontSize: typography.fontSize.xxs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  aiCard: {
    marginBottom: spacing.xl,
    position: 'relative',
    overflow: 'hidden',
  },
  scanLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: colors.forestGreen[400],
  },
  aiHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.lg,
  },
  aiIconContainer: {
    width: 64,
    height: 64,
    borderRadius: borderRadius.xl,
    backgroundColor: colors.forestGreen[500] + '15',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    borderWidth: 1,
    borderColor: colors.forestGreen[400] + '30',
  },
  aiIconGlow: {
    position: 'absolute',
    top: -8,
    left: -8,
    right: -8,
    bottom: -8,
    borderRadius: borderRadius['2xl'],
    backgroundColor: colors.forestGreen[400],
  },
  aiStatusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.forestGreen[500] + '20',
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.forestGreen[400] + '30',
  },
  aiStatusDot: {
    width: 6,
    height: 6,
    borderRadius: borderRadius.full,
    backgroundColor: colors.forestGreen[500],
    marginRight: spacing.xs,
  },
  aiStatusText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodyBold,
    color: colors.forestGreen[500],
    letterSpacing: 1,
  },
  aiTitle: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[200],
    marginBottom: spacing.sm,
  },
  aiDescription: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    marginBottom: spacing.lg,
    lineHeight: 22,
  },
  aiFeatures: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.lg,
  },
  aiFeatureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  aiFeatureText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.bark[400],
  },
  quickActions: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  quickActionCard: {
    flex: 1,
  },
  actionCardInner: {
    alignItems: 'center',
    gap: spacing.sm,
  },
  actionIconBg: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionLabel: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[700],
    textAlign: 'center',
  },
  actionSublabel: {
    fontSize: typography.fontSize.xxs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
  },
  settingsCard: {
    overflow: 'hidden',
    marginBottom: spacing.xl,
  },
  settingsItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  settingsItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: colors.glass.border,
  },
  settingsIconContainer: {
    width: 36,
    height: 36,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.bark[500] + '15',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  settingsIconDanger: {
    backgroundColor: colors.sunsetOrange[500] + '15',
  },
  settingsLabel: {
    flex: 1,
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.bark[700],
  },
  dangerLabel: {
    color: colors.sunsetOrange[500],
  },
});

const modalStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background.primary,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.glass.border,
  },
  title: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[800],
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.xs,
  },
  sectionTitle: {
    fontSize: typography.fontSize.lg,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
  },
  sectionDescription: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    marginBottom: spacing.lg,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.lg,
    borderRadius: borderRadius.xl,
    backgroundColor: colors.glass.whiteLight,
    marginBottom: spacing.md,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  optionCardActive: {
    borderColor: colors.forestGreen[500],
    backgroundColor: colors.forestGreen[50],
  },
  optionCardLocked: {
    opacity: 0.7,
  },
  optionIconBg: {
    width: 48,
    height: 48,
    borderRadius: borderRadius.lg,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  optionContent: {
    flex: 1,
  },
  optionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  optionTitle: {
    fontSize: typography.fontSize.md,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[700],
  },
  optionTitleActive: {
    color: colors.forestGreen[700],
  },
  optionDescription: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    marginTop: spacing.xxs,
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.burntSienna[500],
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
    gap: spacing.xxs,
  },
  premiumBadgeText: {
    fontSize: typography.fontSize.xxs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
  radioButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.bark[300],
    justifyContent: 'center',
    alignItems: 'center',
  },
  radioButtonActive: {
    backgroundColor: colors.forestGreen[500],
    borderColor: colors.forestGreen[500],
  },
  previewCard: {
    marginTop: spacing.sm,
  },
  previewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.xs,
  },
  previewTitle: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.deepTeal[700],
  },
  previewText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[600],
    lineHeight: 20,
  },
  settingsList: {
    overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
  },
  settingItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: colors.glass.border,
  },
  settingLabel: {
    flex: 1,
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[700],
  },
  settingValue: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.bark[500],
  },
  formSection: {
    marginBottom: spacing.lg,
  },
  formLabel: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[600],
    marginBottom: spacing.xs,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.glass.whiteLight,
    padding: spacing.md,
    borderRadius: borderRadius.lg,
    borderWidth: 1,
    borderColor: colors.glass.border,
  },
  inputText: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[700],
  },
  notificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.glass.border,
  },
  notificationLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  notificationLabel: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[700],
  },
  toggle: {
    width: 44,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.bark[200],
    justifyContent: 'center',
    paddingHorizontal: 2,
  },
  toggleActive: {
    backgroundColor: colors.forestGreen[500],
  },
  toggleDot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
  },
  toggleDotActive: {
    alignSelf: 'flex-end',
  },
  helpItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.glass.border,
  },
  helpIconContainer: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.forestGreen[50],
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  helpContent: {
    flex: 1,
  },
  helpLabel: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[700],
  },
  helpDescription: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
  },
  signOutOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
  },
  signOutCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: borderRadius.xl,
    padding: spacing.xl,
    alignItems: 'center',
    width: '100%',
  },
  signOutTitle: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[800],
    marginTop: spacing.md,
  },
  signOutDescription: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    textAlign: 'center',
    marginTop: spacing.sm,
    marginBottom: spacing.xl,
  },
  signOutButtons: {
    flexDirection: 'row',
    gap: spacing.md,
    width: '100%',
  },
  signOutCancel: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.glass.whiteLight,
    alignItems: 'center',
  },
  signOutCancelText: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[600],
  },
  signOutConfirm: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.sunsetOrange[500],
    alignItems: 'center',
  },
  signOutConfirmText: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: '#FFFFFF',
  },
});
