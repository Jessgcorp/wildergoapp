/**
 * WilderGo Messages Screen
 * Convoy messaging experience for nomadic coordination
 * Features: Live pins, member statuses, AI icebreakers
 */

import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  TextInput,
  Animated,
  Platform,
  Modal,
} from 'react-native';
import { useRouter } from '@/hooks/useRouterCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { Image } from 'expo-image';
import { colors, typography, spacing, borderRadius, shadows, blur } from '@/constants/theme';
import { GlassCard } from '@/components/ui/GlassCard';
import { NatureBackground } from '@/components/ui/NatureBackground';
import { ConvoyThread } from '@/components/convoy/ConvoyThread';
import { ConvoyStatusHeader } from '@/components/convoy/ConvoyMemberStatus';
import { NomadicPulseBadge } from '@/components/convoy/NomadicPulseBadge';
import {
  Convoy,
  ConvoyMember,
  convoyService,
  getMemberStatusColor,
  getMemberStatusLabel,
} from '@/services/convoy/convoyService';

interface Conversation {
  id: string;
  name: string;
  lastMessage: string;
  timestamp: string;
  unread: number;
  online: boolean;
  isConvoy?: boolean;
  isBuilder?: boolean;
  routeOverlap?: number;
  avatar?: string;
  members?: ConvoyMember[];
  convoyData?: Convoy;
  nomadicPulse?: 'off_grid' | 'stealth_camping' | 'rv_park' | 'urban_discovery' | 'boondocking' | 'national_park';
}

const conversations: Conversation[] = [
  {
    id: 'conv1',
    name: 'Pacific Coast Convoy',
    lastMessage: 'Alex shared a location: Amazing campspot with cell signal!',
    timestamp: '25m ago',
    unread: 3,
    online: true,
    isConvoy: true,
    convoyData: convoyService.getConvoyById('conv1'),
    members: convoyService.getConvoyById('conv1')?.members,
  },
  {
    id: '1',
    name: 'Alex',
    lastMessage: 'Hey! Are you heading to Glacier too?',
    timestamp: '2m ago',
    unread: 2,
    online: true,
    routeOverlap: 85,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80',
    nomadicPulse: 'boondocking',
  },
  {
    id: 'conv2',
    name: 'Desert Nomads',
    lastMessage: 'Jordan is now En Route',
    timestamp: '1h ago',
    unread: 1,
    online: true,
    isConvoy: true,
    convoyData: convoyService.getConvoyById('conv2'),
    members: convoyService.getConvoyById('conv2')?.members,
  },
  {
    id: '3',
    name: 'Sarah Solar Solutions',
    lastMessage: 'Your panel setup looks great! I can help...',
    timestamp: '1h ago',
    unread: 0,
    online: false,
    isBuilder: true,
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&q=80',
  },
  {
    id: '4',
    name: 'Jordan',
    lastMessage: 'That hot spring was amazing!',
    timestamp: '3h ago',
    unread: 0,
    online: true,
    routeOverlap: 62,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80',
    nomadicPulse: 'national_park',
  },
  {
    id: '5',
    name: 'Sam',
    lastMessage: 'See you at the bonfire tonight!',
    timestamp: 'Yesterday',
    unread: 0,
    online: false,
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&q=80',
    nomadicPulse: 'stealth_camping',
  },
];

export default function MessagesScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'unread' | 'convoys'>('all');
  const [selectedConvoy, setSelectedConvoy] = useState<Convoy | null>(null);
  const [showConvoyThread, setShowConvoyThread] = useState(false);

  // Animation for AI button
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const glowAnim = useRef(new Animated.Value(0.3)).current;

  React.useEffect(() => {
    // Pulse animation for AI button
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Glow animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 0.6,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(glowAnim, {
          toValue: 0.3,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, [pulseAnim, glowAnim]);

  const filteredConversations = conversations.filter((conv) => {
    const matchesSearch = conv.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (activeFilter === 'unread') return conv.unread > 0;
    if (activeFilter === 'convoys') return conv.isConvoy;
    return true;
  });

  const handleConversationPress = useCallback((conv: Conversation) => {
    if (conv.isConvoy && conv.convoyData) {
      setSelectedConvoy(conv.convoyData);
      setShowConvoyThread(true);
    } else {
      // Navigate to DM screen (would be separate screen)
      console.log('Open DM with:', conv.name);
    }
  }, []);

  const getAvatarColor = (item: Conversation) => {
    if (item.isConvoy) return colors.moss[500];
    if (item.isBuilder) return colors.driftwood[500];
    return colors.ember[500];
  };

  const renderConversation = ({ item }: { item: Conversation }) => (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={() => handleConversationPress(item)}
    >
      <GlassCard variant="light" padding="md" style={styles.conversationCard}>
        <View style={styles.conversationItem}>
          {/* Avatar */}
          <View style={styles.avatarContainer}>
            {item.avatar ? (
              <Image source={{ uri: item.avatar }} style={styles.avatarImage} />
            ) : (
              <View style={[styles.avatar, { backgroundColor: getAvatarColor(item) + '25' }]}>
                <Ionicons
                  name={item.isConvoy ? 'people' : item.isBuilder ? 'construct' : 'person'}
                  size={24}
                  color={getAvatarColor(item)}
                />
              </View>
            )}
            {item.online && <View style={styles.onlineIndicator} />}

            {/* Convoy member count badge */}
            {item.isConvoy && item.members && (
              <View style={styles.memberCountBadge}>
                <Text style={styles.memberCountText}>{item.members.length}</Text>
              </View>
            )}
          </View>

          {/* Content */}
          <View style={styles.conversationContent}>
            <View style={styles.conversationHeader}>
              <View style={styles.nameContainer}>
                <Text style={[styles.conversationName, item.unread > 0 && styles.unreadName]}>
                  {item.name}
                </Text>
                {item.isBuilder && (
                  <View style={styles.builderBadge}>
                    <Ionicons name="shield-checkmark" size={12} color={colors.driftwood[500]} />
                  </View>
                )}
                {item.isConvoy && (
                  <View style={styles.convoyBadge}>
                    <Ionicons name="car-sport" size={10} color={colors.moss[500]} />
                  </View>
                )}
              </View>
              <Text style={styles.timestamp}>{item.timestamp}</Text>
            </View>

            {/* Convoy member status header */}
            {item.isConvoy && item.members && (
              <View style={styles.convoyStatusContainer}>
                <ConvoyStatusHeader members={item.members} />
              </View>
            )}

            <View style={styles.messageRow}>
              <Text
                style={[styles.lastMessage, item.unread > 0 && styles.unreadMessage]}
                numberOfLines={1}
              >
                {item.lastMessage}
              </Text>
            </View>

            {/* Meta badges row */}
            <View style={styles.badgesRow}>
              {item.routeOverlap && (
                <View style={styles.routeOverlapBadge}>
                  <Ionicons name="navigate" size={10} color={colors.text.inverse} />
                  <Text style={styles.routeOverlapText}>{item.routeOverlap}%</Text>
                </View>
              )}
              {item.nomadicPulse && (
                <NomadicPulseBadge
                  pulse={item.nomadicPulse}
                  size="small"
                  showLabel={false}
                  animated={false}
                />
              )}
            </View>
          </View>

          {/* Unread Badge */}
          {item.unread > 0 && (
            <View style={styles.unreadBadgeContainer}>
              <View style={styles.unreadBadge}>
                <Text style={styles.unreadCount}>{item.unread}</Text>
              </View>
              <View style={styles.unreadGlow} />
            </View>
          )}

          {/* Convoy arrow */}
          {item.isConvoy && (
            <Ionicons name="chevron-forward" size={20} color={colors.bark[400]} />
          )}
        </View>
      </GlassCard>
    </TouchableOpacity>
  );

  const SearchBarContent = () => (
    <View style={styles.searchBarInner}>
      <Ionicons name="search" size={18} color={colors.bark[400]} />
      <TextInput
        style={styles.searchInput}
        placeholder="Search conversations..."
        placeholderTextColor={colors.bark[400]}
        value={searchQuery}
        onChangeText={setSearchQuery}
      />
      {searchQuery.length > 0 && (
        <TouchableOpacity onPress={() => setSearchQuery('')}>
          <Ionicons name="close-circle" size={18} color={colors.bark[400]} />
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <NatureBackground variant="sage" overlay overlayOpacity={0.5}>
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.headerTitle}>Messages</Text>
            <Text style={styles.headerSubtitle}>Convoy Threads</Text>
          </View>
          <TouchableOpacity style={styles.composeButton}>
            {Platform.OS === 'ios' ? (
              <BlurView intensity={80} tint="light" style={styles.composeBlur}>
                <Ionicons name="add" size={24} color={colors.moss[600]} />
              </BlurView>
            ) : (
              <View style={[styles.composeBlur, styles.composeFallback]}>
                <Ionicons name="add" size={24} color={colors.moss[600]} />
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          {Platform.OS === 'ios' ? (
            <BlurView intensity={60} tint="light" style={styles.searchBar}>
              <SearchBarContent />
            </BlurView>
          ) : (
            <View style={[styles.searchBar, styles.searchBarFallback]}>
              <SearchBarContent />
            </View>
          )}
        </View>

        {/* Filter Tabs */}
        <View style={styles.filterContainer}>
          {(['all', 'unread', 'convoys'] as const).map((filter) => (
            <TouchableOpacity
              key={filter}
              style={[styles.filterTab, activeFilter === filter && styles.filterTabActive]}
              onPress={() => setActiveFilter(filter)}
            >
              {activeFilter === filter && Platform.OS === 'ios' ? (
                <BlurView intensity={80} tint="light" style={styles.filterBlur}>
                  <Ionicons
                    name={filter === 'convoys' ? 'car-sport' : filter === 'unread' ? 'mail-unread' : 'chatbubbles'}
                    size={14}
                    color={colors.moss[600]}
                    style={{ marginRight: spacing.xs }}
                  />
                  <Text style={styles.filterTextActive}>
                    {filter === 'all' ? 'All' : filter === 'unread' ? 'Unread' : 'Convoys'}
                  </Text>
                </BlurView>
              ) : (
                <View style={activeFilter === filter ? styles.filterBlurFallback : undefined}>
                  <Text
                    style={[
                      styles.filterText,
                      activeFilter === filter && styles.filterTextActive,
                    ]}
                  >
                    {filter === 'all' ? 'All' : filter === 'unread' ? 'Unread' : 'Convoys'}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Conversations List */}
        <FlatList
          data={filteredConversations}
          renderItem={renderConversation}
          keyExtractor={(item) => item.id}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: insets.bottom + 100 }
          ]}
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          ListEmptyComponent={
            <GlassCard variant="medium" padding="xl" style={styles.emptyCard}>
              <View style={styles.emptyState}>
                <View style={styles.emptyIconContainer}>
                  <Ionicons name="chatbubbles-outline" size={48} color={colors.moss[500]} />
                </View>
                <Text style={styles.emptyText}>No messages yet</Text>
                <Text style={styles.emptySubtext}>
                  Start a conversation by matching with someone on the Discovery tab or join a convoy!
                </Text>
              </View>
            </GlassCard>
          }
        />

        {/* AI Icebreaker Button with Ember Glow */}
        <Animated.View
          style={[
            styles.icebreakerContainer,
            {
              transform: [{ scale: pulseAnim }],
              bottom: insets.bottom + 100,
            },
          ]}
        >
          <Animated.View style={[styles.icebreakerGlow, { opacity: glowAnim }]} />
          <TouchableOpacity
            style={styles.icebreakerButton}
            onPress={() => router.push('/ai-assistant')}
            activeOpacity={0.8}
          >
            <View style={styles.icebreakerContent}>
              <View style={styles.sparkleContainer}>
                <Ionicons name="sparkles" size={20} color={colors.text.inverse} />
              </View>
              <View style={styles.icebreakerTextContainer}>
                <Text style={styles.icebreakerTitle}>AI Icebreaker</Text>
                <Text style={styles.icebreakerSubtitle}>Generate convoy introductions</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.text.inverse} />
            </View>
          </TouchableOpacity>
        </Animated.View>
      </View>

      {/* Convoy Thread Modal */}
      <Modal
        visible={showConvoyThread}
        animationType="slide"
        presentationStyle="fullScreen"
        onRequestClose={() => setShowConvoyThread(false)}
      >
        {selectedConvoy && (
          <ConvoyThread
            convoy={selectedConvoy}
            currentUserId="current-user"
            onBack={() => setShowConvoyThread(false)}
            onOpenMap={(lat, lng) => {
              setShowConvoyThread(false);
              // Navigate to map with coordinates
              console.log('Open map at:', lat, lng);
            }}
            onViewMember={(member) => {
              console.log('View member profile:', member.name);
            }}
          />
        )}
      </Modal>
    </NatureBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
  },
  headerTitle: {
    fontSize: typography.fontSize['2xl'],
    fontFamily: typography.fontFamily.heading,
    color: colors.text.inverse,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
    letterSpacing: typography.letterSpacing.wide,
  },
  headerSubtitle: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[300],
    marginTop: 2,
  },
  composeButton: {
    borderRadius: borderRadius.full,
    overflow: 'hidden',
  },
  composeBlur: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  composeFallback: {
    backgroundColor: colors.glass.whiteMedium,
  },
  searchContainer: {
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.md,
  },
  searchBar: {
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
  },
  searchBarFallback: {
    backgroundColor: colors.glass.whiteMedium,
  },
  searchBarInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
  },
  searchInput: {
    flex: 1,
    marginLeft: spacing.sm,
    fontSize: typography.fontSize.base,
    color: colors.bark[800],
    paddingVertical: spacing.xs,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.lg,
    gap: spacing.sm,
  },
  filterTab: {
    borderRadius: borderRadius.full,
    overflow: 'hidden',
  },
  filterTabActive: {
    ...shadows.glass,
  },
  filterBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.full,
    overflow: 'hidden',
  },
  filterBlurFallback: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    backgroundColor: colors.glass.whiteMedium,
    borderRadius: borderRadius.full,
  },
  filterText: {
    fontSize: typography.fontSize.sm,
    fontWeight: '500',
    color: colors.bark[300],
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
  },
  filterTextActive: {
    color: colors.moss[600],
    fontWeight: '600',
  },
  listContent: {
    paddingHorizontal: spacing.xl,
  },
  conversationCard: {
    marginVertical: 0,
  },
  conversationItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    position: 'relative',
    marginRight: spacing.md,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: borderRadius.full,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarImage: {
    width: 52,
    height: 52,
    borderRadius: 26,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 14,
    height: 14,
    borderRadius: borderRadius.full,
    backgroundColor: colors.moss[500],
    borderWidth: 2,
    borderColor: colors.glass.whiteLight,
  },
  memberCountBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.moss[500],
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    borderWidth: 2,
    borderColor: colors.glass.whiteLight,
  },
  memberCountText: {
    fontSize: 10,
    fontFamily: typography.fontFamily.bodyBold,
    color: colors.text.inverse,
  },
  conversationContent: {
    flex: 1,
  },
  conversationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  nameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  conversationName: {
    fontSize: typography.fontSize.base,
    fontWeight: '500',
    color: colors.bark[800],
  },
  unreadName: {
    fontWeight: '700',
    color: colors.bark[900],
  },
  builderBadge: {
    width: 18,
    height: 18,
    borderRadius: borderRadius.full,
    backgroundColor: colors.driftwood[500] + '25',
    justifyContent: 'center',
    alignItems: 'center',
  },
  convoyBadge: {
    width: 18,
    height: 18,
    borderRadius: borderRadius.full,
    backgroundColor: colors.moss[500] + '25',
    justifyContent: 'center',
    alignItems: 'center',
  },
  timestamp: {
    fontSize: typography.fontSize.xs,
    color: colors.bark[400],
  },
  convoyStatusContainer: {
    marginVertical: spacing.xs,
  },
  messageRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  lastMessage: {
    flex: 1,
    fontSize: typography.fontSize.sm,
    color: colors.bark[500],
  },
  unreadMessage: {
    color: colors.bark[700],
    fontWeight: '500',
  },
  badgesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: spacing.xs,
  },
  routeOverlapBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.ember[500],
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.full,
    gap: 2,
  },
  routeOverlapText: {
    fontSize: typography.fontSize.xs,
    fontWeight: '600',
    color: colors.text.inverse,
  },
  unreadBadgeContainer: {
    position: 'relative',
    marginLeft: spacing.sm,
  },
  unreadBadge: {
    minWidth: 24,
    height: 24,
    borderRadius: borderRadius.full,
    backgroundColor: colors.ember[500],
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    zIndex: 1,
  },
  unreadGlow: {
    position: 'absolute',
    top: -4,
    left: -4,
    right: -4,
    bottom: -4,
    borderRadius: borderRadius.full,
    backgroundColor: colors.ember[500],
    opacity: 0.3,
    zIndex: 0,
  },
  unreadCount: {
    fontSize: typography.fontSize.xs,
    fontWeight: '700',
    color: colors.text.inverse,
  },
  separator: {
    height: spacing.sm,
  },
  emptyCard: {
    marginTop: spacing['2xl'],
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
  },
  emptyIconContainer: {
    width: 80,
    height: 80,
    borderRadius: borderRadius.full,
    backgroundColor: colors.moss[500] + '20',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  emptyText: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600',
    color: colors.bark[800],
    marginBottom: spacing.sm,
  },
  emptySubtext: {
    fontSize: typography.fontSize.sm,
    color: colors.bark[500],
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: spacing.lg,
  },
  icebreakerContainer: {
    position: 'absolute',
    right: spacing.xl,
    left: spacing.xl,
  },
  icebreakerGlow: {
    position: 'absolute',
    top: -8,
    left: -8,
    right: -8,
    bottom: -8,
    borderRadius: borderRadius['2xl'],
    backgroundColor: colors.ember[500],
  },
  icebreakerButton: {
    backgroundColor: colors.ember[500],
    borderRadius: borderRadius.xl,
    ...shadows.glow,
  },
  icebreakerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  sparkleContainer: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.lg,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  icebreakerTextContainer: {
    flex: 1,
  },
  icebreakerTitle: {
    fontSize: typography.fontSize.md,
    fontWeight: '700',
    color: colors.text.inverse,
  },
  icebreakerSubtitle: {
    fontSize: typography.fontSize.xs,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
});
