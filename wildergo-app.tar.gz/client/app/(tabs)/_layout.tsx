import React, { useState, useEffect } from 'react';
import { Tabs } from 'expo-router';
import { StyleSheet, View, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { colors, shadows, borderRadius, spacing } from '@/constants/theme';
import { SOSTabIcon } from '@/components/emergency';

export default function TabsLayout() {
  const insets = useSafeAreaInsets();

  // Track if there's a nearby help alert (in real app, this would come from a context/service)
  const [hasNearbyAlert, setHasNearbyAlert] = useState(false);
  const [alertPriority, setAlertPriority] = useState<'critical' | 'urgent' | 'assistance'>('assistance');

  // Demo: Simulate incoming alert after 45 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setHasNearbyAlert(true);
      setAlertPriority('urgent');
    }, 45000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.ember[500],
        tabBarInactiveTintColor: colors.bark[400],
        tabBarStyle: {
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: Platform.OS === 'ios' ? 'transparent' : colors.glass.darkMedium,
          borderTopWidth: 0,
          paddingBottom: insets.bottom,
          height: 80 + insets.bottom,
          paddingTop: spacing.sm,
          elevation: 0,
        },
        tabBarBackground: () => (
          Platform.OS === 'ios' ? (
            <BlurView
              tint="dark"
              intensity={90}
              style={StyleSheet.absoluteFill}
            >
              <View style={styles.tabBarOverlay} />
            </BlurView>
          ) : (
            <View style={[StyleSheet.absoluteFill, styles.tabBarFallback]} />
          )
        ),
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
          marginTop: 2,
          letterSpacing: 0.3,
        },
        tabBarIconStyle: {
          marginTop: 4,
        },
      }}
    >
      <Tabs.Screen
        name="discovery"
        options={{
          title: 'Discovery',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon
              name={focused ? 'compass' : 'compass-outline'}
              color={color}
              focused={focused}
              focusColor={colors.ember[500]}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="map"
        options={{
          title: 'Map',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon
              name={focused ? 'map' : 'map-outline'}
              color={color}
              focused={focused}
              focusColor={colors.moss[500]}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          title: 'Messages',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon
              name={focused ? 'chatbubbles' : 'chatbubbles-outline'}
              color={color}
              focused={focused}
              focusColor={colors.driftwood[500]}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profile',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon
              name={focused ? 'person' : 'person-outline'}
              color={color}
              focused={focused}
              focusColor={colors.ember[400]}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="help"
        options={{
          title: 'Help',
          tabBarIcon: ({ color, focused }) => (
            <SOSTabIcon
              focused={focused}
              color={color}
              hasNearbyAlert={hasNearbyAlert}
              alertPriority={alertPriority}
            />
          ),
        }}
      />
    </Tabs>
  );
}

interface TabIconProps {
  name: keyof typeof Ionicons.glyphMap;
  color: string;
  focused: boolean;
  focusColor: string;
}

const TabIcon: React.FC<TabIconProps> = ({ name, color, focused, focusColor }) => {
  return (
    <View style={[styles.iconContainer, focused && styles.iconContainerActive]}>
      <Ionicons
        name={name}
        size={24}
        color={focused ? focusColor : color}
      />
      {focused && (
        <View style={[styles.activeIndicator, { backgroundColor: focusColor }]} />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  tabBarOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(30, 24, 20, 0.75)',
    borderTopWidth: 1,
    borderTopColor: colors.glass.border,
  },
  tabBarFallback: {
    backgroundColor: 'rgba(30, 24, 20, 0.95)',
    borderTopWidth: 1,
    borderTopColor: colors.glass.border,
  },
  iconContainer: {
    width: 48,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: borderRadius.lg,
    position: 'relative',
  },
  iconContainerActive: {
    backgroundColor: colors.glass.whiteSubtle,
  },
  activeIndicator: {
    position: 'absolute',
    bottom: -4,
    width: 4,
    height: 4,
    borderRadius: 2,
    ...shadows.glassSubtle,
  },
});
