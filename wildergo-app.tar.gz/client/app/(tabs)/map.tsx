import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { colors, typography, spacing, borderRadius, shadows, eventImages, mapboxConfig, markerTypes } from '@/constants/theme';
import { ModeToggle, AppMode } from '@/components/ui/ModeToggle';
import { Button } from '@/components/ui/Button';
import { GlassCard } from '@/components/ui/GlassCard';
import { NatureBackground } from '@/components/ui/NatureBackground';
import { Logo } from '@/components/ui/Logo';
import { MapMarker } from '@/components/map/MapMarker';
import { MapControls } from '@/components/map/MapControls';
import { MapSocialSheet } from '@/components/map/MapSocialSheet';
import { AIRoutePlanner } from '@/components/map/AIRoutePlanner';
import { GhostModeMarker, GhostModeIndicator } from '@/components/map/GhostModeMarker';
import { LookAheadRadar } from '@/components/radar/LookAheadRadar';
import { NotificationBanner } from '@/components/radar/RouteOverlapNotifications';
import { EnhancedWeatherHUD } from '@/components/map/EnhancedWeatherHUD';
import { DynamicWeatherOverlay, WeatherOverlayData } from '@/components/map/DynamicWeatherOverlay';
import { WeatherChangeAlert, RouteWeatherTimeline, WeatherChange, RouteWeatherPoint } from '@/components/weather';
import {
  EnhancedCampfireMarker,
  ClusterVibeSheet,
  useEnhancedClustering,
  EnhancedCluster,
} from '@/components/map/EnhancedCampfireCluster';
import { useGhostMode, useMode } from '@/contexts/ModeContext';
import { radarService, RouteOverlapNotification } from '@/services/radar/radarService';
import {
  mapService,
  MapMarkerData,
  SmartRouteSuggestion,
} from '@/services/map/mapService';
import { getWeatherForLocation } from '@/services/map/advancedMapService';

interface ActivityEvent {
  id: string;
  title: string;
  type: 'social' | 'activity' | 'convoy';
  attendees: number;
  maxAttendees?: number;
  host: string;
  time: string;
  location: string;
  imageUrl?: string;
  description?: string;
}

// Helper to map weather condition strings to overlay types
function mapWeatherCondition(condition: string): WeatherOverlayData['condition'] {
  const lower = condition.toLowerCase();
  if (lower.includes('storm') || lower.includes('thunder')) return 'storm';
  if (lower.includes('rain') || lower.includes('shower')) return 'rain';
  if (lower.includes('snow') || lower.includes('sleet')) return 'snow';
  if (lower.includes('fog') || lower.includes('mist')) return 'fog';
  if (lower.includes('wind') || lower.includes('gust')) return 'windy';
  if (lower.includes('cloud') || lower.includes('overcast')) return 'cloudy';
  return 'clear';
}

const nearbyEvents: ActivityEvent[] = [
  {
    id: '1',
    title: 'Sunset Bonfire',
    type: 'social',
    attendees: 12,
    maxAttendees: 20,
    host: 'Alex',
    time: 'Tonight at 7pm',
    location: 'Moab Desert Overlook',
    imageUrl: eventImages.bonfire,
    description: 'Join us for an evening under the stars with good company and warm vibes.',
  },
  {
    id: '2',
    title: 'Climbing Partner Needed',
    type: 'activity',
    attendees: 3,
    host: 'Jordan',
    time: 'Tomorrow 6am',
    location: 'Red Rock Canyon',
    imageUrl: eventImages.climbing,
    description: 'Looking for experienced climbers to tackle the Fisher Towers.',
  },
  {
    id: '3',
    title: 'Morning Hike',
    type: 'activity',
    attendees: 8,
    host: 'Sam',
    time: 'Saturday 5am',
    location: 'Delicate Arch Trail',
    imageUrl: eventImages.hiking,
  },
];

export default function MapScreen() {
  const insets = useSafeAreaInsets();
  const [activeMode, setActiveMode] = useState<AppMode>('friends');
  const [showEvents, setShowEvents] = useState(true);
  const [selectedMarker, setSelectedMarker] = useState<MapMarkerData | null>(null);
  const [sheetVisible, setSheetVisible] = useState(false);
  const [routePlannerVisible, setRoutePlannerVisible] = useState(false);
  const [lookAheadVisible, setLookAheadVisible] = useState(false);
  const [markers, setMarkers] = useState<MapMarkerData[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [routeOverlapNotification, setRouteOverlapNotification] = useState<RouteOverlapNotification | null>(null);
  const [showWeatherOverlay] = useState(true);
  const [weatherData, setWeatherData] = useState<WeatherOverlayData | null>(null);
  const [selectedCluster, setSelectedCluster] = useState<EnhancedCluster | null>(null);
  const [clusterSheetVisible, setClusterSheetVisible] = useState(false);
  const [weatherChanges, setWeatherChanges] = useState<WeatherChange[]>([]);
  const [routeWeatherPoints, setRouteWeatherPoints] = useState<RouteWeatherPoint[]>([]);
  const [showWeatherAlerts, setShowWeatherAlerts] = useState(true);
  const [currentAlertIndex, setCurrentAlertIndex] = useState(0);
  const [alertsShownOnce, setAlertsShownOnce] = useState(false);
  const [isMapExpanded, setIsMapExpanded] = useState(false);

  // Ghost mode state from context
  const { isGhostMode, toggleGhostMode, isPremium } = useGhostMode();
  const { setMode } = useMode();

  // Current user position (center of map for demo)
  const currentUserPosition = { top: '45%' as `${number}%`, left: '45%' as `${number}%` };

  // Default map center coordinates
  const mapCenter = {
    latitude: mapboxConfig.defaultCenter.latitude,
    longitude: mapboxConfig.defaultCenter.longitude,
  };

  // Enhanced clustering for campfire markers
  const { clusters, unclustered } = useEnhancedClustering(markers, 14);

  // Load route overlap notifications
  useEffect(() => {
    // Mock user ID for demo - in real app would come from auth context
    const currentUserId = 'current-user';
    const notifications = radarService.getRouteOverlapNotifications(currentUserId);
    if (notifications.length > 0) {
      // Show the highest priority notification
      setRouteOverlapNotification(notifications[0]);
    }
  }, []);

  // Initialize route weather data for demo
  useEffect(() => {
    const demoWeatherChanges: WeatherChange[] = [
      {
        location: 'Near Denver, CO',
        distance: '45 miles',
        currentCondition: 'sunny',
        upcomingCondition: 'stormy',
        severity: 'high',
      },
      {
        location: 'Colorado Springs',
        distance: '120 miles',
        currentCondition: 'cloudy',
        upcomingCondition: 'snowy',
        severity: 'medium',
      },
    ];

    const demoRouteWeather: RouteWeatherPoint[] = [
      { time: '2:00 PM', location: 'Moab, UT', condition: 'sunny', temperature: 75, distance: 'Start' },
      { time: '4:30 PM', location: 'Green River', condition: 'cloudy', temperature: 68, distance: '52 mi' },
      { time: '6:45 PM', location: 'Price', condition: 'rainy', temperature: 58, distance: '115 mi' },
      { time: '8:30 PM', location: 'Spanish Fork', condition: 'stormy', temperature: 52, distance: '178 mi' },
      { time: '10:00 PM', location: 'Salt Lake City', condition: 'cloudy', temperature: 55, distance: '232 mi' },
    ];

    setWeatherChanges(demoWeatherChanges);
    setRouteWeatherPoints(demoRouteWeather);
  }, []);

  // Auto-dismiss and rotate weather alerts - show only ONE at a time
  useEffect(() => {
    if (weatherChanges.length > 0 && showWeatherAlerts && !alertsShownOnce) {
      const dismissTimer = setTimeout(() => {
        const nextIndex = currentAlertIndex + 1;
        if (nextIndex >= weatherChanges.length) {
          // We've shown all alerts, stop showing
          setShowWeatherAlerts(false);
          setAlertsShownOnce(true);
          setCurrentAlertIndex(0);
        } else {
          // Show next alert
          setCurrentAlertIndex(nextIndex);
        }
      }, 8000); // Show each alert for 8 seconds

      return () => clearTimeout(dismissTimer);
    }
  }, [showWeatherAlerts, currentAlertIndex, weatherChanges.length, alertsShownOnce]);

  // Load markers based on active mode
  useEffect(() => {
    const filteredMarkers = mapService.getMarkersForMode(activeMode);
    setMarkers(filteredMarkers);
  }, [activeMode]);

  // Load weather data for overlay
  useEffect(() => {
    const loadWeather = () => {
      try {
        const weather = getWeatherForLocation(mapCenter.latitude, mapCenter.longitude);
        if (weather) {
          // Convert to overlay format
          const overlayData: WeatherOverlayData = {
            windSpeed: weather.windSpeed || 0,
            windDirection: weather.windDirection || 'N',
            condition: mapWeatherCondition(weather.condition || 'clear'),
            // Storm cells would come from weather alerts service
            stormCells: [],
          };
          setWeatherData(overlayData);
        }
      } catch (error) {
        console.error('Error loading weather for overlay:', error);
        // Set default mild weather
        setWeatherData({
          windSpeed: 8,
          windDirection: 'SW',
          condition: 'clear',
        });
      }
    };
    loadWeather();
  }, [mapCenter.latitude, mapCenter.longitude]);

  // Sync mode with context
  useEffect(() => {
    setMode(activeMode);
  }, [activeMode, setMode]);

  // Handle Look Ahead button press
  const handleLookAhead = useCallback(() => {
    setLookAheadVisible(true);
  }, []);

  // Handle notification dismiss
  const handleNotificationDismiss = useCallback(() => {
    setRouteOverlapNotification(null);
  }, []);

  // Handle notification action
  const handleNotificationPress = useCallback(() => {
    console.log('View overlap details:', routeOverlapNotification);
    // Could navigate to route comparison or user profile
    setRouteOverlapNotification(null);
  }, [routeOverlapNotification]);

  const handleMarkerPress = useCallback((marker: MapMarkerData) => {
    setSelectedMarker(marker);
    setSheetVisible(true);
  }, []);

  const handleSheetClose = useCallback(() => {
    setSheetVisible(false);
    setTimeout(() => setSelectedMarker(null), 300);
  }, []);

  const handleRecenter = useCallback(() => {
    // Recenter map to default location
    console.log('Recentering to:', mapboxConfig.defaultCenter);
  }, []);

  const handleSearchArea = useCallback(() => {
    setIsSearching(true);
    // Simulate search
    setTimeout(() => {
      setIsSearching(false);
    }, 1500);
  }, []);

  const handleZoomIn = useCallback(() => {
    console.log('Zooming in');
  }, []);

  const handleZoomOut = useCallback(() => {
    console.log('Zooming out');
  }, []);

  const handleSmartRoute = useCallback(() => {
    setRoutePlannerVisible(true);
  }, []);

  const handleRouteSelect = useCallback((route: SmartRouteSuggestion) => {
    console.log('Selected route:', route.name);
    // Highlight route on map
  }, []);

  const handleAskToJoin = useCallback((marker: MapMarkerData) => {
    console.log('Ask to join:', marker.id);
    // Send join request
  }, []);

  const handleViewProfile = useCallback((marker: MapMarkerData) => {
    console.log('View profile:', marker.id);
    // Navigate to profile
  }, []);

  const handleMessage = useCallback((marker: MapMarkerData) => {
    console.log('Message:', marker.id);
    // Open chat
  }, []);

  const handleHire = useCallback((marker: MapMarkerData) => {
    console.log('Hire builder:', marker.id);
    // Open hire flow
  }, []);

  // Handle cluster press - show vibe panel
  const handleClusterPress = useCallback((cluster: EnhancedCluster) => {
    setSelectedCluster(cluster);
    setClusterSheetVisible(true);
  }, []);

  // Handle cluster sheet close
  const handleClusterSheetClose = useCallback(() => {
    setClusterSheetVisible(false);
    setTimeout(() => setSelectedCluster(null), 300);
  }, []);

  // Handle marker selection from cluster
  const handleClusterMarkerSelect = useCallback((marker: MapMarkerData) => {
    setClusterSheetVisible(false);
    setTimeout(() => {
      setSelectedMarker(marker);
      setSheetVisible(true);
    }, 300);
  }, []);

  // Marker positions for stylized map
  const markerPositions: { top: `${number}%`; left: `${number}%` }[] = [
    { top: '22%', left: '18%' },
    { top: '32%', left: '52%' },
    { top: '48%', left: '28%' },
    { top: '42%', left: '68%' },
    { top: '62%', left: '42%' },
    { top: '55%', left: '75%' },
    { top: '70%', left: '20%' },
  ];

  return (
    <View style={[styles.screenContainer, { paddingTop: isMapExpanded ? 0 : insets.top }]}>
      {/* MAP SECTION - Takes 55% of screen, or full screen when expanded */}
      <View style={[
        styles.mapSection,
        isMapExpanded && [styles.mapSectionExpanded, { height: SCREEN_HEIGHT, paddingTop: insets.top }]
      ]}>
        <View style={styles.mapArea}>
          {/* Dynamic Weather Overlay */}
          {weatherData && (
            <DynamicWeatherOverlay
              data={weatherData}
              visible={showWeatherOverlay}
            />
          )}

          {/* Custom Styled Map Background */}
          <LinearGradient
            colors={[mapboxConfig.style.land, mapboxConfig.style.landLight, mapboxConfig.style.land]}
            style={styles.mapGradient}
          >
            {/* Simulated terrain features */}
            <View style={[styles.terrainFeature, { top: '8%', left: '5%', backgroundColor: mapboxConfig.style.forest, width: 70, height: 45 }]} />
            <View style={[styles.terrainFeature, { top: '18%', right: '8%', backgroundColor: mapboxConfig.style.water, width: 90, height: 55 }]} />
            <View style={[styles.terrainFeature, { bottom: '35%', left: '12%', backgroundColor: mapboxConfig.style.park, width: 80, height: 50 }]} />
            <View style={[styles.terrainFeature, { bottom: '18%', right: '18%', backgroundColor: mapboxConfig.style.forest, width: 65, height: 40 }]} />
            <View style={[styles.terrainFeature, { top: '50%', left: '55%', backgroundColor: mapboxConfig.style.park, width: 45, height: 30 }]} />

            {/* Road lines */}
            <View style={[styles.roadLine, { top: '38%', transform: [{ rotate: '22deg' }] }]} />
            <View style={[styles.roadLine, { top: '58%', transform: [{ rotate: '-12deg' }] }]} />
            <View style={[styles.roadLine, styles.roadLineVertical, { left: '35%', transform: [{ rotate: '8deg' }] }]} />

            {/* Region labels */}
            <Text style={[styles.mapRegionLabel, { top: '12%', left: '55%' }]}>Nevada</Text>
            <Text style={[styles.mapRegionLabel, { top: '32%', left: '22%' }]}>Utah</Text>
            <Text style={[styles.mapRegionLabel, { bottom: '22%', right: '12%' }]}>Arizona</Text>

            {/* Enhanced Campfire Clusters (for 5+ markers) */}
            {clusters.map((cluster, index) => {
              const clusterPosition = markerPositions[index % markerPositions.length];
              return (
                <EnhancedCampfireMarker
                  key={cluster.id}
                  cluster={cluster}
                  position={clusterPosition}
                  onPress={handleClusterPress}
                />
              );
            })}

            {/* Individual Map Markers (non-clustered) with mode-based filtering */}
            {unclustered.map((marker, index) => {
              const posOffset = (clusters.length + index) % markerPositions.length;
              const position = markerPositions[posOffset];
              const isHighlighted = activeMode === 'dating' && marker.type === 'match';

              return (
                <MapMarker
                  key={marker.id}
                  marker={marker}
                  position={position}
                  isHighlighted={isHighlighted}
                  currentMode={activeMode}
                  onPress={handleMarkerPress}
                />
              );
            })}

            {/* Current User Position */}
            {isGhostMode ? (
              <View style={[styles.currentUserMarker, { top: currentUserPosition.top, left: currentUserPosition.left }]}>
                <GhostModeMarker size="large" showLabel />
              </View>
            ) : (
              <View style={[styles.currentUserMarker, { top: currentUserPosition.top, left: currentUserPosition.left }]}>
                <View style={styles.currentUserPreciseMarker}>
                  <View style={styles.currentUserPreciseInner}>
                    <Ionicons name="navigate" size={14} color={colors.text.inverse} />
                  </View>
                  <View style={styles.currentUserPulse} />
                </View>
              </View>
            )}
          </LinearGradient>

          {/* ONLY ESSENTIAL OVERLAYS ON MAP */}
          {/* Expand/Collapse Button - Top Right */}
          <TouchableOpacity
            style={styles.expandButton}
            onPress={() => setIsMapExpanded(!isMapExpanded)}
          >
            <Ionicons
              name={isMapExpanded ? "contract" : "expand"}
              size={22}
              color="#FFFFFF"
            />
          </TouchableOpacity>

          {/* Compact Weather Badge - Top Left */}
          <View style={styles.compactWeatherBadge}>
            <Ionicons name="sunny" size={18} color={colors.ember[500]} />
            <Text style={styles.compactWeatherTemp}>78°</Text>
          </View>

          {/* Recenter Button - Bottom Right */}
          <TouchableOpacity
            style={styles.recenterButton}
            onPress={handleRecenter}
          >
            <Ionicons name="locate" size={20} color="#2C2C2C" />
          </TouchableOpacity>

          {/* Ghost Mode Indicator (when active) */}
          {isGhostMode && (
            <View style={styles.ghostModeIndicatorCompact}>
              <Ionicons name="eye-off" size={16} color={colors.text.inverse} />
            </View>
          )}
        </View>
      </View>

      {/* CONTROLS SECTION - Below Map (hidden when expanded) */}
      {!isMapExpanded && (
        <ScrollView 
          style={styles.controlsSection}
          contentContainerStyle={styles.controlsContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Mode Selector - Compact Horizontal */}
          <View style={styles.modeSelector}>
            <TouchableOpacity
              style={[styles.modeButton, activeMode === 'dating' && styles.modeButtonActive]}
              onPress={() => setActiveMode('dating')}
            >
              <Ionicons name="heart" size={16} color={activeMode === 'dating' ? '#FFFFFF' : '#4A4A4A'} />
              <Text style={[styles.modeLabel, activeMode === 'dating' && styles.modeLabelActive]}>Dating</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modeButton, activeMode === 'friends' && styles.modeButtonActiveFriends]}
              onPress={() => setActiveMode('friends')}
            >
              <Ionicons name="people" size={16} color={activeMode === 'friends' ? '#FFFFFF' : '#4A4A4A'} />
              <Text style={[styles.modeLabel, activeMode === 'friends' && styles.modeLabelActive]}>Friends</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modeButton, activeMode === 'builder' && styles.modeButtonActiveBuilder]}
              onPress={() => setActiveMode('builder')}
            >
              <Ionicons name="construct" size={16} color={activeMode === 'builder' ? '#FFFFFF' : '#4A4A4A'} />
              <Text style={[styles.modeLabel, activeMode === 'builder' && styles.modeLabelActive]}>Builder</Text>
            </TouchableOpacity>
          </View>

          {/* Smart Features Row */}
          <View style={styles.smartFeaturesRow}>
            <TouchableOpacity style={styles.featureButton} onPress={handleLookAhead}>
              <Ionicons name="radio-outline" size={16} color="#FFFFFF" />
              <Text style={styles.featureButtonText}>Look Ahead</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.featureButton, styles.featureButtonPrimary]} onPress={handleSmartRoute}>
              <Ionicons name="map-outline" size={16} color="#FFFFFF" />
              <Text style={styles.featureButtonText}>Smart Route</Text>
            </TouchableOpacity>
          </View>

          {/* Discover Banner */}
          <View style={styles.discoverBanner}>
            <Ionicons
              name={activeMode === 'dating' ? 'heart' : activeMode === 'friends' ? 'compass' : 'construct'}
              size={18}
              color="#2C2C2C"
            />
            <Text style={styles.discoverText}>
              {activeMode === 'dating' && 'Find matches with overlapping routes'}
              {activeMode === 'friends' && 'Discover travelers and nearby events'}
              {activeMode === 'builder' && 'Find skilled builders and mechanics'}
            </Text>
          </View>

          {/* Weather Alert (if any) - Compact inline */}
          {showWeatherAlerts && weatherChanges.length > 0 && currentAlertIndex < weatherChanges.length && (
            <TouchableOpacity 
              style={styles.inlineWeatherAlert}
              onPress={() => setShowWeatherAlerts(false)}
            >
              <Ionicons name="warning" size={16} color="#FF6B35" />
              <Text style={styles.inlineAlertText} numberOfLines={1}>
                {weatherChanges[currentAlertIndex].condition} expected - {weatherChanges[currentAlertIndex].severity}
              </Text>
              <Ionicons name="close" size={14} color="#666" />
            </TouchableOpacity>
          )}

          {/* Nearby Activities - Compact Cards */}
          <View style={styles.activitiesSection}>
            <View style={styles.activitiesHeader}>
              <Text style={styles.activitiesTitle}>
                {activeMode === 'builder' ? 'Nearby Builders' : 'Nearby Activities'}
              </Text>
              <TouchableOpacity onPress={() => setShowEvents(!showEvents)}>
                <Ionicons
                  name={showEvents ? 'chevron-down' : 'chevron-up'}
                  size={18}
                  color="#666"
                />
              </TouchableOpacity>
            </View>

            {showEvents && (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.activitiesScroll}
              >
                {nearbyEvents.map((event) => (
                  <TouchableOpacity
                    key={event.id}
                    style={styles.activityCard}
                    onPress={() => {
                      const eventMarker: MapMarkerData = {
                        id: event.id,
                        type: 'campfire',
                        name: event.title,
                        latitude: 38.5,
                        longitude: -109.5,
                        eventName: event.title,
                        eventType: event.type,
                        attendees: event.attendees,
                        maxAttendees: event.maxAttendees,
                        participants: event.attendees,
                        host: event.host,
                        eventTime: event.time,
                        time: event.time,
                        subtitle: event.location,
                        location: event.location,
                        description: event.description,
                        imageUrl: event.imageUrl,
                      };
                      setSelectedMarker(eventMarker);
                      setSheetVisible(true);
                    }}
                  >
                    <View style={styles.activityImageWrap}>
                      <Image
                        source={{ uri: event.imageUrl }}
                        style={styles.activityImage}
                        contentFit="cover"
                      />
                      <View style={[
                        styles.activityTypeBadge,
                        { backgroundColor: event.type === 'social' ? colors.ember[500] : colors.moss[500] }
                      ]}>
                        <Ionicons
                          name={event.type === 'social' ? 'flame' : 'walk'}
                          size={10}
                          color="#FFFFFF"
                        />
                      </View>
                    </View>
                    <Text style={styles.activityCardTitle} numberOfLines={1}>{event.title}</Text>
                    <Text style={styles.activityCardMeta}>{event.attendees} going</Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            )}
          </View>

          {/* Drop a Pin Button */}
          <TouchableOpacity style={styles.dropPinButton}>
            <Ionicons name={activeMode === 'builder' ? 'search' : 'location'} size={18} color="#FFFFFF" />
            <Text style={styles.dropPinText}>
              {activeMode === 'builder' ? 'Find Builder' : 'Drop a Pin'}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* Enhanced Liquid Sheet for marker details */}
      {selectedMarker && (
        <MapSocialSheet
          visible={sheetVisible}
          marker={selectedMarker}
          onClose={handleSheetClose}
          onAskToJoin={handleAskToJoin}
          onViewProfile={handleViewProfile}
          onMessage={handleMessage}
          onHire={handleHire}
          currentMode={activeMode}
        />
      )}

      {/* AI Route Planner Modal */}
      <AIRoutePlanner
        visible={routePlannerVisible}
        onClose={() => setRoutePlannerVisible(false)}
        onRouteSelect={handleRouteSelect}
        currentLocation={{
          latitude: mapboxConfig.defaultCenter.latitude,
          longitude: mapboxConfig.defaultCenter.longitude,
        }}
        destination={{
          latitude: 40.7128,
          longitude: -111.8910,
          name: 'Salt Lake City, UT',
        }}
      />

      {/* Advanced Radar Look Ahead Modal */}
      <LookAheadRadar
        visible={lookAheadVisible}
        onClose={() => setLookAheadVisible(false)}
        isPremium={isPremium}
      />

      {/* Cluster Vibe Sheet */}
      {selectedCluster && (
        <ClusterVibeSheet
          visible={clusterSheetVisible}
          cluster={selectedCluster}
          onClose={handleClusterSheetClose}
          onMemberPress={handleClusterMarkerSelect}
          currentMode={activeMode}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#F5EFE6',
  },
  mapSection: {
    height: SCREEN_HEIGHT * 0.55,
    width: '100%',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    overflow: 'hidden',
  },
  mapSectionExpanded: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    height: SCREEN_HEIGHT,
    zIndex: 1000,
    borderRadius: 0,
  },
  mapArea: {
    flex: 1,
    position: 'relative',
    borderRadius: 0,
    overflow: 'hidden',
  },
  expandButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#2C2C2C',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 100,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  compactWeatherBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    gap: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },
  compactWeatherTemp: {
    fontFamily: typography.fontFamily.bodySemiBold,
    fontSize: 16,
    color: '#2C2C2C',
  },
  recenterButton: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 3,
  },
  ghostModeIndicatorCompact: {
    position: 'absolute',
    top: 16,
    left: 80,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlsSection: {
    flex: 1,
  },
  controlsContent: {
    padding: 16,
    gap: 12,
    paddingBottom: 100,
  },
  modeSelector: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 6,
    gap: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  modeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderRadius: 8,
    gap: 6,
  },
  modeButtonActive: {
    backgroundColor: colors.ember[500],
  },
  modeButtonActiveFriends: {
    backgroundColor: '#3A6B4A',
  },
  modeButtonActiveBuilder: {
    backgroundColor: colors.driftwood[500],
  },
  modeLabel: {
    fontFamily: typography.fontFamily.bodyMedium,
    fontSize: 13,
    color: '#4A4A4A',
  },
  modeLabelActive: {
    color: '#FFFFFF',
    fontFamily: typography.fontFamily.bodySemiBold,
  },
  smartFeaturesRow: {
    flexDirection: 'row',
    gap: 12,
  },
  featureButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#6B8E7F',
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
  },
  featureButtonPrimary: {
    backgroundColor: '#3A6B4A',
  },
  featureButtonText: {
    fontFamily: typography.fontFamily.bodySemiBold,
    fontSize: 14,
    color: '#FFFFFF',
  },
  discoverBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    gap: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  discoverText: {
    fontFamily: typography.fontFamily.bodyMedium,
    fontSize: 14,
    color: '#2C2C2C',
    flex: 1,
  },
  inlineWeatherAlert: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF3E0',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    gap: 8,
    borderWidth: 1,
    borderColor: '#FFE0B2',
  },
  inlineAlertText: {
    fontFamily: typography.fontFamily.bodyMedium,
    fontSize: 13,
    color: '#E65100',
    flex: 1,
  },
  activitiesSection: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  activitiesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  activitiesTitle: {
    fontFamily: typography.fontFamily.bodySemiBold,
    fontSize: 15,
    color: '#2C2C2C',
  },
  activitiesScroll: {
    gap: 10,
    paddingRight: 4,
  },
  activityCard: {
    width: 120,
    backgroundColor: '#F8F8F8',
    borderRadius: 10,
    overflow: 'hidden',
  },
  activityImageWrap: {
    height: 70,
    position: 'relative',
  },
  activityImage: {
    width: '100%',
    height: '100%',
  },
  activityTypeBadge: {
    position: 'absolute',
    top: 6,
    left: 6,
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  activityCardTitle: {
    fontFamily: typography.fontFamily.bodySemiBold,
    fontSize: 12,
    color: '#2C2C2C',
    paddingHorizontal: 8,
    paddingTop: 8,
  },
  activityCardMeta: {
    fontFamily: typography.fontFamily.body,
    fontSize: 11,
    color: '#888',
    paddingHorizontal: 8,
    paddingBottom: 8,
  },
  dropPinButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.ember[500],
    paddingVertical: 14,
    borderRadius: 12,
    gap: 8,
    marginTop: 4,
  },
  dropPinText: {
    fontFamily: typography.fontFamily.bodySemiBold,
    fontSize: 15,
    color: '#FFFFFF',
  },
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  headerTitle: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.text.inverse,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
    letterSpacing: typography.letterSpacing.wide,
    textTransform: 'uppercase',
  },
  filterButton: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.full,
    backgroundColor: colors.glass.whiteMedium,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.glass,
  },
  toggleContainer: {
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.sm,
  },
  modeBanner: {
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.sm,
  },
  modeBannerCard: {
    backgroundColor: colors.glass.whiteSubtle,
  },
  modeBannerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  modeBannerText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[600],
    flex: 1,
  },
  mapContainer: {
    flex: 1,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  mapGradient: {
    flex: 1,
    position: 'relative',
  },
  terrainFeature: {
    position: 'absolute',
    borderRadius: borderRadius.xl,
    opacity: 0.5,
  },
  roadLine: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: mapboxConfig.style.road,
    opacity: 0.5,
  },
  roadLineVertical: {
    width: 3,
    height: '100%',
    left: '35%',
    top: 0,
    bottom: 0,
  },
  mapRegionLabel: {
    position: 'absolute',
    fontSize: typography.fontSize.md,
    fontFamily: typography.fontFamily.body,
    color: mapboxConfig.style.textLight,
    fontStyle: 'italic',
    opacity: 0.6,
  },
  mapLegend: {
    position: 'absolute',
    bottom: spacing.lg,
    left: spacing.lg,
    flexDirection: 'row',
    gap: spacing.md,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  legendMarker: {
    width: 18,
    height: 18,
    borderRadius: 9,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.glass.white,
  },
  legendText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.bark[600],
  },
  eventsPanel: {
    borderTopLeftRadius: borderRadius['2xl'],
    borderTopRightRadius: borderRadius['2xl'],
    paddingTop: spacing.lg,
    marginHorizontal: spacing.sm,
  },
  eventsPanelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.xl,
    marginBottom: spacing.md,
  },
  eventsPanelTitle: {
    fontSize: typography.fontSize.md,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
  },
  eventsScroll: {
    paddingHorizontal: spacing.xl,
    paddingBottom: spacing.md,
    gap: spacing.md,
  },
  eventCard: {
    width: 160,
    backgroundColor: colors.glass.whiteSubtle,
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.glass.border,
  },
  eventImageContainer: {
    height: 80,
    position: 'relative',
  },
  eventImage: {
    width: '100%',
    height: '100%',
  },
  eventImageOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.15)',
  },
  eventTypeBadge: {
    position: 'absolute',
    top: spacing.xs,
    left: spacing.xs,
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  eventInfo: {
    padding: spacing.md,
  },
  eventTitle: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
    marginBottom: spacing.xs,
  },
  eventMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  eventAttendees: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
  },
  joinButton: {
    marginHorizontal: spacing.sm,
    marginBottom: spacing.sm,
    backgroundColor: colors.moss[500],
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.lg,
    alignItems: 'center',
  },
  joinButtonText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
  dropPinContainer: {
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.lg,
  },
  // Current user marker styles
  currentUserMarker: {
    position: 'absolute',
    zIndex: 100,
    transform: [{ translateX: -30 }, { translateY: -30 }],
  },
  currentUserPreciseMarker: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  currentUserPreciseInner: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.moss[500],
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.md,
    borderWidth: 2,
    borderColor: colors.text.inverse,
  },
  currentUserPulse: {
    position: 'absolute',
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.moss[500] + '30',
  },
  // Look Ahead button styles
  lookAheadButton: {
    position: 'absolute',
    top: spacing.lg,
    left: spacing.lg,
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    ...shadows.glass,
  },
  lookAheadButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    gap: spacing.xs,
  },
  lookAheadButtonText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
  premiumBadgeMini: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: colors.glass.white,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: spacing.xs,
  },
  // Ghost mode indicator
  ghostModeIndicatorContainer: {
    position: 'absolute',
    top: spacing.lg,
    right: spacing.lg,
  },
  // Route overlap notification
  notificationBannerContainer: {
    position: 'absolute',
    bottom: spacing.lg,
    left: spacing.md,
    right: spacing.md,
  },
  // Weather HUD container
  weatherHudContainer: {
    position: 'absolute',
    top: spacing.lg + 50, // Below the Look Ahead button
    left: spacing.lg,
    zIndex: 50,
  },
  // Weather timeline container
  weatherTimelineContainer: {
    paddingHorizontal: spacing.md,
    marginBottom: spacing.sm,
  },
});
