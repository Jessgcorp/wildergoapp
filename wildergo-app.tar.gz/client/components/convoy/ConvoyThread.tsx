/**
 * WilderGo Convoy Thread Component
 * Full messaging experience with live pins, member statuses, and AI icebreakers
 */

import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, typography, spacing, borderRadius, shadows, blur } from '@/constants/theme';

// Stub hook for text generation (AI disabled in this environment)
function useTextGeneration(_options?: { onSuccess?: () => void; onError?: () => void }) {
  const [isLoading] = useState(false);
  const [data] = useState<string | null>(null);
  const generateText = useCallback(async (_prompt: string): Promise<string> => {
    return 'Welcome to the convoy!';
  }, []);
  return { generateText, data, isLoading };
}
import { GlassCard } from '@/components/ui/GlassCard';
import {
  Convoy,
  ConvoyMessage,
  ConvoyMember,
  getMemberStatusColor,
  getMemberStatusLabel,
  generateIcebreakerContext,
} from '@/services/convoy/convoyService';
import { ConvoyStatusHeader } from './ConvoyMemberStatus';
import { LivePinCard } from './LivePinCard';
import { NomadicPulseBadge } from './NomadicPulseBadge';

interface ConvoyThreadProps {
  convoy: Convoy;
  currentUserId: string;
  onBack: () => void;
  onOpenMap?: (latitude: number, longitude: number) => void;
  onViewMember?: (member: ConvoyMember) => void;
}

export const ConvoyThread: React.FC<ConvoyThreadProps> = ({
  convoy,
  currentUserId,
  onBack,
  onOpenMap,
  onViewMember,
}) => {
  const insets = useSafeAreaInsets();
  const [message, setMessage] = useState('');
  const [showPinSelector, setShowPinSelector] = useState(false);
  const [isGeneratingIcebreaker, setIsGeneratingIcebreaker] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  // AI Icebreaker integration
  const { generateText, data: icebreakerText, isLoading: icebreakerLoading } = useTextGeneration({
    onSuccess: () => {
      setIsGeneratingIcebreaker(false);
    },
    onError: () => {
      setIsGeneratingIcebreaker(false);
    },
  });

  const handleGenerateIcebreaker = useCallback(async (newMember: ConvoyMember) => {
    setIsGeneratingIcebreaker(true);
    const context = generateIcebreakerContext(newMember, convoy.members.filter(m => m.id !== newMember.id));
    await generateText(context);
  }, [convoy.members, generateText]);

  const handleSendMessage = useCallback(() => {
    if (!message.trim()) return;
    // In a real app, this would send the message to the backend
    console.log('Sending message:', message);
    setMessage('');
  }, [message]);

  const handlePinPress = useCallback((latitude: number, longitude: number) => {
    onOpenMap?.(latitude, longitude);
  }, [onOpenMap]);

  const renderMessage = ({ item }: { item: ConvoyMessage }) => {
    const isOwnMessage = item.senderId === currentUserId;
    const isSystem = item.type === 'system';

    // System messages
    if (isSystem) {
      return (
        <View style={styles.systemMessage}>
          <Text style={styles.systemMessageText}>{item.content}</Text>
        </View>
      );
    }

    // Status update messages
    if (item.type === 'status_update' && item.statusUpdate) {
      const newStatusColor = getMemberStatusColor(item.statusUpdate.newStatus);
      const newStatusLabel = getMemberStatusLabel(item.statusUpdate.newStatus);

      return (
        <View style={styles.statusUpdateMessage}>
          <View style={[styles.statusUpdateDot, { backgroundColor: newStatusColor }]} />
          <Text style={styles.statusUpdateText}>
            <Text style={styles.statusUpdateName}>{item.senderName}</Text>
            {' is now '}
            <Text style={[styles.statusUpdateStatus, { color: newStatusColor }]}>
              {newStatusLabel}
            </Text>
          </Text>
        </View>
      );
    }

    // Live pin messages
    if (item.type === 'live_pin' && item.livePin) {
      return (
        <View style={[styles.messageContainer, isOwnMessage && styles.messageContainerOwn]}>
          {!isOwnMessage && (
            <TouchableOpacity
              onPress={() => {
                const member = convoy.members.find(m => m.id === item.senderId);
                if (member) onViewMember?.(member);
              }}
            >
              {item.senderAvatar ? (
                <Image source={{ uri: item.senderAvatar }} style={styles.avatar} />
              ) : (
                <View style={styles.avatarPlaceholder}>
                  <Ionicons name="person" size={16} color={colors.bark[400]} />
                </View>
              )}
            </TouchableOpacity>
          )}
          <View style={styles.messageContent}>
            {!isOwnMessage && (
              <Text style={styles.senderName}>{item.senderName}</Text>
            )}
            <LivePinCard
              pin={item.livePin}
              onPress={(pin) => handlePinPress(pin.latitude, pin.longitude)}
            />
            <Text style={styles.messageTime}>
              {formatTime(item.timestamp)}
            </Text>
          </View>
        </View>
      );
    }

    // AI Icebreaker messages
    if (item.type === 'icebreaker') {
      return (
        <View style={styles.icebreakerContainer}>
          <GlassCard variant="frost" padding="md" style={styles.icebreakerCard}>
            <View style={styles.icebreakerHeader}>
              <View style={styles.icebreakerIconContainer}>
                <Ionicons name="sparkles" size={16} color={colors.ember[500]} />
              </View>
              <Text style={styles.icebreakerLabel}>AI Icebreaker</Text>
            </View>
            <Text style={styles.icebreakerText}>{item.content}</Text>
            <TouchableOpacity style={styles.useIcebreakerButton}>
              <Text style={styles.useIcebreakerText}>Use This</Text>
            </TouchableOpacity>
          </GlassCard>
        </View>
      );
    }

    // Regular text messages
    return (
      <View style={[styles.messageContainer, isOwnMessage && styles.messageContainerOwn]}>
        {!isOwnMessage && (
          <TouchableOpacity
            onPress={() => {
              const member = convoy.members.find(m => m.id === item.senderId);
              if (member) onViewMember?.(member);
            }}
          >
            {item.senderAvatar ? (
              <Image source={{ uri: item.senderAvatar }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={16} color={colors.bark[400]} />
              </View>
            )}
          </TouchableOpacity>
        )}
        <View style={styles.messageContent}>
          {!isOwnMessage && (
            <Text style={styles.senderName}>{item.senderName}</Text>
          )}
          <View style={[
            styles.messageBubble,
            isOwnMessage ? styles.messageBubbleOwn : styles.messageBubbleOther,
          ]}>
            <Text style={[
              styles.messageText,
              isOwnMessage && styles.messageTextOwn,
            ]}>
              {item.content}
            </Text>
          </View>
          <Text style={[
            styles.messageTime,
            isOwnMessage && styles.messageTimeOwn,
          ]}>
            {formatTime(item.timestamp)}
          </Text>
        </View>
      </View>
    );
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
    >
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top }]}>
        {Platform.OS === 'ios' ? (
          <BlurView intensity={blur.heavy} tint="light" style={styles.headerBlur}>
            <HeaderContent
              convoy={convoy}
              onBack={onBack}
              onViewMember={onViewMember}
            />
          </BlurView>
        ) : (
          <View style={[styles.headerBlur, styles.headerFallback]}>
            <HeaderContent
              convoy={convoy}
              onBack={onBack}
              onViewMember={onViewMember}
            />
          </View>
        )}
      </View>

      {/* Messages List */}
      <FlatList
        ref={flatListRef}
        data={convoy.messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.messagesList,
          { paddingBottom: 100 + insets.bottom },
        ]}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() => {
          flatListRef.current?.scrollToEnd({ animated: true });
        }}
      />

      {/* AI Icebreaker Loading */}
      {isGeneratingIcebreaker && (
        <View style={styles.icebreakerLoading}>
          <Ionicons name="sparkles" size={16} color={colors.ember[500]} />
          <Text style={styles.icebreakerLoadingText}>
            Generating icebreaker...
          </Text>
        </View>
      )}

      {/* Input Area */}
      <View style={[styles.inputContainer, { paddingBottom: insets.bottom + spacing.sm }]}>
        {Platform.OS === 'ios' ? (
          <BlurView intensity={blur.heavy} tint="light" style={styles.inputBlur}>
            <InputContent
              message={message}
              setMessage={setMessage}
              onSend={handleSendMessage}
              onPinPress={() => setShowPinSelector(!showPinSelector)}
            />
          </BlurView>
        ) : (
          <View style={[styles.inputBlur, styles.inputFallback]}>
            <InputContent
              message={message}
              setMessage={setMessage}
              onSend={handleSendMessage}
              onPinPress={() => setShowPinSelector(!showPinSelector)}
            />
          </View>
        )}
      </View>
    </KeyboardAvoidingView>
  );
};

// Header content component
interface HeaderContentProps {
  convoy: Convoy;
  onBack: () => void;
  onViewMember?: (member: ConvoyMember) => void;
}

const HeaderContent: React.FC<HeaderContentProps> = ({ convoy, onBack, onViewMember }) => (
  <View style={headerStyles.content}>
    <TouchableOpacity onPress={onBack} style={headerStyles.backButton}>
      <Ionicons name="chevron-back" size={24} color={colors.bark[700]} />
    </TouchableOpacity>

    <View style={headerStyles.titleContainer}>
      <Text style={headerStyles.title} numberOfLines={1}>{convoy.name}</Text>
      <Text style={headerStyles.subtitle}>
        {convoy.members.length} members • {convoy.destination}
      </Text>
    </View>

    {/* Member avatars */}
    <View style={headerStyles.avatarStack}>
      {convoy.members.slice(0, 3).map((member, index) => (
        <TouchableOpacity
          key={member.id}
          style={[headerStyles.stackedAvatar, { marginLeft: index > 0 ? -10 : 0 }]}
          onPress={() => onViewMember?.(member)}
        >
          {member.avatar ? (
            <Image source={{ uri: member.avatar }} style={headerStyles.memberAvatar} />
          ) : (
            <View style={headerStyles.memberAvatarPlaceholder}>
              <Ionicons name="person" size={12} color={colors.bark[400]} />
            </View>
          )}
          <View
            style={[
              headerStyles.statusDot,
              { backgroundColor: getMemberStatusColor(member.status) },
            ]}
          />
        </TouchableOpacity>
      ))}
      {convoy.members.length > 3 && (
        <View style={[headerStyles.moreMembers, { marginLeft: -10 }]}>
          <Text style={headerStyles.moreMembersText}>
            +{convoy.members.length - 3}
          </Text>
        </View>
      )}
    </View>

    <TouchableOpacity style={headerStyles.menuButton}>
      <Ionicons name="ellipsis-vertical" size={20} color={colors.bark[600]} />
    </TouchableOpacity>
  </View>
);

// Input content component
interface InputContentProps {
  message: string;
  setMessage: (msg: string) => void;
  onSend: () => void;
  onPinPress: () => void;
}

const InputContent: React.FC<InputContentProps> = ({
  message,
  setMessage,
  onSend,
  onPinPress,
}) => (
  <View style={inputStyles.content}>
    <TouchableOpacity style={inputStyles.pinButton} onPress={onPinPress}>
      <Ionicons name="location" size={22} color={colors.moss[500]} />
    </TouchableOpacity>

    <TextInput
      style={inputStyles.input}
      placeholder="Message the convoy..."
      placeholderTextColor={colors.bark[400]}
      value={message}
      onChangeText={setMessage}
      multiline
      maxLength={1000}
    />

    <TouchableOpacity
      style={[
        inputStyles.sendButton,
        message.trim() && inputStyles.sendButtonActive,
      ]}
      onPress={onSend}
      disabled={!message.trim()}
    >
      <Ionicons
        name="send"
        size={18}
        color={message.trim() ? colors.text.inverse : colors.bark[400]}
      />
    </TouchableOpacity>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.driftwood[100],
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
  },
  headerBlur: {
    borderBottomWidth: 1,
    borderBottomColor: colors.glass.border,
  },
  headerFallback: {
    backgroundColor: colors.glass.white,
  },
  messagesList: {
    paddingTop: 140,
    paddingHorizontal: spacing.md,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: spacing.md,
    alignItems: 'flex-end',
    gap: spacing.sm,
  },
  messageContainerOwn: {
    flexDirection: 'row-reverse',
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  avatarPlaceholder: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.glass.whiteLight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageContent: {
    maxWidth: '75%',
  },
  senderName: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[600],
    marginBottom: spacing.xs,
    marginLeft: spacing.sm,
  },
  messageBubble: {
    padding: spacing.md,
    borderRadius: borderRadius.xl,
    ...shadows.glassSubtle,
  },
  messageBubbleOwn: {
    backgroundColor: colors.moss[500],
    borderBottomRightRadius: spacing.xs,
  },
  messageBubbleOther: {
    backgroundColor: colors.glass.white,
    borderBottomLeftRadius: spacing.xs,
  },
  messageText: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[700],
    lineHeight: 20,
  },
  messageTextOwn: {
    color: colors.text.inverse,
  },
  messageTime: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    marginTop: spacing.xs,
    marginLeft: spacing.sm,
  },
  messageTimeOwn: {
    textAlign: 'right',
    marginRight: spacing.sm,
    marginLeft: 0,
  },
  systemMessage: {
    alignItems: 'center',
    paddingVertical: spacing.md,
  },
  systemMessageText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    backgroundColor: colors.glass.whiteSubtle,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  statusUpdateMessage: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: spacing.sm,
    gap: spacing.sm,
  },
  statusUpdateDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusUpdateText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
  },
  statusUpdateName: {
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[700],
  },
  statusUpdateStatus: {
    fontFamily: typography.fontFamily.bodySemiBold,
  },
  icebreakerContainer: {
    alignItems: 'center',
    paddingVertical: spacing.md,
  },
  icebreakerCard: {
    maxWidth: '90%',
  },
  icebreakerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  icebreakerIconContainer: {
    width: 28,
    height: 28,
    borderRadius: borderRadius.md,
    backgroundColor: colors.ember[500] + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  icebreakerLabel: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.ember[600],
  },
  icebreakerText: {
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[700],
    lineHeight: 22,
    marginBottom: spacing.md,
  },
  useIcebreakerButton: {
    backgroundColor: colors.ember[500],
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.lg,
    alignSelf: 'flex-start',
  },
  useIcebreakerText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
  icebreakerLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
  },
  icebreakerLoadingText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.ember[500],
  },
  inputContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  inputBlur: {
    borderTopWidth: 1,
    borderTopColor: colors.glass.border,
  },
  inputFallback: {
    backgroundColor: colors.glass.white,
  },
});

const headerStyles = StyleSheet.create({
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleContainer: {
    flex: 1,
    marginLeft: spacing.sm,
  },
  title: {
    fontSize: typography.fontSize.lg,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[800],
    letterSpacing: typography.letterSpacing.wide,
  },
  subtitle: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    marginTop: 2,
  },
  avatarStack: {
    flexDirection: 'row',
    marginRight: spacing.md,
  },
  stackedAvatar: {
    position: 'relative',
  },
  memberAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: colors.glass.white,
  },
  memberAvatarPlaceholder: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.glass.whiteLight,
    borderWidth: 2,
    borderColor: colors.glass.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusDot: {
    position: 'absolute',
    bottom: -1,
    right: -1,
    width: 10,
    height: 10,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: colors.glass.white,
  },
  moreMembers: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.bark[200],
    borderWidth: 2,
    borderColor: colors.glass.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  moreMembersText: {
    fontSize: 10,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[600],
  },
  menuButton: {
    width: 36,
    height: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

const inputStyles = StyleSheet.create({
  content: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: spacing.md,
    gap: spacing.sm,
  },
  pinButton: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.moss[500] + '15',
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    minHeight: 40,
    maxHeight: 100,
    backgroundColor: colors.glass.whiteLight,
    borderRadius: borderRadius.xl,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: typography.fontSize.base,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[800],
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.bark[200],
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonActive: {
    backgroundColor: colors.moss[500],
  },
});

export default ConvoyThread;
