/**
 * WilderGo Builder Profile Card
 * Professional directory format (no swiping)
 * Displays 'Technical Specs', 'Verified Builder' badges, consultation rates
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows } from '@/constants/theme';
import { GlassCard } from '@/components/ui/GlassCard';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface BuilderProfile {
  id: string;
  name?: string;
  businessName: string;
  ownerName?: string;
  imageUrl: string;
  coverImageUrl?: string;
  location: string;
  expertise: string[];
  rating: number;
  reviewCount: number;
  verified: boolean;
  yearsExperience?: number;
  buildsCompleted?: number;
  consultationRate: number;
  availability?: string;
  portfolioImages?: string[];
  specialties: {
    name: string;
    icon: string | keyof typeof Ionicons.glyphMap;
  }[];
  bio?: string;
  certifications?: string[];
  responseTime?: string;
}

interface BuilderProfileCardProps {
  profile: BuilderProfile;
  onBookCall?: () => void;
  onBookConsult?: () => void;
  onViewPortfolio?: () => void;
  onMessage?: () => void;
  featured?: boolean;
}

export const BuilderProfileCard: React.FC<BuilderProfileCardProps> = ({
  profile,
  onBookConsult,
  onViewPortfolio,
  onMessage,
  featured = false,
}) => {
  const specialtyIcons: Record<string, keyof typeof Ionicons.glyphMap> = {
    'Solar': 'sunny',
    'Electrical': 'flash',
    'Plumbing': 'water',
    'HVAC': 'thermometer',
    'Diesel Heaters': 'flame',
    'Insulation': 'layers',
    'Flooring': 'grid',
    'Cabinetry': 'cube',
    'Windows': 'square-outline',
    'Roof Raises': 'arrow-up',
    'Custom Builds': 'construct',
    'Conversions': 'swap-horizontal',
  };

  const renderStars = (rating: number) => {
    return (
      <View style={styles.starsContainer}>
        {[1, 2, 3, 4, 5].map((star) => (
          <Ionicons
            key={star}
            name={star <= rating ? 'star' : star - rating < 1 ? 'star-half' : 'star-outline'}
            size={14}
            color={colors.ember[500]}
          />
        ))}
      </View>
    );
  };

  return (
    <GlassCard
      variant={featured ? 'medium' : 'frost'}
      padding="none"
      style={[styles.container, featured && styles.featuredContainer]}
    >
      {/* Featured Badge */}
      {featured && (
        <View style={styles.featuredBadge}>
          <Ionicons name="star" size={12} color={colors.text.inverse} />
          <Text style={styles.featuredText}>Featured</Text>
        </View>
      )}

      {/* Header with Cover Image */}
      {profile.coverImageUrl && (
        <View style={styles.coverContainer}>
          <Image
            source={{ uri: profile.coverImageUrl }}
            style={styles.coverImage}
            contentFit="cover"
          />
          <View style={styles.coverOverlay} />
        </View>
      )}

      {/* Profile Section */}
      <View style={styles.profileSection}>
        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: profile.imageUrl }}
            style={styles.avatar}
            contentFit="cover"
          />
          {profile.verified && (
            <View style={styles.verifiedBadge}>
              <Ionicons name="shield-checkmark" size={14} color={colors.text.inverse} />
            </View>
          )}
        </View>

        <View style={styles.profileInfo}>
          <View style={styles.nameRow}>
            <Text style={styles.businessName}>{profile.businessName}</Text>
            {profile.verified && (
              <View style={styles.verifiedTag}>
                <Ionicons name="checkmark-circle" size={12} color={colors.moss[500]} />
                <Text style={styles.verifiedTagText}>Verified</Text>
              </View>
            )}
          </View>
          <Text style={styles.ownerName}>by {profile.ownerName || profile.name}</Text>
          <View style={styles.locationRow}>
            <Ionicons name="location" size={12} color={colors.bark[400]} />
            <Text style={styles.location}>{profile.location}</Text>
          </View>
        </View>
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <View style={styles.ratingContainer}>
            {renderStars(profile.rating)}
            <Text style={styles.ratingText}>{profile.rating.toFixed(1)}</Text>
          </View>
          <Text style={styles.statLabel}>{profile.reviewCount} reviews</Text>
        </View>

        <View style={styles.statDivider} />

        {profile.yearsExperience && (
          <>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{profile.yearsExperience}+</Text>
              <Text style={styles.statLabel}>Years Exp.</Text>
            </View>
          </>
        )}

        {profile.buildsCompleted && (
          <>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{profile.buildsCompleted}</Text>
              <Text style={styles.statLabel}>Builds</Text>
            </View>
          </>
        )}
      </View>

      {/* Technical Specs / Expertise */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Technical Expertise</Text>
        <View style={styles.expertiseGrid}>
          {profile.specialties.map((specialty, index) => (
            <View key={index} style={styles.expertiseChip}>
              <Ionicons
                name={specialtyIcons[specialty.name] || 'construct'}
                size={14}
                color={colors.driftwood[500]}
              />
              <Text style={styles.expertiseText}>{specialty.name}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Certifications */}
      {profile.certifications && profile.certifications.length > 0 && (
        <View style={styles.certificationsRow}>
          <Ionicons name="ribbon" size={14} color={colors.moss[500]} />
          <Text style={styles.certificationsText}>
            {profile.certifications.slice(0, 2).join(' • ')}
          </Text>
        </View>
      )}

      {/* Bio */}
      {profile.bio && (
        <Text style={styles.bio} numberOfLines={2}>
          {profile.bio}
        </Text>
      )}

      {/* Availability & Community Focus */}
      <View style={styles.availabilitySection}>
        <View style={styles.availabilityRow}>
          <View style={styles.availabilityItem}>
            <Ionicons name="calendar" size={16} color={colors.bark[500]} />
            <Text style={styles.availabilityText}>{profile.availability}</Text>
          </View>
          {profile.responseTime && (
            <View style={styles.availabilityItem}>
              <Ionicons name="time" size={16} color={colors.bark[500]} />
              <Text style={styles.availabilityText}>{profile.responseTime}</Text>
            </View>
          )}
        </View>

        <View style={styles.communityBadge}>
          <Ionicons name="people" size={14} color={colors.moss[600]} />
          <Text style={styles.communityText}>Community Helper</Text>
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionButtons}>
        <TouchableOpacity
          style={styles.portfolioButton}
          onPress={onViewPortfolio}
          activeOpacity={0.8}
        >
          <Ionicons name="images-outline" size={18} color={colors.driftwood[600]} />
          <Text style={styles.portfolioButtonText}>Portfolio</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.messageButton}
          onPress={onMessage}
          activeOpacity={0.8}
        >
          <Ionicons name="chatbubble-outline" size={18} color={colors.driftwood[600]} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.bookButton}
          onPress={onBookConsult}
          activeOpacity={0.8}
        >
          <Ionicons name="chatbubbles" size={18} color={colors.text.inverse} />
          <Text style={styles.bookButtonText}>Ask for Help</Text>
        </TouchableOpacity>
      </View>
    </GlassCard>
  );
};

// Compact Builder Card for lists
export const BuilderCompactCard: React.FC<{
  profile: BuilderProfile;
  onPress?: () => void;
}> = ({ profile, onPress }) => {
  return (
    <TouchableOpacity
      style={compactStyles.container}
      onPress={onPress}
      activeOpacity={0.9}
    >
      <Image
        source={{ uri: profile.imageUrl }}
        style={compactStyles.image}
        contentFit="cover"
      />
      {profile.verified && (
        <View style={compactStyles.verifiedBadge}>
          <Ionicons name="shield-checkmark" size={10} color={colors.moss[500]} />
        </View>
      )}
      <View style={compactStyles.info}>
        <Text style={compactStyles.name} numberOfLines={1}>
          {profile.businessName}
        </Text>
        <View style={compactStyles.ratingRow}>
          <Ionicons name="star" size={10} color={colors.ember[500]} />
          <Text style={compactStyles.rating}>{profile.rating.toFixed(1)}</Text>
          <Text style={compactStyles.reviews}>({profile.reviewCount})</Text>
        </View>
        <TouchableOpacity style={compactStyles.bookButton}>
          <Text style={compactStyles.bookButtonText}>Book Video Call</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    width: SCREEN_WIDTH - spacing.xl * 2,
    borderRadius: borderRadius['2xl'],
    overflow: 'hidden',
  },
  featuredContainer: {
    borderWidth: 2,
    borderColor: colors.ember[300],
  },
  featuredBadge: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.ember[500],
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
    zIndex: 10,
  },
  featuredText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
  coverContainer: {
    height: 100,
    position: 'relative',
  },
  coverImage: {
    width: '100%',
    height: '100%',
  },
  coverOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  profileSection: {
    flexDirection: 'row',
    padding: spacing.lg,
    paddingBottom: spacing.md,
    gap: spacing.md,
  },
  avatarContainer: {
    position: 'relative',
  },
  avatar: {
    width: 70,
    height: 70,
    borderRadius: borderRadius.xl,
    borderWidth: 3,
    borderColor: colors.glass.white,
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: -4,
    right: -4,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.moss[500],
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.glass.white,
  },
  profileInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    flexWrap: 'wrap',
  },
  businessName: {
    fontSize: typography.fontSize.lg,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[900],
  },
  verifiedTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: colors.moss[100],
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.full,
  },
  verifiedTagText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.moss[600],
  },
  ownerName: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    marginTop: 2,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginTop: spacing.xs,
  },
  location: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingVertical: spacing.md,
    marginHorizontal: spacing.lg,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: colors.glass.border,
  },
  statItem: {
    alignItems: 'center',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  starsContainer: {
    flexDirection: 'row',
  },
  ratingText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodyBold,
    color: colors.bark[800],
  },
  statValue: {
    fontSize: typography.fontSize.lg,
    fontFamily: typography.fontFamily.bodyBold,
    color: colors.bark[800],
  },
  statLabel: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    height: 30,
    backgroundColor: colors.glass.border,
  },
  section: {
    padding: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: 0,
  },
  sectionTitle: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[400],
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.sm,
  },
  expertiseGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  expertiseChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.driftwood[50],
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.driftwood[200],
  },
  expertiseText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.driftwood[700],
  },
  certificationsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.md,
  },
  certificationsText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.moss[600],
  },
  bio: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    lineHeight: 20,
    paddingHorizontal: spacing.lg,
    marginTop: spacing.md,
  },
  availabilitySection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.lg,
    paddingBottom: spacing.md,
  },
  availabilityRow: {
    gap: spacing.sm,
  },
  availabilityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  availabilityText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[600],
  },
  communityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.moss[100],
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.moss[200],
  },
  communityText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.moss[700],
  },
  actionButtons: {
    flexDirection: 'row',
    gap: spacing.sm,
    padding: spacing.lg,
    paddingTop: 0,
  },
  portfolioButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.lg,
    borderWidth: 1.5,
    borderColor: colors.driftwood[300],
  },
  portfolioButtonText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.driftwood[600],
  },
  messageButton: {
    width: 44,
    height: 44,
    borderRadius: borderRadius.lg,
    borderWidth: 1.5,
    borderColor: colors.driftwood[300],
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.driftwood[500],
  },
  bookButtonText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
});

const compactStyles = StyleSheet.create({
  container: {
    width: 150,
    backgroundColor: colors.glass.white,
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    ...shadows.glass,
  },
  image: {
    width: '100%',
    height: 100,
  },
  verifiedBadge: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: colors.glass.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  info: {
    padding: spacing.sm,
  },
  name: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    marginTop: 2,
  },
  rating: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
  },
  reviews: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
  },
  bookButton: {
    marginTop: spacing.sm,
    backgroundColor: colors.driftwood[500],
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    alignItems: 'center',
  },
  bookButtonText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
});

export default BuilderProfileCard;
