/**
 * WilderGo Dating Profile Card
 * Mode-specific profile focusing on Route Synchronization
 * Displays 'Next Stop', 'Travel Timeline', and 'Route Overlap %'
 */

import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows } from '@/constants/theme';
import { GlassCard } from '@/components/ui/GlassCard';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

interface DatingProfile {
  id: string;
  name: string;
  age: number;
  imageUrl: string;
  currentLocation: string;
  nextDestination: string;
  arrivalDate: string;
  routeOverlap: number;
  travelTimeline: string;
  rigType: string;
  rigName?: string;
  interests: string[];
  bio?: string;
  verified?: boolean;
  online?: boolean;
}

interface DatingProfileCardProps {
  profile: DatingProfile;
  onLike?: () => void;
  onPass?: () => void;
  onSuperLike?: () => void;
  onViewProfile?: () => void;
  compact?: boolean;
}

export const DatingProfileCard: React.FC<DatingProfileCardProps> = ({
  profile,
  onLike,
  onPass,
  onSuperLike,
  onViewProfile,
  compact = false,
}) => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _heartPulse = useRef(new Animated.Value(1)).current;
  const overlapGlow = useRef(new Animated.Value(0.3)).current;

  // Pulse animation for high route overlap
  useEffect(() => {
    if (profile.routeOverlap >= 70) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(overlapGlow, {
            toValue: 0.8,
            duration: 1200,
            useNativeDriver: false,
          }),
          Animated.timing(overlapGlow, {
            toValue: 0.3,
            duration: 1200,
            useNativeDriver: false,
          }),
        ])
      ).start();
    }
  }, [profile.routeOverlap, overlapGlow]);

  const getOverlapColor = () => {
    if (profile.routeOverlap >= 70) return colors.ember[500];
    if (profile.routeOverlap >= 40) return colors.moss[500];
    return colors.bark[400];
  };

  const getOverlapLabel = () => {
    if (profile.routeOverlap >= 70) return 'High Match';
    if (profile.routeOverlap >= 40) return 'Good Overlap';
    return 'Different Routes';
  };

  // Compact view for cards in the background
  if (compact) {
    return (
      <TouchableOpacity
        style={compactStyles.container}
        onPress={onViewProfile}
        activeOpacity={0.9}
      >
        <View style={compactStyles.imageContainer}>
          <Image
            source={{ uri: profile.imageUrl }}
            style={compactStyles.image}
            contentFit="cover"
          />
          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.6)']}
            style={compactStyles.overlay}
          />
          <View style={[compactStyles.overlapBadge, { backgroundColor: getOverlapColor() }]}>
            <Text style={compactStyles.overlapText}>{profile.routeOverlap}%</Text>
          </View>
          {profile.online && <View style={compactStyles.onlineIndicator} />}
        </View>
        <View style={compactStyles.info}>
          <Text style={compactStyles.name}>{profile.name}, {profile.age}</Text>
          <Text style={compactStyles.location} numberOfLines={1}>
            📍 {profile.currentLocation}
          </Text>
          <Text style={compactStyles.nextStop} numberOfLines={1}>
            → {profile.nextDestination}
          </Text>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View style={styles.container}>
      {/* Main Image */}
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: profile.imageUrl }}
          style={styles.image}
          contentFit="cover"
        />
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.3)', 'rgba(0,0,0,0.8)']}
          style={styles.imageOverlay}
        />

        {/* Route Overlap Badge */}
        <Animated.View
          style={[
            styles.routeOverlapBadge,
            {
              backgroundColor: getOverlapColor(),
              shadowColor: getOverlapColor(),
              shadowOpacity: overlapGlow,
            },
          ]}
        >
          <Ionicons name="git-merge" size={14} color={colors.text.inverse} />
          <Text style={styles.routeOverlapText}>{profile.routeOverlap}%</Text>
          <Text style={styles.routeOverlapLabel}>{getOverlapLabel()}</Text>
        </Animated.View>

        {/* Verified Badge */}
        {profile.verified && (
          <View style={styles.verifiedBadge}>
            <Ionicons name="shield-checkmark" size={16} color={colors.moss[500]} />
          </View>
        )}

        {/* Profile Info Overlay */}
        <View style={styles.profileInfoOverlay}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>{profile.name}, {profile.age}</Text>
          </View>
          <Text style={styles.location}>
            📍 {profile.currentLocation}
          </Text>
        </View>
      </View>

      {/* Route Sync Card */}
      <GlassCard variant="frost" padding="lg" style={styles.routeCard}>
        <View style={styles.routeHeader}>
          <Ionicons name="navigate" size={18} color={colors.ember[500]} />
          <Text style={styles.routeTitle}>Route Synchronization</Text>
        </View>

        <View style={styles.routeDetails}>
          {/* Next Destination */}
          <View style={styles.routeItem}>
            <View style={styles.routeIcon}>
              <Ionicons name="location" size={16} color={colors.ember[400]} />
            </View>
            <View style={styles.routeInfo}>
              <Text style={styles.routeLabel}>Next Stop</Text>
              <Text style={styles.routeValue}>{profile.nextDestination}</Text>
            </View>
          </View>

          {/* Arrival Date */}
          <View style={styles.routeItem}>
            <View style={styles.routeIcon}>
              <Ionicons name="calendar" size={16} color={colors.ember[400]} />
            </View>
            <View style={styles.routeInfo}>
              <Text style={styles.routeLabel}>Arriving</Text>
              <Text style={styles.routeValue}>{profile.arrivalDate}</Text>
            </View>
          </View>

          {/* Travel Timeline */}
          <View style={styles.routeItem}>
            <View style={styles.routeIcon}>
              <Ionicons name="time" size={16} color={colors.ember[400]} />
            </View>
            <View style={styles.routeInfo}>
              <Text style={styles.routeLabel}>Timeline</Text>
              <Text style={styles.routeValue}>{profile.travelTimeline}</Text>
            </View>
          </View>
        </View>

        {/* Rig Info */}
        <View style={styles.rigInfo}>
          <Text style={styles.rigText}>🚐 {profile.rigType}</Text>
          {profile.rigName && (
            <Text style={styles.rigName}>&quot;{profile.rigName}&quot;</Text>
          )}
        </View>
      </GlassCard>

      {/* Interests */}
      <View style={styles.interestsContainer}>
        {profile.interests.slice(0, 4).map((interest, index) => (
          <View key={index} style={styles.interestChip}>
            <Text style={styles.interestText}>{interest}</Text>
          </View>
        ))}
      </View>

      {/* Action Buttons */}
      <View style={styles.actionButtons}>
        <TouchableOpacity
          style={[styles.actionButton, styles.passButton]}
          onPress={onPass}
          activeOpacity={0.8}
        >
          <Ionicons name="close" size={32} color={colors.bark[400]} />
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, styles.superLikeButton]}
          onPress={onSuperLike}
          activeOpacity={0.8}
        >
          <Ionicons name="star" size={28} color={colors.ember[400]} />
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, styles.likeButton]}
          onPress={onLike}
          activeOpacity={0.8}
        >
          <Ionicons name="heart" size={32} color={colors.ember[500]} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: SCREEN_WIDTH - spacing.xl * 2,
    maxHeight: SCREEN_HEIGHT * 0.78,
    borderRadius: borderRadius['2xl'],
    overflow: 'hidden',
    backgroundColor: colors.glass.white,
    ...shadows.glass,
  },
  imageContainer: {
    height: SCREEN_HEIGHT * 0.38,
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  imageOverlay: {
    ...StyleSheet.absoluteFillObject,
  },
  routeOverlapBadge: {
    position: 'absolute',
    top: spacing.lg,
    right: spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    gap: spacing.xs,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 12,
    elevation: 8,
  },
  routeOverlapText: {
    fontSize: typography.fontSize.md,
    fontFamily: typography.fontFamily.bodyBold,
    color: colors.text.inverse,
  },
  routeOverlapLabel: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.text.inverse,
    opacity: 0.9,
  },
  verifiedBadge: {
    position: 'absolute',
    top: spacing.lg,
    left: spacing.lg,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.glass.white,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.glass,
  },
  profileInfoOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: spacing.lg,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  name: {
    fontSize: typography.fontSize['2xl'],
    fontFamily: typography.fontFamily.heading,
    color: colors.text.inverse,
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  location: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.text.inverse,
    opacity: 0.9,
    marginTop: spacing.xs,
  },
  routeCard: {
    margin: spacing.md,
    borderRadius: borderRadius.xl,
  },
  routeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  routeTitle: {
    fontSize: typography.fontSize.md,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
  },
  routeDetails: {
    gap: spacing.sm,
  },
  routeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  routeIcon: {
    width: 32,
    height: 32,
    borderRadius: borderRadius.md,
    backgroundColor: colors.ember[50],
    justifyContent: 'center',
    alignItems: 'center',
  },
  routeInfo: {
    flex: 1,
  },
  routeLabel: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  routeValue: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
  },
  rigInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.md,
    paddingTop: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.glass.border,
    gap: spacing.sm,
  },
  rigText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[600],
  },
  rigName: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.bark[400],
    fontStyle: 'italic',
  },
  interestsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: spacing.md,
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  interestChip: {
    backgroundColor: colors.ember[50],
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
  },
  interestText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.ember[600],
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: spacing.lg,
    paddingHorizontal: spacing.xl,
    gap: spacing.lg,
  },
  actionButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadows.glass,
  },
  passButton: {
    backgroundColor: colors.glass.white,
    borderWidth: 2,
    borderColor: colors.bark[200],
  },
  superLikeButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.glass.white,
    borderWidth: 2,
    borderColor: colors.ember[200],
  },
  likeButton: {
    backgroundColor: colors.ember[50],
    borderWidth: 2,
    borderColor: colors.ember[300],
  },
});

const compactStyles = StyleSheet.create({
  container: {
    width: SCREEN_WIDTH - spacing.xl * 2,
    borderRadius: borderRadius['2xl'],
    overflow: 'hidden',
    backgroundColor: colors.glass.white,
    ...shadows.glass,
  },
  imageContainer: {
    height: 200,
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
  },
  overlapBadge: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  overlapText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
  onlineIndicator: {
    position: 'absolute',
    top: spacing.md,
    left: spacing.md,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.moss[500],
    borderWidth: 2,
    borderColor: colors.text.inverse,
  },
  info: {
    padding: spacing.md,
  },
  name: {
    fontSize: typography.fontSize.lg,
    fontFamily: typography.fontFamily.heading,
    color: colors.bark[800],
  },
  location: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    marginTop: spacing.xs,
  },
  nextStop: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.ember[600],
    marginTop: spacing.xs,
  },
});

export default DatingProfileCard;
