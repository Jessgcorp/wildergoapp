/**
 * WilderGo Friends Profile Card
 * Mode-specific profile focusing on Activity Alignment
 * Displays 'Interests', 'Available for...' status
 */

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, spacing, borderRadius, shadows } from '@/constants/theme';
import { GlassCard } from '@/components/ui/GlassCard';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface FriendsProfile {
  id: string;
  name: string;
  age?: number;
  imageUrl: string;
  currentLocation: string;
  rigType: string;
  interests: string[];
  availableFor: string[];
  bio?: string;
  online?: boolean;
  verified?: boolean;
  travelStyle?: string;
  pets?: string;
}

interface FriendsProfileCardProps {
  profile: FriendsProfile;
  onConnect?: () => void;
  onMessage?: () => void;
  onViewProfile?: () => void;
  compact?: boolean;
}

export const FriendsProfileCard: React.FC<FriendsProfileCardProps> = ({
  profile,
  onConnect,
  onMessage,
  onViewProfile,
  compact = false,
}) => {
  const availabilityIcons: Record<string, keyof typeof Ionicons.glyphMap> = {
    'Hiking': 'walk',
    'Climbing': 'trending-up',
    'Coffee': 'cafe',
    'Convoy': 'car',
    'Stargazing': 'star',
    'Camping': 'bonfire',
    'Co-working': 'laptop',
    'Photography': 'camera',
    'Surfing': 'water',
    'Music': 'musical-notes',
  };

  if (compact) {
    return (
      <TouchableOpacity
        style={compactStyles.container}
        onPress={onViewProfile}
        activeOpacity={0.9}
      >
        <View style={compactStyles.imageContainer}>
          <Image
            source={{ uri: profile.imageUrl }}
            style={compactStyles.image}
            contentFit="contain"
            contentPosition="top"
          />
          {profile.online && <View style={compactStyles.onlineIndicator} />}
        </View>
        <View style={compactStyles.info}>
          <Text style={compactStyles.name}>{profile.name}</Text>
          <Text style={compactStyles.location} numberOfLines={1}>
            {profile.currentLocation}
          </Text>
          <View style={compactStyles.tagContainer}>
            {profile.availableFor.slice(0, 2).map((activity, index) => (
              <View key={index} style={compactStyles.tag}>
                <Ionicons
                  name={availabilityIcons[activity] || 'ellipse'}
                  size={10}
                  color={colors.moss[500]}
                />
                <Text style={compactStyles.tagText}>{activity}</Text>
              </View>
            ))}
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View style={styles.cardWrapper}>
      {/* Profile Header */}
      <View style={styles.header}>
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: profile.imageUrl }}
            style={styles.image}
            contentFit="contain"
            contentPosition="top"
          />
          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.5)']}
            style={styles.imageOverlay}
          />
          {profile.online && <View style={styles.onlineIndicator} />}
          {profile.verified && (
            <View style={styles.verifiedBadge}>
              <Ionicons name="shield-checkmark" size={14} color={colors.moss[500]} />
            </View>
          )}
        </View>

        {/* Name & Location Overlay */}
        <View style={styles.headerOverlay}>
          <Text style={styles.name}>
            {profile.name}{profile.age ? `, ${profile.age}` : ''}
          </Text>
          <View style={styles.locationRow}>
            <Ionicons name="location" size={14} color={colors.text.inverse} />
            <Text style={styles.location}>{profile.currentLocation}</Text>
          </View>
        </View>
      </View>

      {/* Content - Solid background for readability */}
      <View style={styles.content}>
        {/* Rig Type */}
        <View style={styles.rigRow}>
          <Text style={styles.rigEmoji}>🚐</Text>
          <Text style={styles.rigType}>{profile.rigType}</Text>
          {profile.pets && (
            <View style={styles.petsBadge}>
              <Text style={styles.petsText}>{profile.pets}</Text>
            </View>
          )}
        </View>

        {/* Available For Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Available For</Text>
          <View style={styles.availabilityGrid}>
            {profile.availableFor.map((activity, index) => (
              <View key={index} style={styles.availabilityChip}>
                <Ionicons
                  name={availabilityIcons[activity] || 'ellipse'}
                  size={14}
                  color={colors.moss[500]}
                />
                <Text style={styles.availabilityText}>{activity}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Interests Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Interests</Text>
          <View style={styles.interestsContainer}>
            {profile.interests.map((interest, index) => (
              <View key={index} style={styles.interestChip}>
                <Text style={styles.interestText}>{interest}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Bio */}
        {profile.bio && (
          <Text style={styles.bio} numberOfLines={2}>
            {profile.bio}
          </Text>
        )}

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.messageButton}
            onPress={onMessage}
            activeOpacity={0.8}
          >
            <Ionicons name="chatbubble-outline" size={18} color={colors.moss[600]} />
            <Text style={styles.messageButtonText}>Message</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.connectButton}
            onPress={onConnect}
            activeOpacity={0.8}
          >
            <Ionicons name="people" size={18} color={colors.text.inverse} />
            <Text style={styles.connectButtonText}>Connect</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  cardWrapper: {
    width: '100%',
    borderRadius: borderRadius['2xl'],
    overflow: 'hidden',
    backgroundColor: '#FFFFFF',
    ...shadows.glass,
  },
  header: {
    height: 220,
    position: 'relative',
    backgroundColor: colors.bark[100],
  },
  imageContainer: {
    flex: 1,
    position: 'relative',
    backgroundColor: colors.bark[100],
  },
  image: {
    width: '100%',
    height: '100%',
  },
  imageOverlay: {
    ...StyleSheet.absoluteFillObject,
  },
  onlineIndicator: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: colors.moss[500],
    borderWidth: 2,
    borderColor: colors.text.inverse,
  },
  verifiedBadge: {
    position: 'absolute',
    top: spacing.md,
    left: spacing.md,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.glass.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: spacing.lg,
  },
  name: {
    fontSize: typography.fontSize.xl,
    fontFamily: typography.fontFamily.heading,
    color: colors.text.inverse,
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 4,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginTop: spacing.xs,
  },
  location: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.text.inverse,
    opacity: 0.9,
  },
  content: {
    padding: spacing.lg,
    backgroundColor: '#FFFFFF',
  },
  rigRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  rigEmoji: {
    fontSize: 18,
  },
  rigType: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.bark[600],
  },
  petsBadge: {
    backgroundColor: colors.moss[100],
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: borderRadius.full,
  },
  petsText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.moss[600],
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[400],
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: spacing.sm,
  },
  availabilityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  availabilityChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    backgroundColor: colors.moss[50],
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
    borderWidth: 1,
    borderColor: colors.moss[200],
  },
  availabilityText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodyMedium,
    color: colors.moss[700],
  },
  interestsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  interestChip: {
    backgroundColor: colors.bark[100],
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
  },
  interestText: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[600],
  },
  bio: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[500],
    lineHeight: 20,
    marginBottom: spacing.lg,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: spacing.md,
  },
  messageButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    borderWidth: 1.5,
    borderColor: colors.moss[300],
    backgroundColor: colors.glass.whiteSubtle,
  },
  messageButtonText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.moss[600],
  },
  connectButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.md,
    borderRadius: borderRadius.lg,
    backgroundColor: colors.moss[500],
  },
  connectButtonText: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.text.inverse,
  },
});

const compactStyles = StyleSheet.create({
  container: {
    width: 140,
    backgroundColor: '#FFFFFF',
    borderRadius: borderRadius.xl,
    overflow: 'hidden',
    ...shadows.glass,
  },
  imageContainer: {
    height: 130,
    position: 'relative',
    backgroundColor: colors.bark[100],
  },
  image: {
    width: '100%',
    height: '100%',
  },
  onlineIndicator: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.moss[500],
    borderWidth: 2,
    borderColor: colors.text.inverse,
  },
  info: {
    padding: spacing.sm,
    backgroundColor: '#FFFFFF',
  },
  name: {
    fontSize: typography.fontSize.sm,
    fontFamily: typography.fontFamily.bodySemiBold,
    color: colors.bark[800],
  },
  location: {
    fontSize: typography.fontSize.xs,
    fontFamily: typography.fontFamily.body,
    color: colors.bark[400],
    marginTop: 2,
  },
  tagContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    marginTop: spacing.xs,
  },
  tag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: colors.moss[50],
    paddingHorizontal: spacing.xs,
    paddingVertical: 2,
    borderRadius: borderRadius.sm,
  },
  tagText: {
    fontSize: 9,
    fontFamily: typography.fontFamily.body,
    color: colors.moss[600],
  },
});

export default FriendsProfileCard;
