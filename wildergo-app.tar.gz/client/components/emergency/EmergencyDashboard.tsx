/**
 * Emergency Help Dashboard
 * Main screen with glass cards for emergency categories
 * Liquid iOS aesthetic with Russo One headers
 */

import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Platform,
  Dimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, typography, spacing, borderRadius, shadows, blur } from '@/constants/theme';
import { EmergencyCategory, EMERGENCY_CATEGORIES } from './types';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface EmergencyDashboardProps {
  onSelectCategory: (category: EmergencyCategory) => void;
  activeRequests?: number;
  onViewActiveRequest?: () => void;
  isInConvoy?: boolean;
  onRigBreakFlare?: () => void;
}

export const EmergencyDashboard: React.FC<EmergencyDashboardProps> = ({
  onSelectCategory,
  activeRequests = 0,
  isInConvoy = false,
  onRigBreakFlare,
  onViewActiveRequest,
}) => {
  const insets = useSafeAreaInsets();
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const glowAnim = useRef(new Animated.Value(0.4)).current;

  useEffect(() => {
    // Pulsing animation for emergency header
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Glow animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 0.8,
          duration: 1200,
          useNativeDriver: true,
        }),
        Animated.timing(glowAnim, {
          toValue: 0.4,
          duration: 1200,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, [pulseAnim, glowAnim]);

  const renderCategoryCard = (category: EmergencyCategory) => {
    const info = EMERGENCY_CATEGORIES[category];

    return (
      <TouchableOpacity
        key={category}
        style={styles.categoryCard}
        onPress={() => onSelectCategory(category)}
        activeOpacity={0.8}
      >
        {Platform.OS === 'ios' ? (
          <BlurView
            tint="light"
            intensity={blur.heavy}
            style={styles.categoryBlur}
          >
            <View style={[styles.categoryContent, { borderColor: info.color + '40' }]}>
              <View style={[styles.categoryIconContainer, { backgroundColor: info.color + '20' }]}>
                <Ionicons
                  name={info.icon as keyof typeof Ionicons.glyphMap}
                  size={40}
                  color={info.color}
                />
              </View>
              <Text style={styles.categoryLabel}>{info.label}</Text>
              <Text style={styles.categoryDescription}>{info.description}</Text>
              <View style={styles.categoryExamples}>
                {info.examples.slice(0, 2).map((example, idx) => (
                  <View key={idx} style={[styles.exampleChip, { backgroundColor: info.color + '15' }]}>
                    <Text style={[styles.exampleText, { color: info.color }]}>{example}</Text>
                  </View>
                ))}
              </View>
            </View>
          </BlurView>
        ) : (
          <View style={[styles.categoryContent, styles.categoryContentAndroid, { borderColor: info.color + '40' }]}>
            <View style={[styles.categoryIconContainer, { backgroundColor: info.color + '20' }]}>
              <Ionicons
                name={info.icon as keyof typeof Ionicons.glyphMap}
                size={40}
                color={info.color}
              />
            </View>
            <Text style={styles.categoryLabel}>{info.label}</Text>
            <Text style={styles.categoryDescription}>{info.description}</Text>
            <View style={styles.categoryExamples}>
              {info.examples.slice(0, 2).map((example, idx) => (
                <View key={idx} style={[styles.exampleChip, { backgroundColor: info.color + '15' }]}>
                  <Text style={[styles.exampleText, { color: info.color }]}>{example}</Text>
                </View>
              ))}
            </View>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      {/* Warm Cream Background with subtle emergency gradient */}
      <LinearGradient
        colors={['#F5EFE6', '#F0E8DD', '#EBE2D5']}
        style={StyleSheet.absoluteFill}
      />

      {/* Animated Emergency Glow Overlay */}
      <Animated.View
        style={[
          styles.glowOverlay,
          { opacity: glowAnim },
        ]}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + spacing.lg, paddingBottom: insets.bottom + 120 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <Animated.View style={[styles.header, { transform: [{ scale: pulseAnim }] }]}>
          <View style={styles.sosIconContainer}>
            <Ionicons name="warning" size={48} color={colors.sunsetOrange[500]} />
          </View>
          <Text style={styles.headerTitle}>EMERGENCY HELP</Text>
          <Text style={styles.headerSubtitle}>
            Select the type of help you need
          </Text>
        </Animated.View>

        {/* Active Request Banner */}
        {activeRequests > 0 && (
          <TouchableOpacity
            style={styles.activeRequestBanner}
            onPress={onViewActiveRequest}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[colors.sunsetOrange[500], colors.burntSienna[500]]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.activeRequestGradient}
            >
              <View style={styles.activeRequestContent}>
                <View style={styles.activeRequestLeft}>
                  <View style={styles.pulseDot} />
                  <Text style={styles.activeRequestText}>
                    Active Request Broadcasting
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#FFF" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        )}

        {/* Category Cards Grid */}
        <View style={styles.categoriesGrid}>
          {(Object.keys(EMERGENCY_CATEGORIES) as EmergencyCategory[]).map(renderCategoryCard)}
        </View>

        {/* Convoy Rig Break Flare Option */}
        {isInConvoy && onRigBreakFlare && (
          <TouchableOpacity
            style={styles.convoyFlareCard}
            onPress={onRigBreakFlare}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[colors.burntSienna[500] + '15', colors.sunsetOrange[500] + '10']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.convoyFlareGradient}
            >
              <View style={styles.convoyFlareContent}>
                <View style={[styles.convoyFlareIcon, { backgroundColor: colors.burntSienna[500] + '20' }]}>
                  <Ionicons name="flash" size={28} color={colors.burntSienna[500]} />
                </View>
                <View style={styles.convoyFlareText}>
                  <Text style={styles.convoyFlareTitle}>Convoy Rig Break</Text>
                  <Text style={styles.convoyFlareSubtitle}>
                    Alert your convoy members instantly about a vehicle issue
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={colors.burntSienna[500]} />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        )}

        {/* Safety Notice */}
        <View style={styles.safetyNotice}>
          {Platform.OS === 'ios' ? (
            <BlurView tint="dark" intensity={blur.medium} style={styles.safetyBlur}>
              <View style={styles.safetyContent}>
                <Ionicons name="information-circle" size={24} color={colors.bark[300]} />
                <Text style={styles.safetyText}>
                  For life-threatening emergencies, always call 911 first. This feature connects you with nearby nomads who may be able to assist.
                </Text>
              </View>
            </BlurView>
          ) : (
            <View style={[styles.safetyContent, styles.safetyContentAndroid]}>
              <Ionicons name="information-circle" size={24} color={colors.bark[300]} />
              <Text style={styles.safetyText}>
                For life-threatening emergencies, always call 911 first. This feature connects you with nearby nomads who may be able to assist.
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5EFE6', // Warm Cream
  },
  glowOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: colors.sunsetOrange[500],
    opacity: 0.08,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing['2xl'],
  },
  sosIconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.sunsetOrange[500] + '20',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.lg,
    borderWidth: 2,
    borderColor: colors.sunsetOrange[500] + '40',
    ...shadows.glowEmergency,
  },
  headerTitle: {
    fontFamily: typography.fontFamily.heading,
    fontSize: typography.fontSize['3xl'],
    color: colors.sunsetOrange[500],
    letterSpacing: typography.letterSpacing.rugged,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  headerSubtitle: {
    fontFamily: typography.fontFamily.body,
    fontSize: typography.fontSize.md,
    color: colors.bark[600],
    textAlign: 'center',
  },
  activeRequestBanner: {
    borderRadius: borderRadius.liquid,
    overflow: 'hidden',
    marginBottom: spacing.xl,
    ...shadows.glowDating,
  },
  activeRequestGradient: {
    borderRadius: borderRadius.liquid,
  },
  activeRequestContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  activeRequestLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
  },
  pulseDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#FFF',
  },
  activeRequestText: {
    fontFamily: typography.fontFamily.bodySemiBold,
    fontSize: typography.fontSize.base,
    color: '#FFF',
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  categoryCard: {
    width: (SCREEN_WIDTH - spacing.lg * 2 - spacing.md) / 2,
    borderRadius: borderRadius.liquidLg,
    overflow: 'hidden',
    ...shadows.glass,
  },
  categoryBlur: {
    borderRadius: borderRadius.liquidLg,
    overflow: 'hidden',
  },
  categoryContent: {
    padding: spacing.lg,
    minHeight: 200,
    borderWidth: 1,
    borderRadius: borderRadius.liquidLg,
    backgroundColor: colors.glass.whiteLight,
  },
  categoryContentAndroid: {
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
  },
  categoryIconContainer: {
    width: 72,
    height: 72,
    borderRadius: borderRadius.xl,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  categoryLabel: {
    fontFamily: typography.fontFamily.heading,
    fontSize: typography.fontSize.xl,
    color: colors.bark[800],
    marginBottom: spacing.xs,
    letterSpacing: typography.letterSpacing.rugged,
  },
  categoryDescription: {
    fontFamily: typography.fontFamily.body,
    fontSize: typography.fontSize.sm,
    color: colors.bark[500],
    lineHeight: typography.fontSize.sm * 1.4,
    marginBottom: spacing.md,
  },
  categoryExamples: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
  },
  exampleChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: borderRadius.full,
  },
  exampleText: {
    fontFamily: typography.fontFamily.bodyMedium,
    fontSize: typography.fontSize.xs,
  },
  safetyNotice: {
    borderRadius: borderRadius.liquid,
    overflow: 'hidden',
  },
  safetyBlur: {
    borderRadius: borderRadius.liquid,
  },
  safetyContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.md,
    padding: spacing.lg,
  },
  safetyContentAndroid: {
    backgroundColor: 'rgba(30, 24, 20, 0.85)',
    borderRadius: borderRadius.liquid,
  },
  safetyText: {
    flex: 1,
    fontFamily: typography.fontFamily.body,
    fontSize: typography.fontSize.sm,
    color: colors.bark[200],
    lineHeight: typography.fontSize.sm * 1.5,
  },
  convoyFlareCard: {
    marginBottom: spacing.xl,
    borderRadius: borderRadius.liquid,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.burntSienna[500] + '30',
  },
  convoyFlareGradient: {
    borderRadius: borderRadius.liquid,
  },
  convoyFlareContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.lg,
    gap: spacing.md,
  },
  convoyFlareIcon: {
    width: 56,
    height: 56,
    borderRadius: borderRadius.xl,
    justifyContent: 'center',
    alignItems: 'center',
  },
  convoyFlareText: {
    flex: 1,
  },
  convoyFlareTitle: {
    fontFamily: typography.fontFamily.heading,
    fontSize: typography.fontSize.lg,
    color: colors.bark[800],
    letterSpacing: typography.letterSpacing.rugged,
    marginBottom: spacing.xxs,
  },
  convoyFlareSubtitle: {
    fontFamily: typography.fontFamily.body,
    fontSize: typography.fontSize.sm,
    color: colors.bark[500],
    lineHeight: typography.fontSize.sm * 1.4,
  },
});

export default EmergencyDashboard;
