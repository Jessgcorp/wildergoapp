/**
 * WilderGo Map Service
 * Handles map data, marker management, and social layer logic
 */

import { markerTypes, socialLayer, profileImages, eventImages, natureImages } from '@/constants/theme';

export type MarkerType = 'traveler' | 'campfire' | 'match' | 'builder';
export type AppMode = 'dating' | 'friends' | 'builder';

export interface MapMarkerData {
  id: string;
  type: MarkerType;
  latitude?: number;
  longitude?: number;
  lat?: number;
  lng?: number;
  title?: string;
  name: string;
  subtitle?: string;
  imageUrl?: string;
  // Traveler/Match specific
  age?: number;
  vehicle?: string;
  routeOverlap?: number;
  destination?: string;
  destinationDate?: string;
  interests?: string[];
  online?: boolean;
  // Event specific
  eventType?: 'social' | 'activity' | 'convoy';
  eventName?: string;
  eventTime?: string;
  time?: string;
  participants?: number;
  attendees?: number;
  maxAttendees?: number;
  host?: string;
  activity?: string;
  location?: string;
  description?: string;
  // Builder specific
  specialty?: string;
  rating?: number;
  reviews?: number;
  verified?: boolean;
  availability?: string;
  expertise?: string[];
}

// Mock data for travelers/matches
const mockTravelers: MapMarkerData[] = [
  {
    id: 't1',
    type: 'traveler',
    latitude: 38.5733,
    longitude: -109.5498,
    title: 'Alex',
    name: 'Alex',
    age: 28,
    vehicle: "'98 Sprinter",
    routeOverlap: 85,
    destination: 'Glacier NP',
    destinationDate: 'Aug 15',
    interests: ['Hiking', 'Coffee', 'Photography'],
    imageUrl: profileImages.alex,
    online: true,
    subtitle: 'Moab, UT',
  },
  {
    id: 't2',
    type: 'match',
    latitude: 38.6833,
    longitude: -109.4498,
    title: 'Jordan',
    name: 'Jordan',
    age: 32,
    vehicle: 'Promaster',
    routeOverlap: 72,
    destination: 'Big Sur',
    destinationDate: 'Sept 1',
    interests: ['Yoga', 'Climbing', 'Cooking'],
    imageUrl: profileImages.jordan,
    online: true,
    subtitle: 'Near Arches NP',
  },
  {
    id: 't3',
    type: 'traveler',
    latitude: 38.4533,
    longitude: -109.6198,
    title: 'Sam',
    name: 'Sam',
    age: 26,
    vehicle: 'Skoolie',
    routeOverlap: 45,
    destination: 'Pacific NW',
    destinationDate: 'Aug 20',
    interests: ['Music', 'Surfing', 'Stargazing'],
    imageUrl: profileImages.sam,
    online: false,
    subtitle: 'Canyonlands',
  },
];

// Mock data for events
const mockEvents: MapMarkerData[] = [
  {
    id: 'e1',
    type: 'campfire',
    latitude: 38.5933,
    longitude: -109.5098,
    name: 'Sunset Bonfire',
    title: 'Sunset Bonfire',
    eventName: 'Sunset Bonfire Hangout',
    eventTime: 'Tonight at 7pm',
    participants: 12,
    host: 'Alex',
    activity: 'Social',
    imageUrl: eventImages.bonfire,
    subtitle: 'Desert Overlook',
  },
  {
    id: 'e2',
    type: 'campfire',
    latitude: 38.6133,
    longitude: -109.4898,
    name: 'Morning Hike',
    title: 'Morning Hike',
    eventName: 'Delicate Arch Sunrise',
    eventTime: 'Tomorrow 5:30am',
    participants: 6,
    host: 'Jordan',
    activity: 'Hiking',
    imageUrl: eventImages.hiking,
    subtitle: 'Arches NP',
  },
  {
    id: 'e3',
    type: 'campfire',
    latitude: 38.5333,
    longitude: -109.5798,
    name: 'Climbing Session',
    title: 'Climbing Session',
    eventName: 'Fisher Towers Climb',
    eventTime: 'Sat 6am',
    participants: 4,
    host: 'Sam',
    activity: 'Climbing',
    imageUrl: eventImages.climbing,
    subtitle: 'Fisher Towers',
  },
];

// Mock data for builders
const mockBuilders: MapMarkerData[] = [
  {
    id: 'b1',
    type: 'builder',
    latitude: 38.5433,
    longitude: -109.5298,
    title: "Sarah's Solar",
    name: 'Sarah',
    specialty: 'Electrical Systems',
    rating: 4.9,
    reviews: 47,
    verified: true,
    imageUrl: profileImages.sarah,
    availability: 'Available this week',
    expertise: ['Solar Installation', 'Battery Systems', 'Inverters'],
    subtitle: 'Moab Area',
  },
  {
    id: 'b2',
    type: 'builder',
    latitude: 38.6033,
    longitude: -109.4698,
    title: 'VanTech Mike',
    name: 'Mike',
    specialty: 'Complete Builds',
    rating: 4.8,
    reviews: 32,
    verified: true,
    imageUrl: profileImages.mike,
    availability: 'Booked - Available Oct 15',
    expertise: ['Custom Cabinetry', 'Insulation', 'Plumbing'],
    subtitle: 'Near Arches',
  },
];

/**
 * Get markers filtered by current app mode
 */
export function getMarkersForMode(mode: AppMode): MapMarkerData[] {
  const markers: MapMarkerData[] = [];

  switch (mode) {
    case 'dating':
      // Show travelers with high route overlap as matches
      markers.push(
        ...mockTravelers.map((t) => ({
          ...t,
          type: (t.routeOverlap && t.routeOverlap >= socialLayer.routeOverlap.high
            ? 'match'
            : 'traveler') as MarkerType,
        }))
      );
      // Also show events
      markers.push(...mockEvents);
      break;

    case 'friends':
      // Show all travelers and events
      markers.push(...mockTravelers);
      markers.push(...mockEvents);
      break;

    case 'builder':
      // Show builders only
      markers.push(...mockBuilders);
      break;
  }

  return markers;
}

/**
 * Get marker configuration by type
 */
export function getMarkerConfig(type: MarkerType) {
  return markerTypes[type] || markerTypes.traveler;
}

/**
 * Calculate route overlap glow intensity
 */
export function getRouteOverlapGlow(overlap: number): { intensity: number; color: string } {
  if (overlap >= socialLayer.routeOverlap.high) {
    return { intensity: 0.8, color: 'rgba(214, 138, 92, 0.8)' }; // Strong ember
  } else if (overlap >= socialLayer.routeOverlap.medium) {
    return { intensity: 0.5, color: 'rgba(214, 138, 92, 0.5)' }; // Medium ember
  } else if (overlap >= socialLayer.routeOverlap.low) {
    return { intensity: 0.3, color: 'rgba(214, 138, 92, 0.3)' }; // Light ember
  }
  return { intensity: 0, color: 'transparent' };
}

/**
 * Calculate nomadic density for an area
 */
export function calculateNomadicDensity(
  markers: MapMarkerData[],
  centerLat: number,
  centerLng: number,
  radiusMiles: number
): number {
  const travelers = markers.filter(
    (m) => m.type === 'traveler' || m.type === 'match'
  );

  // Simple distance calculation (approximate for demo)
  const nearby = travelers.filter((t) => {
    const lat = t.latitude ?? t.lat ?? 0;
    const lng = t.longitude ?? t.lng ?? 0;
    const dLat = lat - centerLat;
    const dLng = lng - centerLng;
    const distance = Math.sqrt(dLat * dLat + dLng * dLng) * 69; // rough miles
    return distance <= radiusMiles;
  });

  return nearby.length;
}

/**
 * Get smart route suggestions based on social overlap
 */
export interface SmartRouteSuggestion {
  id: string;
  name: string;
  description: string;
  overlapPercentage: number;
  nomadicDensity: number;
  waypoints: { latitude: number; longitude: number; name: string }[];
  estimatedTravelTime: string;
  highlights: string[];
}

export function getSmartRouteSuggestions(): SmartRouteSuggestion[] {
  return [
    {
      id: 'route1',
      name: 'High Desert Social Loop',
      description: 'Maximum nomad density route through Moab to Monument Valley',
      overlapPercentage: 78,
      nomadicDensity: 12,
      waypoints: [
        { latitude: 38.5733, longitude: -109.5498, name: 'Moab' },
        { latitude: 38.7833, longitude: -109.7498, name: 'Arches NP' },
        { latitude: 37.0042, longitude: -110.0987, name: 'Monument Valley' },
      ],
      estimatedTravelTime: '3 days',
      highlights: ['3 bonfire events', '8 travelers en route', '2 vetted builders'],
    },
    {
      id: 'route2',
      name: 'Canyon Country Connect',
      description: 'Connect with nomads heading to Zion and Bryce',
      overlapPercentage: 65,
      nomadicDensity: 8,
      waypoints: [
        { latitude: 38.5733, longitude: -109.5498, name: 'Moab' },
        { latitude: 37.2982, longitude: -113.0263, name: 'Zion NP' },
        { latitude: 37.6283, longitude: -112.1677, name: 'Bryce Canyon' },
      ],
      estimatedTravelTime: '4 days',
      highlights: ['2 hiking groups', '5 travelers with overlap', '1 builder'],
    },
    {
      id: 'route3',
      name: 'Pacific Northwest Trail',
      description: 'Follow the nomad migration to cooler climates',
      overlapPercentage: 52,
      nomadicDensity: 15,
      waypoints: [
        { latitude: 38.5733, longitude: -109.5498, name: 'Moab' },
        { latitude: 43.8041, longitude: -110.7139, name: 'Grand Teton' },
        { latitude: 45.5152, longitude: -122.6784, name: 'Portland' },
      ],
      estimatedTravelTime: '7 days',
      highlights: ['Multiple convoy opportunities', '15+ nomads', '5 builders'],
    },
  ];
}

export const mapService = {
  getMarkersForMode,
  getMarkerConfig,
  getRouteOverlapGlow,
  calculateNomadicDensity,
  getSmartRouteSuggestions,
};

export default mapService;
