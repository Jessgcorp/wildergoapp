/**
 * WilderGo RevenueCat Hook
 * Manages subscription state and purchase operations
 */

import { useState, useEffect, useCallback } from 'react';
import { Platform, Alert } from 'react-native';

interface CustomerInfo {
  entitlements: {
    active: Record<string, any>;
  };
}

interface Package {
  identifier: string;
  product: {
    identifier: string;
    priceString: string;
  };
}

interface UseRevenueCatReturn {
  isInitialized: boolean;
  isPremium: boolean;
  isLoading: boolean;
  packages: Package[];
  customerInfo: CustomerInfo | null;
  purchasePackage: (pkg: Package) => Promise<boolean>;
  restorePurchases: () => Promise<boolean>;
  checkEntitlement: (entitlementId: string) => boolean;
}

const CONVOY_ENTITLEMENT_ID = 'convoy';
const PREMIUM_ENTITLEMENT_ID = 'premium';

export const useRevenueCat = (): UseRevenueCatReturn => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo | null>(null);
  const [packages, setPackages] = useState<Package[]>([]);

  // Initialize RevenueCat
  useEffect(() => {
    const init = async () => {
      try {
        const apiKey = process.env.EXPO_PUBLIC_REVENUECAT_API_KEY;

        if (!apiKey) {
          console.log('RevenueCat API key not configured - running in development mode');
          setIsLoading(false);
          return;
        }

        const Purchases = await import('react-native-purchases').then(m => m.default);

        // Configure SDK
        Purchases.configure({ apiKey });

        // Get customer info
        const info = await Purchases.getCustomerInfo();
        setCustomerInfo(info);

        // Get offerings
        const offerings = await Purchases.getOfferings();
        if (offerings.current?.availablePackages) {
          setPackages(offerings.current.availablePackages);
        }

        setIsInitialized(true);
      } catch (error) {
        console.error('Failed to initialize RevenueCat:', error);
      } finally {
        setIsLoading(false);
      }
    };

    init();
  }, []);

  // Check if user has premium access
  const isPremium = customerInfo?.entitlements?.active?.[CONVOY_ENTITLEMENT_ID] !== undefined ||
                    customerInfo?.entitlements?.active?.[PREMIUM_ENTITLEMENT_ID] !== undefined;

  // Purchase a package
  const purchasePackage = useCallback(async (pkg: Package): Promise<boolean> => {
    if (!isInitialized) {
      Alert.alert('Error', 'RevenueCat is not initialized');
      return false;
    }

    setIsLoading(true);

    try {
      const Purchases = await import('react-native-purchases').then(m => m.default);
      const { customerInfo: newInfo } = await Purchases.purchasePackage(pkg as any);
      setCustomerInfo(newInfo);

      return newInfo.entitlements.active[CONVOY_ENTITLEMENT_ID] !== undefined ||
             newInfo.entitlements.active[PREMIUM_ENTITLEMENT_ID] !== undefined;
    } catch (error: any) {
      if (!error.userCancelled) {
        console.error('Purchase failed:', error);
        Alert.alert('Purchase Failed', error.message || 'An error occurred during purchase.');
      }
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [isInitialized]);

  // Restore purchases
  const restorePurchases = useCallback(async (): Promise<boolean> => {
    if (!isInitialized) {
      Alert.alert('Error', 'RevenueCat is not initialized');
      return false;
    }

    setIsLoading(true);

    try {
      const Purchases = await import('react-native-purchases').then(m => m.default);
      const info = await Purchases.restorePurchases();
      setCustomerInfo(info);

      const hasPremium = info.entitlements.active[CONVOY_ENTITLEMENT_ID] !== undefined ||
                         info.entitlements.active[PREMIUM_ENTITLEMENT_ID] !== undefined;

      if (hasPremium) {
        Alert.alert('Success', 'Your subscription has been restored!');
      } else {
        Alert.alert('No Subscription Found', 'No active subscription was found to restore.');
      }

      return hasPremium;
    } catch (error: any) {
      console.error('Restore failed:', error);
      Alert.alert('Restore Failed', error.message || 'An error occurred while restoring purchases.');
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [isInitialized]);

  // Check specific entitlement
  const checkEntitlement = useCallback((entitlementId: string): boolean => {
    return customerInfo?.entitlements?.active?.[entitlementId] !== undefined;
  }, [customerInfo]);

  return {
    isInitialized,
    isPremium,
    isLoading,
    packages,
    customerInfo,
    purchasePackage,
    restorePurchases,
    checkEntitlement,
  };
};

export default useRevenueCat;
