import { useNavigation, NavigationProp } from '@react-navigation/native';

type RootParamList = Record<string, object | undefined>;

export function useRouter() {
  const navigation = useNavigation<NavigationProp<RootParamList>>();
  
  return {
    push: (path: string, params?: Record<string, unknown>) => {
      const routeName = path.replace(/^\/\(tabs\)\//, '').replace(/^\/(onboarding)\//, '');
      navigation.navigate(routeName, params);
    },
    replace: (path: string, params?: Record<string, unknown>) => {
      const routeName = path.replace(/^\/\(tabs\)\//, '').replace(/^\/(onboarding)\//, '');
      navigation.navigate(routeName, params);
    },
    back: () => {
      if (navigation.canGoBack()) {
        navigation.goBack();
      }
    },
    canGoBack: () => navigation.canGoBack(),
  };
}
